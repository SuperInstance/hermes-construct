# digital-twin-shell

> *"The simulation is a hypothesis. Reality is the arbiter. The human
> is the anchor."*
> — the gitage archive

The **visible reef surface** for the SuperInstance fleet — boat + fleet
+ Gap + kintsugi + the agents (CoCapn, Scout, Validator), all rendered
in a single Three.js page and streamed from a Python WebSocket bridge
that consumes a JSONL fixture shaped like the eventual `cocapn-marine`
NMEA output.

* Single HTML file, no build step.
* Three.js r147 + OrbitControls via CDN (pinned). r147 is the last release
  that ships both `build/three.min.js` (UMD) and `examples/js/controls/OrbitControls.js`
  (UMD), so no importmap is required for the no-build GitHub Pages drop-in.
* Python stdlib + `websockets>=12` for the bridge (with a stdlib
  fallback if the lib isn't available).
* GitHub Pages drop-in.
* ~330 lines of HTML, ~330 lines of Python.

## Quick start

```bash
# 1. (Optional) install the websockets lib for the bridge
pip install websockets

# 2. Start the bridge on port 8765, replaying the bundled 2-min track
python -m digital_twin_shell.bridge --replay --port 8765 &

# 3. Serve the static page (any static server works)
python -m http.server 8000 &

# 4. Open the page
open http://localhost:8000/index.html
# or run the bundled helper:
./bin/dev.sh
```

You should see: a dark indigo ocean, a paper-white boat at the origin,
three teal ghost-ships fading by distance, a HUD bottom-left, a gold
serif agent panel top-right ("CoCapn: course 270°, rudder 0.0°, on
course."), and at t≈35s a gold seam opens on the ocean as the sounder
diverges from the chart; at t≈70s a fuzzy circle opens around the boat
as the heading deadband trips.

### WS endpoint override

The default WS endpoint is `ws://<hostname>:8765/`. Override via query
params:

```
http://localhost:8000/index.html?ws=ws://192.168.1.42:8765/&port=8765
```

## The Reef — public site

A polished public site for the shell lives in the sibling
`superinstance-reef/` repo. It has a pre-rendered 90-second MP4/WebM
loop of the shell rendering this fixture's narrative arc
(casting off → contour → Gap opens → kintsugi fires → CoCapn
corrects → settled on the 50-fathom line). The hero plays muted,
autoplay, looped, with no WebSocket required — the demo never
breaks.

```
superinstance-reef/
├── index.html              # landing with the pre-rendered hero
├── demo.html               # live demo (embeds this shell in an iframe)
├── assets/
│   ├── digital-twin-demo.mp4   # 7.6 MB · h264 · 1600×900 · ~107s loop
│   ├── digital-twin-demo.webm  # 11 MB · vp9 fallback
│   ├── poster-gap.png          # used as the video poster
│   ├── poster-calm.png
│   └── poster-settled.png
├── README.md
└── LICENSE
```

The recording was made with Playwright driving this shell against
`sample-fixture-demo.jsonl`. To re-record it:

```bash
# 1. start the bridge with the demo fixture
DTS_BRIDGE_PORT=29500 PYTHONPATH=. \
  python -m digital_twin_shell.bridge --replay --loop \
  --fixture sample-fixture-demo.jsonl --hz 2.0 &

# 2. serve the shell
python -m http.server 8000

# 3. record (separate script; see ../superinstance-reef/_docs/)
playwright record --browser=chromium \
  --viewport-size=1600,900 --video-dir=tests/videos \
  http://127.0.0.1:8000/index.html?port=29500
```

## Gamified idle mode (`--simulate`)

When the system isn't being used for real fishing (no live sensor
data, no live vessel at the wheel), the bridge can run in
**simulator mode** and emit a procedural 7-act narrative through
the same WebSocket pipe. The shell renders it identically — the
renderer doesn't know whether the data is from a fixture file or
the simulator — but adds a GAMIFIED badge, a SCORE panel, a
MISSION banner, and achievement toasts on top of the same Three.js
scene.

```bash
# start the bridge in simulator mode
PYTHONPATH=. python -m digital_twin_shell.bridge --simulate \
  --sim-seed 42 --hz 2.0
# → ws://127.0.0.1:8765 is live, emitting a 7-act narrative
# → shell receives the same record shape as the fixture
# → GAMIFIED badge appears, score ticks up, missions complete
```

The acts progress by elapsed time. Each act has its own physics
(the autopilot fights different drift per act), CoCapn voice,
mission, and achievement:

| Act           | Duration | Mission                              | Achievement   |
|---------------|----------|--------------------------------------|---------------|
| DEPARTURE     | 15s      | Hold course 270°                     | First Steps   |
| APPROACH      | 20s      | Reach the 50-fathom line             | 50 Fathoms    |
| THE_GAP       | 25s      | Stay within 5° of 270°               | The Gap       |
| STORM         | 30s      | Stay within 10° of 270° during storm | Stormrider    |
| GHOST_FLEET   | 40s      | Maintain CPA > 0.5nm                 | Mariner       |
| WHALE         | 40s      | Slow to 3kt, hold 30s                | Whale Watcher |
| WRECK         | 50s      | Log the wreck position               | Hydrographer  |
| SETTLED       | ∞        | Standing by                          | Reefwalker    |

Scoring: +10 per kintsugi seam, +5/sec on-course, +200 per mission
completed, +500 per achievement, -1/sec off-course. See
`tests/test_simulator.py` for the full contract.

The simulator is a single Python file (`digital_twin_shell/simulator.py`,
~25 KB, no external dependencies). Records emitted match the JSONL
fixture schema, so adding `--simulate` did not require any changes
to the renderer.

## The visual vocabulary

Every visible element ties back to a piece of the lore. The lore lives
in `gitage17.md`, `gitage18.md`, and `gitage19.md`. The mapping:

| Scene element | Lore reference | Render rule |
| ------------- | -------------- | ----------- |
| The boat at the origin | The Captain's avatar | Procedural hull, paper-white, gentle bob, gold masthead dot |
| The three ghost-ships (Cormorant, Meridian, Resolute) | The Fleet — *"the constellation of lights on the horizon"* | Teal hulls, distance fade, name label |
| The fuzzy circle overlay when `deadband.heading_ok = false` or `bathy.contour_50fathom = false` | The Gap — *"the scene's aperture, where creativity lives"* | Additive radial gradient + animated noise, rendered **proud** |
| Gold-orange seams at `|depth_m - bathy.depth_m| > 2.0` | Kintsugi — *"scars-as-decoration, the system is stronger for its breaks"* | Torus rings with gold gradient, additive blending |
| Top-right agent panel in serif italic | CoCapn's voice | Updates only on stream events (not every frame) |
| Bottom-right sparkline | Validator's law — γ + η ≤ C | Headroom over time, broken-state highlight |
| HUD bottom-left | The Captain's view | Tabular monospace numerics |
| Connection indicator top-right | LIVE / FIXTURE / OFFLINE | Color-coded dot, brass on FIXTURE |

The visual goal: **render the reef proud, not apologetically.** Gaps
and seams are features of the world, not warnings. The Captain's job is
to tend them.

## Repository layout

```
digital-twin-shell/
├── index.html                  # the entire scene, single file
├── sample-fixture.jsonl        # 120 records, 2 min @ 1 Hz (the "smoke" fixture)
├── sample-fixture-demo.jsonl   # 180 records, 90s @ 2 Hz (the demo narrative)
├── digital_twin_shell/         # Python package
│   ├── __init__.py
│   ├── cocapn_contract.py      # parses contracts/contract_projection.rs
│   ├── bridge.py               # WS server + JSONL reader
│   ├── config.py               # env-var configuration
│   ├── http_control.py         # /healthz + /metrics
│   ├── logging_setup.py        # JSON or text logging
│   └── gen_fixture.py          # regenerates the bundled fixture
├── contracts/
│   └── contract_projection.rs  # canonical Rust source for the wire contract
├── tests/
│   ├── test_smoke.py           # contract + replay roundtrip
│   ├── test_index.py           # HTML health (Playwright → curl)
│   ├── test_config.py          # env-var configuration
│   ├── test_http_control.py    # health/metrics endpoints
│   ├── test_logging.py         # JSON / text log formats
│   ├── test_shutdown.py        # graceful shutdown contract
│   ├── test_integration.py     # bridge + fixture end-to-end
│   ├── screenshots/            # captured proofs
│   └── videos/                 # pre-rendered demo recording (mp4/webm + posters)
├── bin/
│   ├── dev.sh                  # one-shot dev launcher
│   └── demo.sh                 # one-shot demo launcher (auto token + browser)
├── pyproject.toml              # websockets>=12 + pytest
├── Dockerfile
├── service-worker.js           # PWA cache + WS bypass
├── manifest.webmanifest
├── README.md                   # ← you are here
├── AGENT.md                    # onboarding for any future agent
├── AGENTS.md                   # the agent architecture in the scene
├── ARCHITECTURE.md             # dataflow diagram
├── STATE.md                    # what works, what doesn't, what's next
├── CONTRACT.md                 # the JSON wire format (signed off)
├── memory/                     # onboarding tiles
└── LICENSE                     # Apache-2.0 (same as cocapn-marine family)
```

## Tests

```bash
python tests/test_smoke.py    # contract + WS roundtrip
python tests/test_index.py    # HTML health (Playwright → curl fallback)
```

`test_smoke.py` asserts the JSON contract matches `cocapn-marine`'s
serde field names exactly, replays the fixture for ≥5 records, and
verifies the WS server emits to a connected client.

`test_index.py` tries to install Playwright headless Chromium; if it
can, it loads the page and takes a screenshot. If it can't, it falls
back to a curl-based smoke test that asserts the served HTML contains
the canvas, the Three.js CDN script tag, the WS endpoint, the legend,
and the agent panel.

## Reproducibility

A fresh clone needs only:

```bash
pip install websockets      # optional — stdlib fallback works without it
./bin/dev.sh
```

…and the page opens at `http://localhost:8000/index.html`. No node,
no React, no build, no auth, no telemetry.

## License

Apache-2.0. See [LICENSE](LICENSE).

## Credits

Lore by Casey (gitage17/18/19). Code by Coder. Both subject to revision
by whoever picks this up next.
---

# Operations (production)

This section covers everything a deployer needs to run the bridge as a
real service, not a demo.

## Environment variables

| Variable | Default | Description |
| --- | --- | --- |
| `DTS_BRIDGE_HOST` | `0.0.0.0` | Bind address for the WebSocket data plane. |
| `DTS_BRIDGE_PORT` | `8765` | Bind port for the WebSocket data plane. |
| `DTS_HEALTH_PORT` | bridge+1 | Bind port for the HTTP control plane (`/healthz`, `/metrics`). |
| `DTS_BRIDGE_FIXTURE` | `sample-fixture.jsonl` | Path to the JSONL fixture to replay. |
| `DTS_BRIDGE_HZ` | `1.0` | Records per second to broadcast. |
| `DTS_LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR`. |
| `DTS_LOG_FORMAT` | `json` | `json` for machine-readable, `text` for humans. |
| `DTS_AUTH_TOKEN` | (empty) | When set, WS clients must present this token (subprotocol or `?token=`). Empty = no auth. |
| `DTS_ALLOWED_ORIGINS` | `*` | Comma-separated `Origin` whitelist for WS handshake and HTTP control. |
| `DTS_TLS_CERT` | (empty) | Path to a PEM cert for the WS server (enables WSS). |
| `DTS_TLS_KEY` | (empty) | Path to a PEM key for the WS server. |
| `DTS_TLS_CERT_HEALTH` | (empty) | Optional separate cert for the health/metrics port. |
| `DTS_TLS_KEY_HEALTH` | (empty) | Optional separate key for the health/metrics port. |
| `DTS_MAX_CLIENTS` | `64` | Refuse new WS clients beyond this. |
| `DTS_MAX_FRAME_BYTES` | `65536` | Reject any incoming client message larger than this (close 1008). |
| `DTS_MAX_MESSAGES_PER_SEC` | `10` | Per-client rate limit; exceeding it closes the connection (1008). |
| `DTS_WATCHDOG_TIMEOUT_S` | `10` | If no upstream frame for this many seconds, `/healthz` flips to `degraded` (HTTP 503). |
| `DTS_ENV` | `dev` | Set to `production` to require `DTS_AUTH_TOKEN` at startup (refuses to boot without it). |
| `DTS_TELEMETRY_ENDPOINT` | (empty) | Optional URL for the renderer to POST telemetry beacons to. |

## Run modes

### Dev mode (no auth, fixture-only, no TLS)

```bash
PYTHONPATH=. python -m digital_twin_shell.bridge \
  --replay --fixture sample-fixture.jsonl
python -m http.server 8000
# open http://localhost:8000/index.html
```

### Demo mode (random token, one command)

```bash
./bin/demo.sh
# prints: Bridge is live. Demo URL (paste into your browser):
#         http://127.0.0.1:8000/index.html?token=<random>
#         Auth token: <random>
```

### Production mode (auth, structured logs, no TLS)

```bash
export DTS_ENV=production
export DTS_AUTH_TOKEN="$(openssl rand -hex 24)"
export DTS_LOG_FORMAT=json
export DTS_ALLOWED_ORIGINS="https://twin.example.com"
PYTHONPATH=. python -m digital_twin_shell.bridge \
  --replay --fixture /var/lib/dts/fixture.jsonl
```

### Production with WSS

```bash
export DTS_TLS_CERT=/etc/dts/tls.crt
export DTS_TLS_KEY=/etc/dts/tls.key
PYTHONPATH=. python -m digital_twin_shell.bridge --replay
```

### Container

```bash
docker build -t dts:prod .
docker run --rm \
  -e DTS_ENV=production \
  -e DTS_AUTH_TOKEN="$(openssl rand -hex 24)" \
  -e DTS_TLS_CERT=/etc/dts/tls.crt \
  -e DTS_TLS_KEY=/etc/dts/tls.key \
  -v /etc/dts:/etc/dts:ro \
  -v /var/lib/dts:/var/lib/dts:ro \
  -p 8765:8765 -p 8766:8766 \
  dts:prod
```

The image has `HEALTHCHECK CMD` against `/healthz` on the health port,
so `docker ps` shows healthy/unhealthy automatically.

## Health and metrics

`/healthz` (HTTP, `DTS_HEALTH_PORT`):

```json
{
  "status": "ok",
  "state": "STREAMING",
  "uptime_s": 12345.6,
  "last_frame_age_s": 0.7,
  "clients": 3,
  "frames_sent": 12340
}
```

Returns **200** when `state == "STREAMING"` AND `last_frame_age_s <
DTS_WATCHDOG_TIMEOUT_S`. Otherwise returns **503** with `status:
"degraded"`.

`/metrics` (HTTP, `DTS_HEALTH_PORT`, Prometheus text format):

| Series | Type | Meaning |
| --- | --- | --- |
| `dts_frames_sent_total` | counter | Records broadcast to all WS clients. |
| `dts_clients_connected` | gauge | Currently connected WS clients. |
| `dts_errors_total{kind=...}` | counter | Bridge errors, labeled by category. |
| `dts_last_frame_age_seconds` | gauge | Seconds since the last upstream frame. |
| `dts_fixture_progress` | gauge | Fraction of the fixture consumed (0..1). |
| `dts_state_info{state=...}` | gauge | Current state (`STREAMING` is the live one). |

## WebSocket auth

Two ways for a client to present the token:

1. **Subprotocol header** — `Sec-WebSocket-Protocol: dts-token.<token>`
2. **Query string** — `ws://host:port/?token=<token>`

Both are accepted; pick whichever your client makes easier.

## Graceful shutdown

Send `SIGTERM` (or `SIGINT`). The bridge:

1. Logs `signal received; draining` at INFO
2. Stops accepting new clients
3. Sends `{"type":"shutdown","ts":"..."}` to every connected client
4. Waits up to 5 seconds for clients to close cleanly
5. Exits 0

The renderer handles the shutdown frame by transitioning to a distinct
`SHUTDOWN` connection state (separate from `OFFLINE`) and does **not**
attempt to reconnect.

## Troubleshooting

| Symptom | Log line to grep for | Fix |
| --- | --- | --- |
| Bridge refuses to start with "auth required in production" | `auth required in production` | Set `DTS_AUTH_TOKEN` or unset `DTS_ENV=production` |
| Clients get 401 immediately | `rejected: missing token` | Client must send the `DTS_AUTH_TOKEN` via subprotocol or `?token=` |
| `/healthz` returns 503 | `watchdog tripped` or `state=DRAINING` | Check upstream feed; restart if needed |
| Bridge exits 0 mid-flight | `shutdown complete` | Normal — this is a SIGTERM-triggered drain |
| Client gets closed with code 1008 | `rate limit exceeded` or `frame too large` | Client is sending too fast or too big — see `DTS_MAX_MESSAGES_PER_SEC` and `DTS_MAX_FRAME_BYTES` |
| Origin rejected | `rejected: origin` | Add the origin to `DTS_ALLOWED_ORIGINS` |
| Port already in use | `bind: address already in use` | Change `DTS_BRIDGE_PORT` or `DTS_HEALTH_PORT` |
| Static assets 404 on the page | n/a (browser console) | `manifest.webmanifest` and `service-worker.js` must be served at the static root, not under `static/` |

## Production checklist

- [ ] `DTS_ENV=production` is set
- [ ] `DTS_AUTH_TOKEN` is set to a random ≥ 24-char value, rotated periodically
- [ ] `DTS_ALLOWED_ORIGINS` is restricted to known hostnames
- [ ] `DTS_LOG_FORMAT=json` so log shippers can parse
- [ ] `DTS_LOG_LEVEL=INFO` (or `WARNING` for high-traffic)
- [ ] `DTS_TLS_CERT` and `DTS_TLS_KEY` point to valid certs
- [ ] `DTS_WATCHDOG_TIMEOUT_S` is set to something tighter than the upstream feed's worst-case stall
- [ ] Container health check is bound to `/healthz`
- [ ] `/metrics` is scraped by Prometheus (or your equivalent) at ≤ 30s intervals
- [ ] Log shipping is configured to capture both `stdout` and `stderr`
- [ ] WS clients present the token via subprotocol or `?token=`
