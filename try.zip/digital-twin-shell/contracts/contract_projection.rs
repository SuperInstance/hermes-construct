// contracts/cocapn_marine_snapshot.rs
//
// =====================================================================
// HAND-COMPOSED CONTRACT PROJECTION — digital-twin-shell ↔ cocapn-marine
// =====================================================================
//
// This file is a HAND-COMPOSED PROJECTION of cocapn-marine's existing
// public types. It is NOT a vendored copy of any upstream struct.
// cocapn-marine has no Snapshot type today. This struct aggregates
// field names from cocapn-marine's existing public types:
//
//   NmeaMessage::Gga(GgaData)        → vessel.lat, vessel.lon
//   NmeaMessage::Vhw (when parsed)   → vessel.heading_deg, vessel.sog_knots
//   AutopilotOutput                  → rudder_command_deg
//   BathyDatabase::depth_at()        → depth_m, bathy.contour_50fathom
//   HeadingDeadband::check()         → deadband.heading_ok
//   DepthDeadband::check()           → deadband.depth_ok
//   SpeedDeadband::check_high/low()  → deadband.speed_ok
//
// Both the bridge and the smoke test parse this file at runtime —
// neither hardcodes field names. The upstream source files
// (sensor.rs, autopilot.rs, bathy.rs, deadband.rs) are cross-checked
// in the smoke test for verbatim matches.
//
// Every field in `Snapshot` here is either a verbatim reference to a
// cocapn-marine public field (see the test trace in
// tests/test_smoke.py) OR an extension documented in CONTRACT.md.
//
// When cocapn-marine upstream adds a real `Snapshot` struct, replace
// this file with a symlink to it. The parsers will pick up the new
// source automatically.
//
// Verbatim from the task brief:
//
//   vessel: { lat: f64, lon: f64, heading_deg: f64, sog_knots: f64, cog_deg: f64 }
//   depth_m: Option<f64>
//   rudder_command_deg: f64
//   autopilot: { on_course: bool, target_heading_deg: f64 }
//   bathy: { depth_m: f64, contour_50fathom: bool }
//   deadband: { heading_ok: bool, depth_ok: bool, speed_ok: bool }
//   timestamp: ISO 8601
//
// Optional extension keys (NOT in the cocapn-marine upstream types,
// added by the bridge for the rendered scene):
//
//   fleet[]:      { name: string, lat, lon, heading_deg }
//   agent:        { speaker: string, text: string }
//   conservation: { gamma, eta, C, headroom }

#![allow(dead_code)]
#![cfg_attr(feature = "no_std", no_std)]

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// The vessel's pose and motion at one instant. Mirrors the `vessel`
/// field inside `Snapshot`.
///
/// Field names (lat, lon, heading_deg, sog_knots, cog_deg) are the JSON
/// keys that appear on the wire when cocapn-marine serializes with serde.
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct Vessel {
    /// Latitude in decimal degrees, north-positive. From the brief: `lat: f64`.
    pub lat: f64,
    /// Longitude in decimal degrees, east-positive. From the brief: `lon: f64`.
    pub lon: f64,
    /// True heading in degrees, 0=N, 90=E, 180=S, 270=W. From the brief: `heading_deg: f64`.
    pub heading_deg: f64,
    /// Speed over ground in knots. From the brief: `sog_knots: f64`.
    pub sog_knots: f64,
    /// Course over ground in degrees. From the brief: `cog_deg: f64`.
    pub cog_deg: f64,
}

/// The autopilot state. From the brief: `autopilot: { on_course: bool, target_heading_deg: f64 }`.
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct Autopilot {
    /// True iff the autopilot is currently tracking its target heading.
    pub on_course: bool,
    /// The heading the autopilot is trying to hold, in degrees.
    pub target_heading_deg: f64,
}

/// The bathymetry model in use. From the brief: `bathy: { depth_m: f64, contour_50fathom: bool }`.
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct Bathy {
    /// Depth at the boat's current position, in meters.
    pub depth_m: f64,
    /// True iff the boat is on the 50-fathom (~91.4 m) shelf edge.
    pub contour_50fathom: bool,
}

/// The deadband state — three booleans indicating which channels are healthy.
/// From the brief: `deadband: { heading_ok: bool, depth_ok: bool, speed_ok: bool }`.
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct Deadband {
    /// Heading confidence is high.
    pub heading_ok: bool,
    /// Depth confidence is high.
    pub depth_ok: bool,
    /// Speed confidence is high.
    pub speed_ok: bool,
}

/// The full snapshot. This is what `cocapn-marine` serializes to JSON
/// when the `serde` feature is on, with field names verbatim from the brief.
///
/// Field names (in this order in the struct definition):
///   vessel, depth_m, rudder_command_deg, autopilot, bathy, deadband, timestamp
#[cfg_attr(feature = "serde", derive(Serialize, Deserialize))]
pub struct ContractProjection {
    /// Vessel pose and motion.
    pub vessel: Vessel,
    /// Live sounder depth, in meters. None if no sounder reading available.
    /// From the brief: `depth_m: Option<f64>`.
    pub depth_m: Option<f64>,
    /// Commanded rudder angle in degrees. From the brief: `rudder_command_deg: f64`.
    pub rudder_command_deg: f64,
    /// Autopilot state.
    pub autopilot: Autopilot,
    /// Bathymetry at the boat.
    pub bathy: Bathy,
    /// Deadband health.
    pub deadband: Deadband,
    /// ISO 8601 timestamp at which the snapshot was taken.
    pub timestamp: String, // ISO 8601
}