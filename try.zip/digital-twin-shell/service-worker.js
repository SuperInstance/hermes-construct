// service-worker.js — cache-first shell, network-only for the WS endpoint.
//
// Responsibilities:
//   1. On install: pre-cache the static shell (index.html, three.js bundles).
//   2. On fetch: serve from cache when present; fall through to network.
//   3. Never intercept the WS upgrade — the bridge MUST be live.
//   4. Accept a SKIP_WAITING message so a future deploy can force the
//      new SW to take over without waiting for all tabs to close.
//
// Cache version bumps force a clean refresh: change CACHE_NAME and the
// activate handler evicts the old caches.

/* global self, clients */

const CACHE_NAME = "dts-shell-v1";

// Minimal shell.  Add to this list as more files become static.
const PRECACHE = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./telemetry.js",
  // Three.js CDN bundles — pinned versions, the same ones index.html
  // loads.  Pre-caching them makes the page work offline-after-first-
  // load.  The browser's HTTP cache would catch them too, but having
  // them in the SW cache means the first offline visit works.
  "https://unpkg.com/three@0.147.0/build/three.min.js",
  "https://unpkg.com/three@0.147.0/examples/js/controls/OrbitControls.js",
];

// --- install --------------------------------------------------------------

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      // addAll is atomic — if any URL fails the whole install fails and
      // the SW stays in the previous state.  That's what we want for
      // a production deploy: either the shell is complete or we don't
      // claim to be the active worker.
      cache.addAll(PRECACHE).catch((err) => {
        // The CDN may be unreachable during install (e.g. behind a
        // corporate proxy).  Don't let a transient CDN outage break
        // install; log and continue with whatever DID land in the cache.
        // eslint-disable-next-line no-console
        console.warn("[sw] precache partial:", err && err.message);
        return null;
      })
    )
  );
  // Activate immediately when the operator calls postMessage({type:'SKIP_WAITING'}).
  self.skipWaiting();
});

// --- activate -------------------------------------------------------------

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      );
      // Take control of open clients without a reload.
      await self.clients.claim();
    })()
  );
});

// --- message channel (SKIP_WAITING) --------------------------------------

self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
  if (data.type === "CACHE_STATS") {
    event.ports[0] && event.ports[0].postMessage({ type: "CACHE_STATS_OK" });
  }
});

// --- fetch ----------------------------------------------------------------

self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Only handle GET — anything else (POST, PUT, …) passes through.
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // WebSocket upgrades MUST reach the network untouched.  Even if
  // we have an HTML page cached, the WS handshake has to be live.
  if (req.headers.get("Upgrade") === "websocket") return;
  // The WS endpoint may be served over plain http(s) and upgraded; if
  // the path looks like a WS endpoint, also pass through.
  if (url.pathname === "/ws" || url.pathname.endsWith("/ws/")) return;
  // Same-origin /healthz, /metrics: always live (they tell the operator
  // what's happening RIGHT NOW).
  if (url.pathname === "/healthz" || url.pathname === "/metrics") return;

  // Cache-first for everything else.
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      const hit = await cache.match(req, { ignoreSearch: false });
      if (hit) {
        // Refresh in the background (stale-while-revalidate flavour).
        event.waitUntil(
          fetch(req)
            .then((res) => {
              if (res && res.status === 200) cache.put(req, res.clone());
            })
            .catch(() => {
              /* offline; keep the cached copy */
            })
        );
        return hit;
      }
      try {
        const res = await fetch(req);
        if (res && res.status === 200 && url.origin === self.location.origin) {
          cache.put(req, res.clone());
        }
        return res;
      } catch (err) {
        // Network failed and we have no cache entry.  Return a tiny
        // offline shim so the page can render a graceful "you're
        // offline" message.
        return new Response(
          "<!doctype html><meta charset=utf-8><title>offline</title>" +
            "<body style=\"background:#0b0d11;color:#e8e1d1;font-family:sans-serif;" +
            "padding:24px\"><h1>offline</h1><p>The digital-twin shell is not " +
            "in the local cache and the network is unreachable. Reconnect " +
            "and try again.</p></body>",
          { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } }
        );
      }
    })()
  );
});
