# CONTRACT.md — the JSON wire format

This document is the signed contract between `cocapn-marine`'s eventual
I/O layer and the digital-twin-shell bridge. Both sides must accept
records shaped exactly like the example below.

**Source of truth:** `contracts/contract_projection.rs`. This is a
**hand-composed contract projection** that aggregates field names from
cocan-marine's existing public types (`NmeaMessage::Gga(GgaData)`,
`AutopilotOutput`, `BathyDatabase`, `HeadingDeadband`/`DepthDeadband`/
`SpeedDeadband`). It is **not** a vendored copy of any upstream struct —
cocapn-marine has no `Snapshot` type today. The Python bridge parses it
at startup (via `digital_twin_shell.cocapn_contract`), and the smoke
test parses it directly (in
`tests/test_smoke.py::test_contract_keys_match_cocapn_marine`). Neither
piece of Python code hardcodes field names — they all come from this
file. The smoke test additionally cross-checks the field names against
cocapn-marine's actual upstream source (`sensor.rs`, `autopilot.rs`,
`bathy.rs`, `deadband.rs`) to confirm they are real verbatim references.

## Schema (top level)

Every record is one JSON object with these top-level keys:

| Key | Type | Required | Notes |
| --- | ---- | -------- | ----- |
| `vessel` | object | yes | `{lat, lon, heading_deg, sog_knots, cog_deg}` |
| `depth_m` | number \| null | yes | Live sounder depth in meters; null if unavailable |
| `rudder_command_deg` | number | yes | Commanded rudder angle, degrees |
| `autopilot` | object | yes | `{on_course: bool, target_heading_deg: f64}` |
| `bathy` | object | yes | `{depth_m: f64, contour_50fathom: bool}` |
| `deadband` | object | yes | `{heading_ok: bool, depth_ok: bool, speed_ok: bool}` |
| `timestamp` | string (ISO 8601) | yes | e.g. `2026-07-10T12:00:00Z` |
| `fleet` | array\<object\> | optional | Each: `{name, lat, lon, heading_deg}` |
| `agent` | object | optional | `{speaker: string, text: string}` — CoCapn's voice line |
| `conservation` | object | optional | `{gamma, eta, C, headroom}` |

## Example record

```json
{
  "vessel": {
    "lat": 57.2333,
    "lon": -150.45,
    "heading_deg": 270.0,
    "sog_knots": 6.2,
    "cog_deg": 270.0
  },
  "depth_m": 92.6,
  "rudder_command_deg": 0.0,
  "autopilot": {
    "on_course": true,
    "target_heading_deg": 270.0
  },
  "bathy": {
    "depth_m": 92.0,
    "contour_50fathom": true
  },
  "deadband": {
    "heading_ok": true,
    "depth_ok": true,
    "speed_ok": true
  },
  "timestamp": "2026-07-10T12:00:00Z",
  "fleet": [
    {"name": "Cormorant", "lat": 57.287361, "lon": -150.578517, "heading_deg": 266.34},
    {"name": "Meridian",  "lat": 57.193413, "lon": -150.294344, "heading_deg": 270.16},
    {"name": "Resolute",  "lat": 57.31064,  "lon": -150.366017, "heading_deg": 264.04}
  ],
  "conservation": {"gamma": 0.86, "eta": 0.08, "C": 1.0, "headroom": 0.06},
  "agent": {
    "speaker": "CoCapn",
    "text": "CoCapn: course 270°, rudder 0.0°, on course."
  }
}
```

## Semantics

* **`vessel.heading_deg`**: 0 = north, 90 = east, 180 = south, 270 = west.
  The renderer rotates the boat so its bow points along this heading.
* **`autopilot.on_course`**: true iff the autopilot believes it is
  currently tracking the target heading. False means a gap is forming.
* **`bathy.contour_50fathom`**: true iff the boat is on the 50-fathom
  (~91.4 m) shelf edge. False = drift onto shallower water = a Gap
  opens.
* **`deadband`**: the three booleans are independent. A frame with
  `heading_ok = false` AND `depth_ok = true` means only heading
  confidence is degraded; depth confidence is fine. The renderer
  treats *any* false as Gap-opening.
* **`depth_m - bathy.depth_m > 2.0`** triggers a kintsugi seam at that
  frame. The seam is rendered as a gold torus ring on the ocean plane,
  offset from the boat so the boat never overlaps it.
* **`fleet`**: each ghost ship carries its current lat/lon/heading.
  The renderer converts to scene units (1 nm = ~1.67 units) and
  positions the ghost relative to the vessel.
* **`agent`**: the rate is bounded upstream — the bridge should not
  emit `agent` on every frame, only when CoCapn has something to say.
* **`conservation`**: γ (productive signal) + η (loss) ≤ C (capacity).
  The sparkline plots the headroom (= C - γ - η) over time.

## Transport

* One record per WebSocket text frame.
* JSON, no trailing whitespace, `separators=(",", ":")`.
* 1 Hz cadence is the default; the bridge honors `--hz`.

## Versioning

This is contract v1. Future versions will be marked with a top-level
`"v": 1` field once the field count grows past what fits in one
shippable schema.