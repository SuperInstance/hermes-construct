# STATE.md — what works today, what doesn't, what's next

## What works today

* `digital_twin_shell.bridge` reads a JSONL fixture at 1 Hz and
  broadcasts to all connected WebSocket clients. Verified end-to-end
  by `tests/test_smoke.py`.
* The `websockets` library is preferred when available; a stdlib-only
  fallback implements just enough of RFC 6455 (text frames, single
  client) for the demo. The choice is logged at startup.
* `index.html` opens in any modern browser, no build step. Three.js
  r161 + OrbitControls are loaded from a pinned CDN.
* The rendered scene includes (Three.js r147 via CDN):
  * a procedurally-shaded ocean plane (sinusoidal swell + foam noise)
  * a procedural hull boat at the origin, heading-rotated
  * three teal ghost-ships (Cormorant, Meridian, Resolute) drifting
    around the boat with distance fade
  * a fuzzy-circle Gap overlay when `deadband.heading_ok = false` or
    `bathy.contour_50fathom = false`
  * gold-orange kintsugi seams on the ocean plane when
    `|depth_m - bathy.depth_m| > 2.0 m`
  * a translucent agent panel (top-right) with CoCapn's voice in the
    lore's serif italic — updated on stream events, not every frame
  * a HUD (bottom-left) showing vessel pose
  * a conservation sparkline (bottom-right) for γ + η ≤ C
  * a connection indicator (top-right) showing LIVE / FIXTURE / OFFLINE
* `bin/dev.sh` brings up the bridge + a static server + opens the
  browser in one shot. Cross-platform (`python3` vs `python`,
  `xdg-open` vs `open` vs `webbrowser`).
* `tests/test_index.py` either takes a Playwright screenshot or falls
  back to a curl-based smoke test (proving the served HTML contains
  the canvas, the CDN script tag, the WS endpoint, the legend, and
  the agent panel).

## What doesn't work today

* `cocapn-marine` has no I/O. The bridge consumes a hand-curated
  fixture, not a live stream from the Rust crate. The fixture is
  shaped to match the signed-off contract — see `CONTRACT.md` — so
  the swap will be one CLI flag when the I/O layer lands.
* The renderer is single-file Three.js with no asset pipeline; the
  Three.js scene is the demo-grade spine, not a final visual.
* Load testing, axe-core accessibility audit, and Playwright
  service-worker offline test are not in the smoke suite yet.
  Documented as the next-wave backlog in `deliverable.md`.
* The Three.js scene is *good*, but it is **not** Unreal 5. The hull
  is procedural box geometry; the ocean is a plane with a fragment
  shader; the ghost ships are clones. There is no PBR, no ocean
  FFT, no foam particles.
* No headless screenshot was captured in this environment (no
  browser). `test_index.py` will use Playwright if available and
  fall back to a curl smoke test otherwise. The fallback log is
  saved to `tests/screenshots/curl-smoke.log`.
* The kintsugi seam rendering is *intentionally* a torus with a
  gold texture — it's a scar-as-decoration, not a geometry-correct
  fault line. A future agent may want to replace it with a heightmap
  perturbation of the ocean plane.
* The ghost-ship labels are DOM overlays projected via manual math;
  no `CSS2DRenderer`. This is intentional (no extra dependency) but
  not as crisp as a proper renderer.
* No Starlink-mediated fleet sync. The fleet is rendered from a
  single JSON stream.

## What's next

The digital twin now has a visible shell. The next step is wiring
cocapn-marine's eventual I/O layer through this bridge and adding
the Unreal 5 backend for higher fidelity rendering.

Concretely, the next three tasks for whoever picks this up:

1. **Wire `cocapn-marine`'s I/O.** Add a `cocapn-marine --stream`
   subcommand that emits one JSON snapshot per second to stdout,
   matching the contract in `CONTRACT.md`. Then change the bridge
   CLI to default to `--pipe <(cocapn-marine --stream)` and add a
   `--fixture` fallback for tests.

2. **Port the visual layer to an Unreal 5 module.** The current
   Three.js scene is enough for a bridge laptop, but it's not enough
   for the long view. UE5 gets us proper ocean FFT, PBR, and the
   option to drop the rendered scene into a VR headset for the
   Captain. The contract stays the same; only the renderer changes.

3. **Add Starlink-mediated fleet sync.** Right now each boat runs
   its own bridge. The reef metaphor demands that they share data.
   When Boat 3 detects a gap, Boat 7 should see it. The schema
   already supports a `fleet` array — extend it to allow live
   push-from-peer updates, and let the bridge subscribe to a
   Starlink-mediated multicast.

## Round 4 — public site (the-reef)

The shell now has a polished public-facing site at the sibling
`superinstance-reef/` repo. The site is a single static page
(`index.html` + 21 MB of video assets) that embeds a pre-rendered
90-second loop of the shell's narrative arc. The recording was made
with Playwright driving this shell against a new hand-authored
fixture `sample-fixture-demo.jsonl` (180 records, 90s @ 2 Hz) which
walks the boat through casting off → contour approach → Gap opens
(heading drift) → kintsugi seams fire → CoCapn corrects → settled
on the 50-fathom line.

* `tests/videos/digital-twin-demo.mp4` (7.6 MB, h264) — the hero
* `tests/videos/digital-twin-demo.webm` (11 MB, vp9) — fallback
* `tests/videos/poster-gap.png` (the gap/kintsugi moment, 1.1 MB)
* `tests/videos/poster-calm.png` (calm departure, 330 KB)
* `tests/videos/poster-settled.png` (settled on station, 850 KB)

The landing page hero is `autoplay muted loop playsinline`; some
browsers (e.g. iOS Safari without user gesture) require a click,
and the page shows a play button as the fallback. The page never
breaks because there is no backend dependency — the pre-rendered
video is the demo.

A second page, `superinstance-reef/demo.html`, embeds this shell
in an iframe with a status bar at the top that surfaces the shell's
`window.__digitalTwin.getConnState()` value via cross-frame polling.
For local dev it points at `../digital-twin-shell/index.html`;
for production it should be edited to point at the shell's hosted
URL.

## Open questions

* Should the Gap be clickable? (Currently no.) If yes, what does the
  click do — open a side panel with CoCapn's suggestions, or send a
  Scout?
* Should the kintsugi seams persist across sessions? (Currently they
  fade after 12 s.) Persistence would mean a per-boat log of "golden
  repairs."
* Should the Captain have an avatar in the scene? (Currently the
  boat IS the Captain.)
* Should the gamified simulator auto-launch when no live sensor
  data is present? (Currently it requires `--simulate`.) Auto-launch
  is a one-liner: a watchdog that flips the source after
  `DTS_IDLE_S` seconds of zero traffic. Not wired yet — the demo
  site just runs both modes side by side.
* Should the simulator record show the full 220s story? (Currently
  the demo recording is 200s; WRECK + SETTLED are missing.) A
  longer recording would push the file size past 30 MB.
---

## Round 5 — instruments + gamified simulator

The shell now reads 6 new instrument record types from the bridge
stream — wind, GPS, engine, depth sounder, compass, weather, VHF —
and renders them as 5 new HTML panels (wind dial, GPS badge,
barometer, engine readout, AIS list) plus a transient VHF radio
chatter popup. The bridge emits them from a hand-authored
`sample-fixture-demo.jsonl` (180 records, 90s, 2 Hz) or from the
new procedural simulator.

The simulator is a state machine in `digital_twin_shell/simulator.py`
that runs when `bridge --simulate` is passed. 8 acts, each with
its own physics, voice, mission, and achievement unlock. The
shell renders simulator output identically to fixture output, but
overlays a GAMIFIED badge, SCORE panel, MISSION banner, and
achievement toasts. Total cost to renderer: ~120 LoC of HTML/CSS/JS
additions, no Three.js changes.

* `digital_twin_shell/simulator.py` (~25 KB)
* `tests/test_simulator.py` (9/9 passing)
* `--simulate` and `--sim-seed` flags on the bridge
* New HTML panels: `wind`, `gps`, `baro`, `vhf`, `ais`, `engine`
* New gamified UI: `game-badge`, `score-panel`, `mission`, `achievements`
* Sample-fixture updated: 17 fields per record (was 9)

The site at `superinstance-reef/` grew a `play.html` page and a
new "Bridge" section on the landing that shows a 2x2 grid of the
four pre-rendered views (shell, chart, radar, simulator). Total
site size: 82 MB (mostly the four pre-rendered MP4s).

---

## Round 3 — production hardening (post-cancel pickup)

The shell now has 14 env-driven tunables, structured JSON logging,
`/healthz` and `/metrics` on a separate control port, WS auth
(subprotocol or `?token=`), CORS, per-client rate limit, max frame
size, optional WSS, graceful SIGTERM-triggered shutdown that sends a
shutdown frame to clients, renderer retry with exponential backoff +
jitter, a distinct `SHUTDOWN` state in the UI, a service worker for
offline-resilient shell caching, a PWA manifest, CSP, ARIA labels,
`prefers-reduced-motion` respect, an opt-in telemetry hook, a
Dockerfile with HEALTHCHECK, and an Operations section in the README
covering env vars, four run modes, health/metrics, WS auth, graceful
shutdown, and a troubleshooting table with seven failure modes and
their fixes.

The smoke suite grew from 5 to 11 tests; all pass under
`python tests/test_smoke.py` with no pytest required. Run
`./bin/demo.sh` for a one-shot demo with auto-generated auth token.

The next three tasks for whoever picks this up:

1. **Wire `cocapn-marine`'s I/O.** Add a `cocapn-marine --stream`
   subcommand that emits one JSON snapshot per second to stdout,
   matching the contract in `CONTRACT.md`. Then change the bridge
   CLI to default to `--pipe <(cocapn-marine --stream)` and add a
   `--fixture` fallback for tests.

2. **Port the visual layer to an Unreal 5 module.** The current
   Three.js scene is enough for a bridge laptop, but it's not enough
   for the long view. UE5 gets us proper ocean FFT, PBR, and the
   option to drop the rendered scene into a VR headset for the
   Captain. The contract stays the same; only the renderer changes.

3. **Add Starlink-mediated fleet sync.** Right now each boat runs
   its own bridge. The reef metaphor demands that they share data.
   When Boat 3 detects a gap, Boat 7 should see it. The schema
   already supports a `fleet` array — extend it to allow live
   push-from-peer updates, and let the bridge subscribe to a
   Starlink-mediated multicast.
