# ARCHITECTURE.md

The digital-twin shell is a thin pipeline:

```
   cocapn-marine (Rust, no_std)            ← future: I/O layer
            │
            │  JSON snapshot  (serde → JSON)
            ▼
   ┌─────────────────────────┐
   │  bridge.py (Python)     │  ← reads JSONL fixture OR a future
   │  WebSocket server       │     live cocapn-marine stdout stream
   │  on 0.0.0.0:8765        │
   └─────────────────────────┘
            │
            │  one JSON record per WS text frame (1 Hz)
            ▼
   ┌─────────────────────────┐
   │  index.html (browser)   │  ← Three.js r161 via CDN
   │  Three.js / WebGL       │
   └─────────────────────────┘
            │
            ▼
   The Captain's bridge laptop screen
```

## Boundary contracts

There are three boundaries in this pipeline. Two are *clean contracts*,
one is *demo-grade*.

| Boundary | Status | Notes |
| -------- | ------ | ----- |
| `cocapn-marine` → `bridge.py` | **demo-grade** | The Rust crate has no I/O yet. The bridge currently consumes a hand-curated `sample-fixture.jsonl`. The fixture's JSON shape is signed off as the eventual cocapn-marine snapshot contract — see `CONTRACT.md`. |
| `bridge.py` → `index.html` | **clean contract** | One JSON record per WS text frame, 1 Hz, with a documented schema. The bridge validates records against `validate_record()` before broadcasting. The browser parses via `JSON.parse` and reads known keys. |
| `index.html` → the renderer | internal | Three.js scenegraph; not a contract, just code. |

## Component responsibilities

### cocapn-marine (Rust, future)

* Owns the truth about the boat (vessel pose, autopilot, rudder, deadband).
* Owns the bathymetry model.
* Serializes a `ContractProjection` to JSON when the `serde` feature is on.
* Has no I/O today. Will, eventually, write JSONL to stdout (or a UNIX
  socket) at 1 Hz, which the bridge consumes.

### bridge.py (Python, today)

* Reads a JSONL fixture (or a future live stream) at 1 Hz.
* Validates each record against the wire contract.
* Broadcasts to all connected WS clients.
* Falls back to a stdlib-only WS server if `websockets` isn't installed.
* No state, no DB. Stateless stream relay.

### index.html (browser, today)

* Three.js scene at the boat's origin (vessel is fixed; fleet drifts around it).
* HUD: vessel pose, depth, heading, rudder, on-course indicator.
* Agent panel: CoCapn's voice (rendered in serif italic; updates on stream
  events only, not every frame).
* Conservation sparkline: γ + η ≤ C, headroom over time.
* Three ghost-ships (Cormorant, Meridian, Resolute) with distance fade.
* Gap overlay (fuzzy circle) when the deadband or contour trips.
* Kintsugi seams (gold torus rings) when sounder diverges from chart.
* Gracefully degrades to OFFLINE state — freezes the last good scene, no
  console errors.

## What this is not

* It is not a game engine. It is not Unreal 5.
* It is not a real-time control system. It is a *twin* — a hypothesis
  rendered for the Captain to look at.
* It is not a simulator. The actual simulation lives in `cocapn-marine`;
  this is the visible shell of that simulation.

## The next layer

When `cocapn-marine`'s I/O lands, the bridge can switch from
`--fixture sample-fixture.jsonl` to `--pipe <(cocapn-marine --stream)`,
and the rendered scene stays the same. The contract is signed off in
`CONTRACT.md` and pinned in `contracts/contract_projection.rs`.

## The contract source

`contracts/contract_projection.rs` is a hand-composed contract projection that
aggregates field names from cocapn-marine's existing public types
(GgaData, AutopilotOutput, BathyDatabase, HeadingDeadband, etc.).
It is the authoritative source of the JSON wire format used by the
bridge. The Python bridge and the smoke test both parse this file at
startup; neither hardcodes field names.
When the upstream crate lands, replace this file with a symlink to the
real source — the parsers pick it up automatically.