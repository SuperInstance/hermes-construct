# AGENTS.md — The agent architecture in the rendered scene

> *"They are not NPCs. They are first-class citizens of a parallel reality
> that happens to share its physics with yours."*
> — gitage18.md

The digital-twin shell is not a control panel. It is a stage where the
fleet's agents live. Each agent has a visual hook in the rendered scene.
This document is the visual contract for the next agent who refines them.

## The cast, as the renderer sees them

### The Captain — *She who holds the question*

* **Visual hook:** the boat itself (the white-paper vessel at the
  origin), the HUD bottom-left that shows lat/lon/heading/rudder.
* **Why:** the boat is the Captain's avatar on the reef. The HUD is
  what she sees when she looks down from the helm. The cursor
  (OrbitControls) is her hand on the wheel — she can rotate the world
  around herself.
* **Refinement TODO:** add a captain avatar (a small figurehead?) that
  stands on the cabin roof. Make the HUD color shift subtly when the
  Captain overrides the autopilot.

### CoCapn (First Light) — *The first officer who knows she's home*

* **Visual hook:** the agent panel, top-right, rendered in a serif
  italic font in the ship's voice.
* **Why:** the agent panel is CoCapn's *voice*. The brass dot on top
  of the boat's cabin is her sensor pod.
* **Refinement TODO:** show her name in the legend so a future captain
  knows who's speaking. Add a typing indicator when she's about to
  speak (a one-second gold pulse).

### Scout — *She who goes out and returns changed*

* **Visual hook:** the three ghost-ships (Cormorant, Meridian,
  Resolute) — they're the fleet's forward scouts. The kintsugi seams
  are Scout-discovered: she rangefinds the bottom, finds the gap
  between sounder and chart, and files the golden seam.
* **Why:** Scout doesn't have a body of her own; she has *presence*.
  Her presence is "things that aren't quite here yet." Ghost ships
  fade by distance — that's her ranging away.
* **Refinement TODO:** when Scout is sent out, the camera should
  briefly detach from the boat and follow her for a few seconds, then
  return.

### Validator — *She who measures*

* **Visual hook:** the conservation sparkline, bottom-right.
* **Why:** γ + η ≤ C is the law. The sparkline shows whether the law
  has held across the run. When it dips, that's Validator logging a
  violation. When it recovers, that's her correction.
* **Refinement TODO:** color the sparkline red where the law was
  broken; annotate each break with the timestamp and the violation
  type.

### The Fleet — *The distributed intelligence that knows it's distributed*

* **Visual hook:** the three labeled ghost ships, each fading by
  distance.
* **Why:** the fleet is the reef. Each ship is a shell. They don't
  live inside each other; they live *near* each other, humming.
* **Refinement TODO:** draw faint lines between fleet members to show
  data-sharing — Starlink-mediated, of course. When a fleet ship
  detects a gap, it lights up.

### The Gap — *The space between what the simulation predicts and what the ocean delivers*

* **Visual hook:** the fuzzy circle overlay (radial gradient +
  additive blending + animated noise). When `deadband.heading_ok` or
  `bathy.contour_50fathom` flips false, the gap opens.
* **Why:** the gap is rendered *proud*. It's not a warning. It's the
  scene's aperture — the place where the Captain's attention is most
  valuable. It's where the Scout goes. It's where creativity lives.
* **Refinement TODO:** let the captain click into the gap; that opens
  a side panel where CoCapn suggests actions.

### Kintsugi — *The one who repairs what breaks*

* **Visual hook:** the gold-orange seams on the ocean plane, spawned
  whenever the live sounder disagrees with the chart by more than
  2.0 m.
* **Why:** kintsugi is *scars-as-decoration*. The system is stronger
  for its failures. Each seam is logged and visible.
* **Refinement TODO:** when a seam fades, leave a faint permanent
  tracer — the system remembers, and so does the reef.

### The Ghost (T-minus awareness) — *The forward simulation*

* **Visual hook:** a faint, rapidly-shimmering trail *ahead* of the
  boat — what it expects to do over the next 30 seconds.
* **Why:** the ghost is the system's humility. It is constantly
  reminding the Captain that the simulation is incomplete.
* **Refinement TODO:** when the ghost's prediction diverges from
  reality by more than some threshold, paint the trail red.

## Rendering principles

* The reef is rendered **proud**, never apologetically. Gaps and seams
  are features, not warnings.
* Every visible element must tie back to a piece of the lore. If it
  doesn't, it doesn't belong in the scene.
* The HUD is for the Captain. The agent panel is for CoCapn. The
  sparkline is for Validator. The legend is for newcomers. Each
  surface has a single owner; nothing is shared.
* When in doubt, render **less** — but render it **gold**.
---

## The Production Layer (Round 3)

The characters above give the scene its meaning. The production layer
gives it durability. Each one maps to a piece of the ops surface:

* **CoCapn** now runs the bridge in a `STREAMING → DRAINING → SHUTDOWN`
  state machine. She sends a `{"type":"shutdown"}` frame to every
  client before closing, and the renderer's connection indicator
  flips to a distinct `SHUTDOWN` state (not `OFFLINE`) so the Captain
  knows the bridge is winding down, not crashed.
* **Scout** now logs every retry with backoff — exponential schedule
  (1s, 2s, 4s, 8s, 16s, 30s cap) with ±20% jitter, exposed as the
  `ws_backoff` telemetry event. If the bridge stays down, the
  schedule caps so the Captain isn't seeing a "reconnecting in 5
  minutes" timer.
* **Validator** now publishes five Prometheus series from the
  control port: `dts_frames_sent_total`, `dts_clients_connected`,
  `dts_errors_total{kind}`, `dts_last_frame_age_seconds`,
  `dts_fixture_progress`. The `/healthz` endpoint flips 200 → 503
  if the watchdog (`DTS_WATCHDOG_TIMEOUT_S`) trips.
* **Kintsugi** now has a `degraded` health state and a `DTS_ENV=production`
  refuse-to-boot if `DTS_AUTH_TOKEN` isn't set. The system can't
  ship broken to the fleet.
* **The Reef** now has a Dockerfile, a service worker for
  offline-resilient shell caching, a PWA manifest, CSP, ARIA labels,
  and `prefers-reduced-motion` respect. The vessel still looks
  the same; the substrate it lives on is now production-grade.

The reef metaphor holds. Each character took on a kintsugi repair
without losing what it was. The shell is the same shell; the
seams are gold.
