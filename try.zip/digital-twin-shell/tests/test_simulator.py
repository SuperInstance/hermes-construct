"""
test_simulator.py — verify the gamified procedural simulator.

The simulator is the bridge's idle-mode generator: when the system
isn't being used for real fishing, ``bridge --simulate`` runs the
simulator and emits a continuous procedural narrative through the
same WebSocket pipe as the fixture. The shell renders it the same
way (it just shows the GAMIFIED badge and a SCORE panel).

This test exercises the simulator directly, without the bridge,
and asserts the contract:

    * records have the same top-level shape as the JSONL fixture
    * the state machine progresses through 7 acts
    * score, kintsugi, and mission fields are always present
    * the Wreck and Settled acts loop indefinitely
"""
import sys
import time
from pathlib import Path

# Add repo root to path so we can import the package
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from digital_twin_shell.simulator import Simulator, ACTS, Score


# Schema fields every record must have (intersection with the JSONL fixture)
REQUIRED_FIELDS = {
    "vessel", "depth_m", "rudder_command_deg", "autopilot", "bathy",
    "deadband", "conservation", "fleet", "agent",
    "wind", "gps", "engine", "depth_sounder", "compass", "weather", "log",
    "game", "simulator", "timestamp",
}


def test_simulator_emits_well_formed_records():
    """Every record has the same top-level shape as the fixture."""
    sim = Simulator(hz=10.0, seed=42)
    seen_keys = set()
    for _ in range(20):
        rec = sim.next_record()
        seen_keys.update(rec.keys())
    missing = REQUIRED_FIELDS - seen_keys
    assert not missing, f"missing required fields: {missing}"


def test_simulator_progression_through_acts():
    """Forcing time forward should advance the state machine."""
    sim = Simulator(hz=10.0, seed=42)
    seen_acts = set()
    # Run for ~250 simulated seconds by jumping the start_time
    t0 = time.time()
    # Walk the act transitions by setting start_time into the past
    for i in range(50):
        # Jump the start time back to simulate elapsed time
        sim.start_time = t0 - (i * 5)  # 5s elapsed per tick
        sim._maybe_advance_act()
        seen_acts.add(sim.current_act.name)
    # We should have seen at least DEPARTURE, APPROACH, THE_GAP, STORM
    for expected in ["DEPARTURE", "APPROACH", "THE_GAP", "STORM"]:
        assert expected in seen_acts, f"never reached {expected}, got {seen_acts}"


def test_simulator_score_increments_with_kintsugi():
    """Repairing seams (low conservation headroom) should add kintsugi + score."""
    from digital_twin_shell.simulator import TheGapAct
    sim = Simulator(hz=10.0, seed=1)
    # Force into THE_GAP act by replacing the act and resetting voice
    sim.current_act_index = 2  # THE_GAP
    sim.current_act = TheGapAct(sim)
    initial_kintsugi = sim.score.kintsugi
    initial_points = sim.score.points
    # Generate a bunch of records
    for _ in range(50):
        sim.next_record()
    # Should have gained kintsugi
    assert sim.score.kintsugi > initial_kintsugi, \
        f"no kintsugi gained: {initial_kintsugi} -> {sim.score.kintsugi}"
    assert sim.score.points > initial_points, \
        f"no points gained: {initial_points} -> {sim.score.points}"


def test_simulator_first_steps_achievement_unlocked():
    """Entering DEPARTURE unlocks the First Steps achievement."""
    sim = Simulator(hz=10.0, seed=42)
    assert "First Steps" in sim.score.achievements


def test_simulator_mission_field_present():
    """The mission text is set on each act and surfaced in the record."""
    sim = Simulator(hz=10.0, seed=42)
    # First record should have a mission
    rec = sim.next_record()
    assert "current_mission" in rec["game"]
    assert rec["game"]["current_mission"] is not None
    # The mission text matches the DEPARTURE act
    assert "Hold course" in rec["game"]["current_mission"]


def test_simulator_act_changes_voice():
    """Each act sets a distinct intro voice."""
    sim = Simulator(hz=10.0, seed=42)
    # The DEPARTURE act voice is set on construction
    assert "Welcome aboard" in sim.voice_text or "Standing by" in sim.voice_text


def test_simulator_acts_defined():
    """All 7 acts (plus Settled) are present in ACTS."""
    assert len(ACTS) == 8
    act_names = {a.name for a in ACTS}
    assert "DEPARTURE" in act_names
    assert "SETTLED" in act_names


def test_simulator_bridge_uses_simulator():
    """The bridge accepts --simulate and starts the simulator."""
    # Smoke test: just import the bridge's arg parser
    from digital_twin_shell.bridge import parse_args
    args = parse_args(["--simulate"])
    assert args.simulate is True
    args = parse_args(["--simulate", "--sim-seed", "123"])
    assert args.simulate is True
    assert args.sim_seed == 123


def test_simulator_record_has_optional_vhf():
    """VHF appears every 8th tick (rate-limited chatter)."""
    sim = Simulator(hz=10.0, seed=42)
    vhf_count = 0
    for i in range(50):
        rec = sim.next_record()
        if "vhf" in rec:
            vhf_count += 1
            # VHF has channel, text, source_mmsi
            assert "channel" in rec["vhf"]
            assert "text" in rec["vhf"]
    # At least one VHF message should have appeared in 50 ticks
    assert vhf_count >= 1, "no VHF messages in 50 ticks"


if __name__ == "__main__":
    tests = [
        ("simulator emits well-formed records", test_simulator_emits_well_formed_records),
        ("simulator progresses through acts", test_simulator_progression_through_acts),
        ("simulator score increments with kintsugi", test_simulator_score_increments_with_kintsugi),
        ("First Steps achievement unlocked on enter", test_simulator_first_steps_achievement_unlocked),
        ("simulator mission field present", test_simulator_mission_field_present),
        ("simulator act changes voice", test_simulator_act_changes_voice),
        ("simulator has 8 acts defined", test_simulator_acts_defined),
        ("bridge accepts --simulate", test_simulator_bridge_uses_simulator),
        ("simulator VHF chatter rate-limited", test_simulator_record_has_optional_vhf),
    ]
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
        except Exception as e:
            print(f"  FAIL  {name}: {e}")
            sys.exit(1)
    print("all simulator tests passed")
