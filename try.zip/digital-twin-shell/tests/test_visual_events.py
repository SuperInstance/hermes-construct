"""
test_visual_events.py — push fixture frames directly into the page via
__digitalTwin_pushFixture to verify the Gap + kintsugi visualisations
fire correctly. Takes a screenshot at each interesting moment.
"""

from __future__ import annotations

import json
import socket
import subprocess
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SHOTS = REPO_ROOT / "tests" / "screenshots"


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _wait_for_port(port: int, timeout: float = 6.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.4):
                return True
        except OSError:
            time.sleep(0.1)
    return False


def main() -> int:
    http_port = _free_port()
    env = {**os.environ, "PYTHONPATH": str(REPO_ROOT)} if False else None
    proc = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(http_port),
         "--bind", "127.0.0.1"],
        cwd=str(REPO_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if not _wait_for_port(http_port, timeout=6.0):
        print("http didn't bind")
        return 1

    try:
        # Read fixture
        records = []
        with (REPO_ROOT / "sample-fixture.jsonl").open() as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))

        # Find interesting frames
        gap_frames = [(i, r) for i, r in enumerate(records)
                      if not r["deadband"]["heading_ok"]
                      or not r["bathy"]["contour_50fathom"]]
        kin_frames = [(i, r) for i, r in enumerate(records)
                      if abs(r["depth_m"] - r["bathy"]["depth_m"]) > 2.0]
        print(f"found {len(gap_frames)} gap frames, {len(kin_frames)} kintsugi frames")

        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
            ctx = browser.new_context(viewport={"width": 1280, "height": 800})
            page = ctx.new_page()
            errors = []
            page.on("pageerror", lambda exc: errors.append(str(exc)))
            ws_err_token = ("WebSocket connection", "ERR_CONNECTION_REFUSED")
            def _on_console(msg):
                if msg.type != "error":
                    return
                if all(s in msg.text for s in ws_err_token):
                    return
                errors.append(msg.text)
            page.on("console", _on_console)
            page.goto(f"http://127.0.0.1:{http_port}/index.html",
                      wait_until="domcontentloaded", timeout=15_000)
            page.wait_for_timeout(1500)

            # Push frames one at a time, screenshot at key moments
            for label, idx in [
                ("00-baseline", 0),
                ("01-kintsugi", kin_frames[len(kin_frames) // 2][0]),
                ("02-gap", gap_frames[len(gap_frames) // 2][0]),
                ("03-end", len(records) - 1),
            ]:
                page.evaluate(
                    "(rec) => window.__digitalTwin_pushFixture(rec)",
                    records[idx],
                )
                page.wait_for_timeout(1500)
                out = SHOTS / f"frame-{label}.png"
                page.screenshot(path=str(out), full_page=False)
                print(f"  {label}: frame {idx} → {out}")
                state = page.evaluate("""() => ({
                    frame_count: window.__digitalTwin?.getFrameCount?.(),
                    agent_text: document.getElementById('agent-text').textContent,
                    gap_visible: (() => {
                        const s = window.__digitalTwin?.scene?.children?.find(c => c.isSprite);
                        return s ? s.visible : null;
                    })(),
                })""")
                print(f"    state: {state}")
            browser.close()
        if errors:
            print(f"FAIL: {len(errors)} JS errors")
            for e in errors:
                print(f"    - {e}")
            return 1
        print("OK")
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=4)
        except Exception:
            proc.kill()


if __name__ == "__main__":  # pragma: no cover
    import os
    raise SystemExit(main())