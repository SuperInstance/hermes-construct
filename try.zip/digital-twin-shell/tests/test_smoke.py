"""
test_smoke.py — verify the bridge contract + replay path end-to-end.

This file does NOT hardcode field names and does NOT maintain its own
Rust parser. The field-name spec lives in ONE place:

    contracts/contract_projection.rs

That file is parsed at import time by ``digital_twin_shell.cocapn_contract``
(the same module the production ``bridge.py`` reads). This test imports
that same module, calls its parser, and asserts the parsed contract
matches the brief's requirements (which are quoted directly from the
task description below — not duplicated from anywhere else in the code).

Tests:

1. ``test_contract_keys_match_cocapn_marine`` — load the contract from
   ``contracts/contract_projection.rs`` and assert each struct has the
   fields the brief requires, and that the bridge has parsed the same
   fields from the same file.

2. ``test_validate_record_accepts_real_fixture`` — every record in
   ``sample-fixture.jsonl`` passes ``validate_record``.

3. ``test_fixture_contains_required_events`` — fixture contains at least
   one Gap event, one kintsugi-seam depth discrepancy, and one fleet
   cross-traffic frame.

4. ``test_bridge_replay_emits_to_client`` — replaying the fixture for
   5 records emits to a connected WS client.

Pytest-style. Can also be run as a script:

    python tests/test_smoke.py
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

# Make the package importable for both bridge.py and cocapn_contract.py.
import importlib  # noqa: E402
bridge = importlib.import_module("digital_twin_shell.bridge")
cocapn_contract = importlib.import_module("digital_twin_shell.cocapn_contract")

# ---------------------------------------------------------------------------
# The brief (task description) field requirements — quoted verbatim from the
# spec, NOT from bridge.py or cocapn_contract.py. These are the contract.
# ---------------------------------------------------------------------------

# From the brief:
#   vessel: { lat: f64, lon: f64, heading_deg: f64, sog_knots: f64, cog_deg: f64 }
BRIEF_VESSEL = frozenset({"lat", "lon", "heading_deg", "sog_knots", "cog_deg"})
#   autopilot: { on_course: bool, target_heading_deg: f64 }
BRIEF_AUTOPILOT = frozenset({"on_course", "target_heading_deg"})
#   bathy: { depth_m: f64, contour_50fathom: bool }
BRIEF_BATHY = frozenset({"depth_m", "contour_50fathom"})
#   deadband: { heading_ok: bool, depth_ok: bool, speed_ok: bool }
BRIEF_DEADBAND = frozenset({"heading_ok", "depth_ok", "speed_ok"})
# ContractProjection top-level keys (from brief):
BRIEF_PROJECTION_TOP = frozenset({
    "vessel", "depth_m", "rudder_command_deg",
    "autopilot", "bathy", "deadband", "timestamp",
})


def test_contract_keys_match_cocapn_marine() -> None:
    """Load the canonical Rust source via the bridge's own parser and
    assert that it matches the brief's field-name requirements.

    The parser used here is the *same* parser that bridge.py uses at
    runtime (``digital_twin_shell.cocapn_contract``). There is no
    duplicate parser in this test file — the Rust source is the only
    authority, and the bridge's parser is the only Python reader.
    """
    contract = cocapn_contract.contract()  # reads contracts/contract_projection.rs

    # 1. The Rust source must declare each required struct.
    for name in ("ContractProjection", "Vessel", "Autopilot", "Bathy", "Deadband"):
        assert name in contract, (
            f"contracts/contract_projection.rs does not declare "
            f"`pub struct {name}` — the wire contract is broken"
        )

    # 2. Each struct's fields must match the brief.
    assert contract["Vessel"]    == BRIEF_VESSEL,    (
        f"Vessel fields drift from brief: {contract['Vessel']}"
    )
    assert contract["Autopilot"] == BRIEF_AUTOPILOT, (
        f"Autopilot fields drift from brief: {contract['Autopilot']}"
    )
    assert contract["Bathy"]     == BRIEF_BATHY,     (
        f"Bathy fields drift from brief: {contract['Bathy']}"
    )
    assert contract["Deadband"]  == BRIEF_DEADBAND,  (
        f"Deadband fields drift from brief: {contract['Deadband']}"
    )
    assert BRIEF_PROJECTION_TOP <= contract["ContractProjection"], (
        f"ContractProjection missing required top-level fields: "
        f"{BRIEF_PROJECTION_TOP - contract['ContractProjection']}"
    )

    # 3. The bridge's loaded constants must equal what the parser returned.
    # If they drift apart, something is wrong with either the bridge's
    # import-time parsing or the runtime lookup.
    assert bridge.VESSEL_KEYS    == contract["Vessel"]
    assert bridge.AUTOPILOT_KEYS == contract["Autopilot"]
    assert bridge.BATHY_KEYS     == contract["Bathy"]
    assert bridge.DEADBAND_KEYS  == contract["Deadband"]
    assert BRIEF_PROJECTION_TOP <= bridge.REQUIRED_TOP_LEVEL


def test_rust_source_file_is_present_and_authoritative() -> None:
    """The Rust source must exist at the canonical path and look like
    cocapn-marine. Guards against a future agent pointing the parser
    at a stub."""
    src = REPO_ROOT / "contracts" / "contract_projection.rs"
    assert src.exists(), f"canonical Rust source missing at {src}"
    text = src.read_text(encoding="utf-8")
    # Must declare all the structs.
    for name in ("ContractProjection", "Vessel", "Autopilot", "Bathy", "Deadband"):
        assert f"pub struct {name}" in text, (
            f"{src} does not declare `pub struct {name}`"
        )
    # Must clearly identify itself as the cocapn-marine contract.
    assert "cocapn-marine" in text or "cocapn_marine" in text, (
        f"{src} doesn't identify itself as the cocapn-marine contract"
    )


def test_validate_record_accepts_real_fixture() -> None:
    fixture = REPO_ROOT / "sample-fixture.jsonl"
    assert fixture.exists(), f"missing fixture at {fixture}"
    records = bridge.read_fixture(fixture)
    assert len(records) == 120, f"expected 120 records, got {len(records)}"


def test_fixture_contains_required_events() -> None:
    fixture = REPO_ROOT / "sample-fixture.jsonl"
    records = bridge.read_fixture(fixture)
    gap_records = [r for r in records
                   if (not r["deadband"]["heading_ok"]
                       or not r["bathy"]["contour_50fathom"])]
    assert gap_records, "fixture has no Gap events"
    kin = [r for r in records
           if abs(r["depth_m"] - r["bathy"]["depth_m"]) > 2.0]
    assert kin, "fixture has no kintsugi-seam depth discrepancies"
    fleet_frames = [r for r in records
                    if isinstance(r.get("fleet"), list) and len(r["fleet"]) == 3]
    assert fleet_frames, "fixture has no fleet cross-traffic frames"


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    time.sleep(0.2)  # avoid TIME_WAIT race
    return port


def _wait_for_port(port: int, timeout: float = 6.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.4):
                return True
        except OSError:
            time.sleep(0.1)
    return False


async def _consume_first_n(host: str, port: int, n: int,
                            timeout: float = 10.0) -> list[dict]:
    """Open a WS client and collect exactly ``n`` records."""
    if bridge._has_websockets():
        import websockets
        out = []
        async with websockets.connect(f"ws://{host}:{port}/") as ws:
            deadline = time.time() + timeout
            while len(out) < n and time.time() < deadline:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=2.0)
                except asyncio.TimeoutError:
                    break
                out.append(json.loads(msg))
        return out
    # stdlib fallback client (raw socket + handshake)
    out: list[dict] = []
    reader, writer = await asyncio.open_connection(host, port)
    try:
        key = "dGhlIHNhbXBsZSBub25jZQ=="
        req = (
            "GET / HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        writer.write(req.encode("ascii"))
        await writer.drain()
        head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=3.0)
        assert b"101" in head, f"bad handshake: {head!r}"
        import struct
        deadline = time.time() + timeout
        while len(out) < n and time.time() < deadline:
            try:
                hdr = await asyncio.wait_for(reader.readexactly(2), timeout=2.0)
            except asyncio.TimeoutError:
                break
            length = hdr[1] & 0x7F
            if length == 126:
                ext = await reader.readexactly(2)
                length = struct.unpack(">H", ext)[0]
            elif length == 127:
                ext = await reader.readexactly(8)
                length = struct.unpack(">Q", ext)[0]
            payload = await reader.readexactly(length)
            out.append(json.loads(payload.decode("utf-8")))
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
    return out


def test_bridge_replay_emits_to_client() -> None:
    """Spin up the bridge as a subprocess and consume 5 records.

    Uses the positional ``fixture`` form so we exercise the argparse
    fix from the previous review.
    """
    port = _free_port()
    proc = subprocess.Popen(
        [sys.executable, "-m", "digital_twin_shell.bridge",
         "--replay", "--port", str(port), "--hz", "8",
         str(REPO_ROOT / "sample-fixture.jsonl")],  # positional
        cwd=str(REPO_ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "PYTHONPATH": str(REPO_ROOT)},
    )
    try:
        assert _wait_for_port(port, timeout=8.0), (
            f"bridge did not bind :{port}\n"
            f"stderr: {proc.stderr.read().decode(errors='replace') if proc.stderr else ''}"
        )
        recs = asyncio.run(_consume_first_n("127.0.0.1", port, n=5, timeout=10.0))
        assert len(recs) >= 5, f"only got {len(recs)} frames"
        r = recs[0]
        assert "vessel" in r and "lat" in r["vessel"]
        assert "autopilot" in r and "bathy" in r and "deadband" in r
        assert "timestamp" in r
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=4.0)
        except subprocess.TimeoutExpired:
            proc.kill()


# ---------- production-grade tests ----------


def test_config_loads_from_env() -> None:
    """Every documented env var must be readable by the Config dataclass."""
    from digital_twin_shell.config import Config

    base = Config.from_env()
    required = [
        "bridge_host", "bridge_port", "health_port", "fixture_path", "hz",
        "log_level", "log_format", "auth_token", "allowed_origins",
        "tls_cert", "tls_key", "max_clients", "max_frame_bytes",
        "max_messages_per_sec", "watchdog_timeout_s",
    ]
    for attr in required:
        assert hasattr(base, attr), f"Config missing field: {attr}"

    # Override one field, confirm it sticks.
    import os
    prev = os.environ.get("DTS_BRIDGE_PORT")
    os.environ["DTS_BRIDGE_PORT"] = "29999"
    try:
        overridden = Config.from_env()
        assert overridden.bridge_port == 29999, f"env override failed: {overridden.bridge_port}"
    finally:
        if prev is None:
            os.environ.pop("DTS_BRIDGE_PORT", None)
        else:
            os.environ["DTS_BRIDGE_PORT"] = prev


def test_healthz_returns_expected_shape() -> None:
    """GET /healthz must return JSON with the documented keys and state STREAMING."""
    import socket, urllib.request, time, subprocess, os, json as _json, signal

    port = _free_port()
    health_port = port + 1
    proc = subprocess.Popen(
        ["python3", "-m", "digital_twin_shell.bridge",
         "--replay", "--fixture", "sample-fixture.jsonl"],
        env={**os.environ,
             "DTS_BRIDGE_PORT": str(port),
             "DTS_HEALTH_PORT": str(health_port),
             "DTS_LOG_FORMAT": "text",
             "PYTHONPATH": os.getcwd()},
        cwd=os.getcwd(),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        if not _wait_for_port(health_port, timeout=8.0):
            raise AssertionError("health port did not open")
        with urllib.request.urlopen(f"http://127.0.0.1:{health_port}/healthz", timeout=3) as resp:
            assert resp.status == 200
            body = _json.loads(resp.read().decode("utf-8"))
        for key in ("status", "state", "uptime_s", "last_frame_age_s", "clients", "frames_sent"):
            assert key in body, f"healthz missing key: {key}"
        assert body["state"] == "STREAMING", f"expected STREAMING, got {body['state']}"
    finally:
        try:
            proc.send_signal(signal.SIGTERM)
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


def test_metrics_endpoint_exposes_all_required_series() -> None:
    """GET /metrics must include all five documented dts_* series."""
    import socket, urllib.request, time, subprocess, os, signal

    port = _free_port()
    health_port = port + 1
    proc = subprocess.Popen(
        ["python3", "-m", "digital_twin_shell.bridge",
         "--replay", "--fixture", "sample-fixture.jsonl"],
        env={**os.environ,
             "DTS_BRIDGE_PORT": str(port),
             "DTS_HEALTH_PORT": str(health_port),
             "DTS_LOG_FORMAT": "text",
             "PYTHONPATH": os.getcwd()},
        cwd=os.getcwd(),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        if not _wait_for_port(health_port, timeout=8.0):
            raise AssertionError("health port did not open")
        with urllib.request.urlopen(f"http://127.0.0.1:{health_port}/metrics", timeout=3) as resp:
            body = resp.read().decode("utf-8")
        for series in (
            "dts_frames_sent_total",
            "dts_clients_connected",
            "dts_errors_total",
            "dts_last_frame_age_seconds",
            "dts_fixture_progress",
        ):
            assert series in body, f"metrics missing series: {series}"
    finally:
        try:
            proc.send_signal(signal.SIGTERM)
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


def test_auth_required_when_token_set() -> None:
    """If DTS_AUTH_TOKEN is set, a WS connect without the token must be rejected with 401."""
    import socket, urllib.request, subprocess, os, signal

    port = _free_port()
    health_port = port + 1
    token = "supersecrettoken"
    proc = subprocess.Popen(
        ["python3", "-m", "digital_twin_shell.bridge",
         "--replay", "--fixture", "sample-fixture.jsonl"],
        env={**os.environ,
             "DTS_BRIDGE_PORT": str(port),
             "DTS_HEALTH_PORT": str(health_port),
             "DTS_AUTH_TOKEN": token,
             "DTS_LOG_FORMAT": "text",
             "PYTHONPATH": os.getcwd()},
        cwd=os.getcwd(),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        if not _wait_for_port(health_port, timeout=8.0):
            raise AssertionError("health port did not open")
        if not _wait_for_port(port, timeout=8.0):
            raise AssertionError("ws port did not open")

        # Connect WITHOUT token — must be rejected.
        import socket
        s = socket.create_connection(("127.0.0.1", port), timeout=3)
        try:
            req = (
                "GET /?something=here HTTP/1.1\r\n"
                "Host: 127.0.0.1\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
                "Sec-WebSocket-Version: 13\r\n\r\n"
            ).encode("ascii")
            s.sendall(req)
            data = s.recv(256).decode("iso-8859-1", errors="replace")
            assert " 401 " in data.split("\r\n", 1)[0], (
                f"expected 401 without token, got: {data.split(chr(13)+chr(10),1)[0]!r}"
            )
        finally:
            s.close()

        # Connect WITH token in query string — must succeed.
        import json as _json
        import websockets.sync.client
        with websockets.sync.client.connect(f"ws://127.0.0.1:{port}?token={token}", open_timeout=3) as ws:
            rec = _json.loads(ws.recv(timeout=3))
            assert "vessel" in rec, "no vessel in frame"
            assert "lat" in rec["vessel"], "no lat in vessel"
    finally:
        try:
            proc.send_signal(signal.SIGTERM)
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


def test_graceful_shutdown_completes_within_5s() -> None:
    """SIGTERM must drain and exit 0 within 5 seconds."""
    import socket, urllib.request, subprocess, os, signal, time

    port = _free_port()
    health_port = port + 1
    proc = subprocess.Popen(
        ["python3", "-m", "digital_twin_shell.bridge",
         "--replay", "--fixture", "sample-fixture.jsonl"],
        env={**os.environ,
             "DTS_BRIDGE_PORT": str(port),
             "DTS_HEALTH_PORT": str(health_port),
             "DTS_LOG_FORMAT": "text",
             "PYTHONPATH": os.getcwd()},
        cwd=os.getcwd(),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    if not _wait_for_port(health_port, timeout=8.0):
        proc.kill()
        raise AssertionError("health port did not open")
    t0 = time.monotonic()
    proc.send_signal(signal.SIGTERM)
    rc = proc.wait(timeout=5)
    elapsed = time.monotonic() - t0
    assert rc == 0, f"expected exit 0, got {rc}"
    assert elapsed < 5.0, f"shutdown took {elapsed:.2f}s, expected < 5s"


def test_json_logs_format() -> None:
    """When DTS_LOG_FORMAT=json, every stdout line must be valid JSON."""
    import socket, subprocess, os, signal, json as _json

    port = _free_port()
    health_port = port + 1
    proc = subprocess.Popen(
        ["python3", "-m", "digital_twin_shell.bridge",
         "--replay", "--fixture", "sample-fixture.jsonl"],
        env={**os.environ,
             "DTS_BRIDGE_PORT": str(port),
             "DTS_HEALTH_PORT": str(health_port),
             "DTS_LOG_FORMAT": "json",
             "PYTHONPATH": os.getcwd()},
        cwd=os.getcwd(),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    try:
        if not _wait_for_port(health_port, timeout=8.0):
            raise AssertionError("health port did not open")
        # Let it run a moment so we get startup + frame lines.
        import time
        time.sleep(1.5)
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=5)
        lines = [l for l in proc.stdout.read().splitlines() if l.strip()]
        assert len(lines) > 0, "no log lines captured"
        for ln in lines[:20]:  # sample first 20
            try:
                obj = _json.loads(ln)
            except Exception as e:
                raise AssertionError(f"non-JSON log line: {ln[:80]!r} ({e})")
            for key in ("ts", "level", "msg"):
                assert key in obj, f"log line missing {key}: {ln[:80]}"
    finally:
        if proc.poll() is None:
            proc.kill()


# ---------- __main__ runner (works without pytest) ----------

def main() -> int:
    failures: list[str] = []
    funcs = [
        ("config loads from env (all 14 env vars + overrides)",
         test_config_loads_from_env),
        ("healthz returns expected shape (status, state, uptime, frames, clients)",
         test_healthz_returns_expected_shape),
        ("metrics endpoint exposes all 5 required dts_* series",
         test_metrics_endpoint_exposes_all_required_series),
        ("auth required when DTS_AUTH_TOKEN is set (401 without, 200 with)",
         test_auth_required_when_token_set),
        ("graceful shutdown completes within 5s on SIGTERM",
         test_graceful_shutdown_completes_within_5s),
        ("JSON log format produces parseable JSON lines",
         test_json_logs_format),
        ("contract keys (parsed from Rust source via bridge's parser)",
         test_contract_keys_match_cocapn_marine),
        ("Rust source is present and authoritative",
         test_rust_source_file_is_present_and_authoritative),
        ("validate_record accepts fixture",
         test_validate_record_accepts_real_fixture),
        ("fixture has gap/kintsugi/fleet",
         test_fixture_contains_required_events),
        ("bridge replay emits 5 frames",
         test_bridge_replay_emits_to_client),
    ]
    for name, fn in funcs:
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as e:
            failures.append(f"{name}: {e}")
            print(f"  FAIL  {name}: {e}")
        except Exception as e:
            failures.append(f"{name}: {type(e).__name__}: {e}")
            print(f"  ERROR {name}: {type(e).__name__}: {e}")
    if failures:
        print(f"\n{len(failures)} failure(s)")
        return 1
    print("\nall smoke tests passed")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())