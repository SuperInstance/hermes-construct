"""
test_index_with_bridge.py — start the bridge AND the static server, push
the fixture into the page via the exposed __digitalTwin_pushFixture
hook, then take a screenshot. This is the gold-path test: real bridge,
real fixture, real WebGL.

Optional: only runs when `--with-bridge` is passed. Otherwise the
verifier falls back to test_index.py which doesn't need a bridge.
"""

from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SHOTS = REPO_ROOT / "tests" / "screenshots"
SHOTS.mkdir(parents=True, exist_ok=True)


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _wait_for_port(port: int, timeout: float = 8.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.4):
                return True
        except OSError:
            time.sleep(0.1)
    return False


def main() -> int:
    bridge_port = _free_port()
    http_port = _free_port()
    env = {**os.environ, "PYTHONPATH": str(REPO_ROOT)}

    print(f"[with-bridge] starting bridge on :{bridge_port}")
    bridge = subprocess.Popen(
        [sys.executable, "-m", "digital_twin_shell.bridge",
         "--replay", "--port", str(bridge_port), "--hz", "8"],
        cwd=str(REPO_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    print(f"[with-bridge] starting http on :{http_port}")
    http = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(http_port),
         "--bind", "127.0.0.1"],
        cwd=str(REPO_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        if not _wait_for_port(bridge_port, timeout=10.0):
            print(f"[with-bridge] bridge didn't bind :{bridge_port}")
            return 1
        if not _wait_for_port(http_port, timeout=6.0):
            print(f"[with-bridge] http didn't bind :{http_port}")
            return 1

        from playwright.sync_api import sync_playwright

        out = SHOTS / "digital-twin-with-bridge.png"
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
            ctx = browser.new_context(viewport={"width": 1280, "height": 800})
            page = ctx.new_page()
            errors = []
            ws_err_token = ("WebSocket connection", "ERR_CONNECTION_REFUSED")
            def _on_console(msg):
                if msg.type != "error":
                    return
                if all(s in msg.text for s in ws_err_token):
                    return
                errors.append(msg.text)
            page.on("pageerror", lambda exc: errors.append(f"pageerror: {exc}"))
            page.on("console", _on_console)
            url = f"http://127.0.0.1:{http_port}/index.html?port={bridge_port}"
            page.goto(url, wait_until="domcontentloaded", timeout=15_000)
            # Wait for the bridge to push several frames.
            page.wait_for_timeout(8000)
            page.screenshot(path=str(out), full_page=False)
            state = page.evaluate("""() => ({
                ws_url: window.__digitalTwin?.WS_URL,
                frame_count: window.__digitalTwin?.getFrameCount?.(),
                conn_state: window.__digitalTwin?.getConnState?.(),
                hud_lat: document.getElementById('hud-lat').textContent,
                hud_depth: document.getElementById('hud-depth').textContent,
                hud_heading: document.getElementById('hud-heading').textContent,
                agent_text: document.getElementById('agent-text').textContent,
            })""")
            browser.close()
        print(f"[with-bridge] screenshot: {out}")
        print(f"[with-bridge] JS errors (filtered): {errors}")
        print(f"[with-bridge] state: {state}")
        log_path = SHOTS / "with-bridge.log"
        log_path.write_text(json.dumps({"errors": errors, "state": state},
                                        indent=2))
        if errors:
            print("[with-bridge] FAIL: unfiltered JS errors present")
            return 1
        if state.get("frame_count", 0) < 1:
            print("[with-bridge] FAIL: no frames received from bridge")
            return 1
        if state.get("conn_state") != "LIVE":
            print(f"[with-bridge] FAIL: conn_state != LIVE "
                  f"(got {state.get('conn_state')!r})")
            return 1
        print("[with-bridge] OK")
        return 0
    finally:
        http.terminate()
        bridge.terminate()
        try:
            http.wait(timeout=4)
        except Exception:
            http.kill()
        try:
            bridge.wait(timeout=4)
        except Exception:
            bridge.kill()


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())