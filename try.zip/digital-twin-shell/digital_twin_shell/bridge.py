"""
bridge.py — WebSocket bridge between the cocapn-marine JSONL stream
and a browser-rendered digital twin.

Production features layered on top of the demo-grade bridge:

* Config via env vars (see :mod:`digital_twin_shell.config`).
* Structured JSON logging (see :mod:`digital_twin_shell.logging_setup`).
* HTTP control plane on a separate port (see :mod:`.http_control`):
  ``GET /healthz``, ``GET /metrics``, 404 everywhere else.
* WS auth (token via ``Sec-WebSocket-Protocol: dts-token.<t>`` or
  ``?token=<t>``).
* CORS allow-list (configurable via ``DTS_ALLOWED_ORIGINS``).
* Per-client rate limit + max-frame-size enforcement.
* Optional TLS (``DTS_TLS_CERT`` + ``DTS_TLS_KEY`` for the WS server;
  ``DTS_TLS_CERT_HEALTH`` + ``DTS_TLS_KEY_HEALTH`` for the control port).
* Graceful shutdown state machine: STREAMING -> DRAINING -> SHUTDOWN.
  On SIGTERM/SIGINT: stop accepting new clients, send a
  ``{"type":"shutdown","ts":...}`` frame to all connected clients, wait
  up to 5s, then close with code 1001. Exit 0.

Wire protocol
=============
One JSON record per WS text frame, matching the contract signed off in
``CONTRACT.md``.  The contract is parsed at startup from the
HAND-COMPOSED Rust source at ``contracts/contract_projection.rs``.

Usage
=====
::

    # Replay the bundled fixture at 1Hz on :8765
    python -m digital_twin_shell.bridge --replay

    # Or pick a different fixture
    python -m digital_twin_shell.bridge --fixture my-track.jsonl

    # All knobs are env vars
    DTS_BRIDGE_PORT=9000 DTS_AUTH_TOKEN=secret python -m digital_twin_shell.bridge --replay
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import hashlib
import json
import logging
import os
import signal
import ssl
import struct
import sys
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator, Optional, Set, Tuple

from .cocapn_contract import (
    contract,
    projection_keys,
    vessel_keys,
    autopilot_keys,
    bathy_keys,
    deadband_keys,
    all_top_level_keys,
    DEFAULT_RUST_SOURCE,
)
from .config import Config
from .http_control import BridgeState, ControlServer

log = logging.getLogger("digital_twin_shell.bridge")


# ---------------------------------------------------------------------------
# JSON contract — parsed from the canonical Rust source.
# The constants below are derived from contracts/contract_projection.rs
# at import time. Do NOT redefine field names here; update the Rust file.
# ---------------------------------------------------------------------------

def _load_contract_keys():
    """Pull all required key sets from the HAND-COMPOSED Rust source."""
    c = contract()
    return {
        "CONTRACT_KEYS": all_top_level_keys(),
        "VESSEL_KEYS":   c["Vessel"],
        "AUTOPILOT_KEYS": c["Autopilot"],
        "BATHY_KEYS":    c["Bathy"],
        "DEADBAND_KEYS": c["Deadband"],
        "REQUIRED_TOP_LEVEL": projection_keys(),
    }


_LOADED = _load_contract_keys()
CONTRACT_KEYS = _LOADED["CONTRACT_KEYS"]
VESSEL_KEYS = _LOADED["VESSEL_KEYS"]
AUTOPILOT_KEYS = _LOADED["AUTOPILOT_KEYS"]
BATHY_KEYS = _LOADED["BATHY_KEYS"]
DEADBAND_KEYS = _LOADED["DEADBAND_KEYS"]
REQUIRED_TOP_LEVEL = _LOADED["REQUIRED_TOP_LEVEL"]


def contract_source_path() -> Path:
    """Return the path of the Rust source file the contract was parsed from."""
    return DEFAULT_RUST_SOURCE


def validate_record(rec: dict) -> None:
    """Raise ValueError if ``rec`` doesn't satisfy the wire contract.

    The required top-level keys come from the ContractProjection in
    ``contracts/contract_projection.rs``. Optional extensions
    (``fleet``, ``agent``, ``conservation``) are allowed but not required.
    """
    missing = REQUIRED_TOP_LEVEL - set(rec)
    if missing:
        raise ValueError(f"record missing required keys (from Rust contract): {missing}")
    for k in VESSEL_KEYS:
        if k not in rec["vessel"]:
            raise ValueError(f"vessel missing key: {k}")
    for k in AUTOPILOT_KEYS:
        if k not in rec["autopilot"]:
            raise ValueError(f"autopilot missing key: {k}")
    for k in BATHY_KEYS:
        if k not in rec["bathy"]:
            raise ValueError(f"bathy missing key: {k}")
    for k in DEADBAND_KEYS:
        if k not in rec["deadband"]:
            raise ValueError(f"deadband missing key: {k}")


# ---------------------------------------------------------------------------
# Fixture reading
# ---------------------------------------------------------------------------

def read_fixture(path: Path) -> list[dict]:
    """Read a JSONL fixture, one record per line, validate each."""
    records: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{lineno}: bad JSON: {exc}") from exc
            validate_record(rec)
            records.append(rec)
    if not records:
        raise ValueError(f"{path}: fixture is empty")
    return records


async def stream_fixture(records: list[dict], *, hz: float = 1.0,
                         loop: bool = False,
                         state: Optional[BridgeState] = None
                         ) -> AsyncIterator[dict]:
    """Yield fixture records at ``hz`` Hz. If ``loop`` is true, loop forever.

    ``state`` is updated so the HTTP control plane can publish fixture
    progress.  It is mutated only on the asyncio loop thread, so no
    locking is needed.
    """
    interval = 1.0 / hz
    i = 0
    total = len(records)
    if state is not None:
        state.fixture_total = total
        state.fixture_loop = loop
    while True:
        for rec in records:
            i += 1
            if state is not None:
                state.fixture_index = i
            yield rec
            await asyncio.sleep(interval)
        if not loop:
            return


# ---------------------------------------------------------------------------
# Auth + CORS helpers (shared by both WS backends)
# ---------------------------------------------------------------------------

def _extract_token_from_protocol(protocol_header: str) -> Optional[str]:
    """Parse a ``Sec-WebSocket-Protocol`` header.

    The client sends a comma-separated list of subprotocols.  Our auth
    scheme is one of the entries to be ``"dts-token.<value>"``.  Returns
    the value if present, else None.
    """
    if not protocol_header:
        return None
    for raw in protocol_header.split(","):
        sub = raw.strip()
        if sub.startswith("dts-token."):
            return sub[len("dts-token."):]
    return None


def _check_origin(headers, allowed_origins) -> Tuple[bool, str]:
    """Return (ok, reason).  ``ok`` is True if the Origin header is
    acceptable (or no Origin was sent — many WS clients omit it)."""
    origin = headers.get("origin") or headers.get("Origin") or ""
    if "*" in allowed_origins:
        return True, "*"
    if not origin:
        # No Origin header (e.g. raw CLI client, curl, non-browser tool).
        # We allow this for ops; browsers always send Origin.
        return True, "no-origin"
    if origin in allowed_origins:
        return True, "matched"
    return False, f"origin {origin!r} not in allow-list"


def _check_auth(headers, url_path: str,
                auth_token: str) -> Tuple[bool, str]:
    """Return (ok, reason).  Returns ok=True if auth is disabled or
    a valid token is presented.  Otherwise ok=False and the reason."""
    if not auth_token:
        return True, "auth-disabled"
    # 1. ?token=<t> query param.
    if url_path:
        try:
            # url_path may include "?" and a fragment; parse_query handles both.
            q = urllib.parse.parse_qs(
                urllib.parse.urlparse(url_path).query
            )
            supplied = (q.get("token") or [None])[0]
            if supplied and _safe_eq(supplied, auth_token):
                return True, "query-param"
        except Exception:
            pass
    # 2. Sec-WebSocket-Protocol: dts-token.<t>
    proto = headers.get("sec-websocket-protocol", "")
    tok = _extract_token_from_protocol(proto)
    if tok and _safe_eq(tok, auth_token):
        return True, "subprotocol"
    return False, "missing-or-bad-token"


def _safe_eq(a: str, b: str) -> bool:
    """Constant-time string equality."""
    if len(a) != len(b):
        return False
    result = 0
    for x, y in zip(a, b):
        result |= ord(x) ^ ord(y)
    return result == 0


# ---------------------------------------------------------------------------
# Per-client rate limiting
# ---------------------------------------------------------------------------

@dataclass
class _ClientBucket:
    """Token-bucket-ish rate limiter (1 second window).

    We use a simple count-in-the-last-second rather than a full
    token bucket — the goal is "stop an obviously abusive client",
    not "shape traffic to a precise rate".  The cap is
    ``cfg.max_messages_per_sec`` per client.
    """
    window_start: float = 0.0
    count: int = 0

    def allow(self, now: float, cap: int) -> bool:
        if now - self.window_start >= 1.0:
            self.window_start = now
            self.count = 0
        self.count += 1
        return self.count <= cap


# ---------------------------------------------------------------------------
# WebSocket server — websockets-when-available, stdlib fallback otherwise.
# ---------------------------------------------------------------------------

@dataclass
class BridgeStats:
    """Backwards-compat counters (the canonical ones live on BridgeState)."""
    clients: int = 0
    frames_sent: int = 0
    started_at: float = 0.0


class _WSServerBase:
    """Common interface used by both backends."""

    def __init__(self, cfg: Config, state: BridgeState) -> None:
        self.cfg = cfg
        self.state = state
        self.stats = BridgeStats(started_at=time.time())

    async def serve(self, src: AsyncIterator[dict]) -> None:  # pragma: no cover
        raise NotImplementedError


def _has_websockets() -> bool:
    try:
        import websockets  # noqa: F401
        return True
    except Exception:
        return False


class _WebsocketsServer(_WSServerBase):
    """Backend that uses the ``websockets`` library (>=12)."""

    # Subprotocol prefix used for token-over-subprotocol auth.
    # We don't actually negotiate this subprotocol — we only use its
    # presence as a way to smuggle the token past intermediaries.
    AUTH_SUBPROTOCOL_PREFIX = "dts-token."

    def __init__(self, cfg: Config, state: BridgeState) -> None:
        super().__init__(cfg, state)
        # Map of websocket -> _ClientBucket for rate limiting.
        self._buckets: dict = {}
        # Connected client set (after handshake).
        self.connected: set = set()
        # Set when shutdown begins; reject new clients.
        self.draining: bool = False

    # -------------------------------------------------------------------

    async def serve(self, src: AsyncIterator[dict]) -> None:
        import websockets
        from websockets.http import Headers  # type: ignore

        # Build the process_request callback that handles auth + CORS
        # BEFORE the upgrade completes.
        async def process_request(conn, request):
            # ``conn`` is the ServerConnection.  In websockets>=13 the
            # path is ``conn.request.path``; in 12 it's ``request.path``.
            path = getattr(
                getattr(conn, "request", None), "path", ""
            ) or request.path
            req_headers = Headers()  # we use the underlying request
            for k, v in request.headers.raw_items():
                req_headers[k] = v

            # Reject with 503 if we're shutting down.
            if self.draining:
                log.info("ws rejected: bridge draining",
                         extra={"path": path})
                return conn.respond(503, "Bridge shutting down\n")

            # CORS
            ok, why = _check_origin(req_headers, self.cfg.allowed_origins)
            if not ok:
                log.warning("ws rejected: origin not allowed",
                            extra={"reason": why, "path": path})
                self.state.note_error("origin_rejected")
                return conn.respond(403, f"Forbidden: {why}\n")

            # Auth
            ok, why = _check_auth(
                req_headers, path, self.cfg.auth_token
            )
            if not ok:
                client_ip = _client_ip(conn, request)
                log.warning("ws rejected: auth failed",
                            extra={
                                "client_ip": client_ip,
                                "reason": why,
                                "path": path,
                            })
                self.state.note_error("auth_rejected")
                return conn.respond(401, "Unauthorized\n")

            return None  # proceed with the handshake

        # The ``process_request`` hook returns ``None`` to let the
        # handshake continue, or an HTTPResponse to short-circuit it.

        # Limit the per-connection incoming size at the websockets
        # protocol layer (defence in depth alongside our own check).
        async def handler(ws):
            # ``ws.request.path`` holds the path; we already validated
            # the token in process_request.
            if self.cfg.max_clients and len(self.connected) >= self.cfg.max_clients:
                log.warning("ws rejected: max clients reached",
                            extra={"max": self.cfg.max_clients})
                self.state.note_error("max_clients")
                try:
                    await ws.close(1013, "max clients reached")
                except Exception:
                    pass
                return
            self.connected.add(ws)
            self.state.clients = len(self.connected)
            self.stats.clients = len(self.connected)
            client_ip = _safe_addr(ws)
            log.info("client connected",
                     extra={"client_ip": client_ip,
                            "clients": self.state.clients})
            bucket = _ClientBucket()
            self._buckets[ws] = bucket
            try:
                # Per-connection read loop.
                async for msg in ws:
                    # Incoming messages are NOT used by the bridge (the
                    # data flows upstream → clients, never client →
                    # upstream), but we still need to enforce the
                    # rate limit + size cap.
                    if isinstance(msg, (bytes, bytearray)):
                        size = len(msg)
                    else:
                        size = len(msg.encode("utf-8"))
                    if size > self.cfg.max_frame_bytes:
                        log.warning("ws rejected: frame too large",
                                    extra={
                                        "client_ip": client_ip,
                                        "size": size,
                                        "max": self.cfg.max_frame_bytes,
                                    })
                        self.state.note_error("oversize_frame")
                        try:
                            await ws.close(
                                1009, "frame too large"
                            )
                        except Exception:
                            pass
                        return
                    now = time.time()
                    if not bucket.allow(now, self.cfg.max_messages_per_sec):
                        log.warning("ws rejected: rate limit",
                                    extra={
                                        "client_ip": client_ip,
                                        "cap": self.cfg.max_messages_per_sec,
                                    })
                        self.state.note_error("rate_limited")
                        try:
                            await ws.close(
                                1008, "policy violation: rate limit"
                            )
                        except Exception:
                            pass
                        return
            except Exception as exc:
                # websockets.exceptions.ConnectionClosed is normal; log
                # anything else at WARNING.
                name = type(exc).__name__
                if "ConnectionClosed" in name:
                    pass
                else:
                    log.warning("ws read error",
                                extra={"error": str(exc), "kind": name})
            finally:
                self.connected.discard(ws)
                self._buckets.pop(ws, None)
                self.state.clients = len(self.connected)
                self.stats.clients = len(self.connected)
                log.info("client disconnected",
                         extra={"client_ip": client_ip,
                                "clients": self.state.clients})

        # Build TLS context if certs are configured.
        ssl_ctx = None
        if self.cfg.tls_cert and self.cfg.tls_key:
            ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_ctx.load_cert_chain(
                certfile=self.cfg.tls_cert,
                keyfile=self.cfg.tls_key,
            )

        async with websockets.serve(
            handler, self.cfg.bridge_host, self.cfg.bridge_port,
            ping_interval=20, ping_timeout=20,
            max_size=self.cfg.max_frame_bytes,
            ssl=ssl_ctx,
            process_request=process_request,
        ) as server:
            scheme = "wss" if ssl_ctx else "ws"
            log.info("bridge listening",
                     extra={
                         "scheme": scheme,
                         "host": self.cfg.bridge_host,
                         "port": self.cfg.bridge_port,
                     })
            await self._relay(server, src)

    # -------------------------------------------------------------------

    async def _relay(self, server, src: AsyncIterator[dict]) -> None:
        """Pump fixture records to all connected clients.

        Watches ``self.draining``; once set, the relay stops pulling
        from the source so the drain coroutine can flush the
        shutdown frame without racing the next record.
        """
        del server
        async for rec in src:
            if self.draining:
                return
            self.state.note_frame()
            if not self.connected:
                # No listener — keep counting so the smoke test sees
                # the stream alive.
                continue
            payload = json.dumps(rec, separators=(",", ":"))
            dead = []
            for ws in list(self.connected):
                if self.draining:
                    return
                try:
                    await ws.send(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.connected.discard(ws)
                self._buckets.pop(ws, None)
            self.state.clients = len(self.connected)
            self.stats.frames_sent += 1

    # -------------------------------------------------------------------

    async def begin_drain(self, timeout: float = 5.0) -> None:
        """Send ``{"type":"shutdown"}`` to all clients and close cleanly."""
        self.draining = True
        if not self.connected:
            return
        shutdown_frame = json.dumps(
            {"type": "shutdown", "ts": time.time()}, separators=(",", ":")
        )
        # Send the shutdown frame FIRST so the renderer flips to
        # SHUTDOWN state even if the next fixture record is already
        # queued in the relay loop.
        for ws in list(self.connected):
            try:
                await ws.send(shutdown_frame)
            except Exception:
                pass
        # Give the client a moment to receive the frame, then close.
        await asyncio.sleep(min(0.1, timeout))
        for ws in list(self.connected):
            try:
                await ws.close(1001, "going away")
            except Exception:
                pass
        # Best-effort drain; do not block forever.
        deadline = time.time() + timeout
        while self.connected and time.time() < deadline:
            await asyncio.sleep(0.05)
        for ws in list(self.connected):
            try:
                await ws.close(1001, "going away")
            except Exception:
                pass
            self.connected.discard(ws)
        self._buckets.clear()
        self.state.clients = 0
        self.stats.clients = 0


# ---------------------------------------------------------------------------
# Stdlib fallback (for environments where ``websockets`` isn't installed)
# ---------------------------------------------------------------------------

class _StdlibFallbackServer(_WSServerBase):
    """Pure-stdlib fallback. Implements just enough of RFC 6455 to demo.

    Single-client only.  Auth/CORS/rate-limit logic is the same as the
    ``websockets`` backend; only the framing differs.
    """

    MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    def __init__(self, cfg: Config, state: BridgeState) -> None:
        super().__init__(cfg, state)
        self.draining: bool = False

    async def serve(self, src: AsyncIterator[dict]) -> None:
        async def handle_client(reader, writer):
            try:
                head = await asyncio.wait_for(
                    reader.readuntil(b"\r\n\r\n"), timeout=5.0
                )
            except (asyncio.IncompleteReadError, asyncio.TimeoutError):
                writer.close()
                return
            head_text = head.decode("iso-8859-1")
            lines = head_text.split("\r\n")
            request_line = lines[0]
            headers = {}
            for line in lines[1:]:
                if ":" in line:
                    k, v = line.split(":", 1)
                    headers[k.strip().lower()] = v.strip()
            parts = request_line.split(" ")
            url_path = parts[1] if len(parts) >= 2 else "/"

            # 503 if draining
            if self.draining:
                writer.write(b"HTTP/1.1 503 Service Unavailable\r\n"
                             b"Content-Length: 23\r\n"
                             b"Connection: close\r\n\r\n"
                             b"Bridge shutting down\n")
                await writer.drain()
                writer.close()
                return

            # CORS
            ok, why = _check_origin(headers, self.cfg.allowed_origins)
            if not ok:
                log.warning("stdlib-fallback rejected: origin",
                            extra={"reason": why})
                self.state.note_error("origin_rejected")
                writer.write(b"HTTP/1.1 403 Forbidden\r\n"
                             b"Content-Length: 10\r\n"
                             b"Connection: close\r\n\r\n"
                             b"Forbidden\n")
                await writer.drain()
                writer.close()
                return

            # Auth
            ok, why = _check_auth(headers, url_path, self.cfg.auth_token)
            if not ok:
                peer = writer.get_extra_info("peername")
                client_ip = peer[0] if peer else "?"
                log.warning("stdlib-fallback rejected: auth",
                            extra={"client_ip": client_ip, "reason": why})
                self.state.note_error("auth_rejected")
                writer.write(b"HTTP/1.1 401 Unauthorized\r\n"
                             b"Content-Length: 12\r\n"
                             b"WWW-Authenticate: Token\r\n"
                             b"Connection: close\r\n\r\n"
                             b"Unauthorized\n")
                await writer.drain()
                writer.close()
                return

            key = headers.get("sec-websocket-key")
            if not key:
                writer.close()
                return
            accept = base64.b64encode(
                hashlib.sha1(
                    (key + self.MAGIC).encode("ascii")
                ).digest()
            ).decode("ascii")
            response = (
                "HTTP/1.1 101 Switching Protocols\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
            )
            writer.write(response.encode("ascii"))
            await writer.drain()
            self.state.clients = 1
            self.stats.clients = 1
            log.info("stdlib-fallback client connected")

            bucket = _ClientBucket()
            try:
                async for rec in src:
                    self.state.note_frame()
                    payload = json.dumps(rec, separators=(",", ":")).encode("utf-8")
                    header = bytearray()
                    header.append(0x81)  # FIN + text
                    length = len(payload)
                    if length < 126:
                        header.append(length)
                    elif length < (1 << 16):
                        header.append(126)
                        header += struct.pack(">H", length)
                    else:
                        header.append(127)
                        header += struct.pack(">Q", length)
                    writer.write(bytes(header) + payload)
                    try:
                        await writer.drain()
                    except (ConnectionResetError, BrokenPipeError):
                        break
                    self.stats.frames_sent += 1
                    # Rate-limit reads (client -> server frames).
                    # The fallback doesn't read frames; skip.
            except Exception as exc:
                log.warning("stdlib-fallback client error",
                            extra={"error": str(exc)})
            finally:
                self.state.clients = 0
                self.stats.clients = 0
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
                log.info("stdlib-fallback client disconnected")

        server = await asyncio.start_server(
            handle_client, self.cfg.bridge_host, self.cfg.bridge_port
        )
        log.info("bridge (stdlib fallback) listening",
                 extra={
                     "scheme": "ws",
                     "host": self.cfg.bridge_host,
                     "port": self.cfg.bridge_port,
                 })
        async with server:
            await server.serve_forever()

    async def begin_drain(self, timeout: float = 5.0) -> None:
        self.draining = True
        # The stdlib fallback uses a single client; closing the
        # underlying server is the cleanest shutdown path.
        # Caller should also call server.close() (handled in _amain).
        return


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _client_ip(conn, request) -> str:
    """Best-effort client IP extraction for the websockets backend."""
    try:
        # websockets>=12 exposes ``request.headers`` and ``conn.transport``.
        peer = request.headers.get("x-forwarded-for")
        if peer:
            return peer.split(",")[0].strip()
        transport = getattr(conn, "transport", None)
        if transport and transport.get_extra_info("peername"):
            return transport.get_extra_info("peername")[0]
    except Exception:
        pass
    return "?"


def _safe_addr(ws) -> str:
    try:
        peer = ws.transport.get_extra_info("peername")  # type: ignore[attr-defined]
        if peer:
            return str(peer[0])
    except Exception:
        pass
    return "?"


def make_server(cfg: Config, state: BridgeState) -> _WSServerBase:
    if _has_websockets():
        log.info("using 'websockets' library backend")
        return _WebsocketsServer(cfg, state)
    log.warning("'websockets' library not importable; "
                "using stdlib fallback")
    return _StdlibFallbackServer(cfg, state)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="python -m digital_twin_shell.bridge",
        description=(
            "Digital-twin WebSocket bridge (cocapn-marine JSONL → browser)."
        ),
        epilog=(
            "Examples:\n"
            "  python -m digital_twin_shell.bridge --replay\n"
            "  python -m digital_twin_shell.bridge --fixture my-track.jsonl\n"
            "  DTS_AUTH_TOKEN=secret python -m digital_twin_shell.bridge --replay\n"
        ),
    )
    p.add_argument("fixture_positional", nargs="?", type=Path, default=None,
                   help="Positional: path to a JSONL fixture file.")
    p.add_argument("--fixture", type=Path, default=None,
                   help="Path to a JSONL fixture file (one record per line).")
    p.add_argument("--port", type=int, default=None,
                   help="WS port (overrides DTS_BRIDGE_PORT, default 8765).")
    p.add_argument("--host", default=None,
                   help="Bind host (overrides DTS_BRIDGE_HOST).")
    p.add_argument("--hz", type=float, default=None,
                   help="Replay rate (overrides DTS_BRIDGE_HZ, default 1).")
    p.add_argument("--replay", action="store_true",
                   help="Replay the bundled sample-fixture.jsonl (2-min track).")
    p.add_argument("--simulate", action="store_true",
                   help="Run the procedural simulator (gamified mode).")
    p.add_argument("--sim-seed", type=int, default=None,
                   help="Seed for the simulator RNG (for reproducible runs).")
    p.add_argument("--loop", action="store_true",
                   help="Loop the fixture forever (good for demos).")
    p.add_argument("--verbose", "-v", action="store_true")
    args = p.parse_args(argv)

    if args.fixture is None and args.fixture_positional is not None:
        args.fixture = args.fixture_positional
    return args


def _resolve_fixture(args: argparse.Namespace, cfg: Config) -> Path:
    """Resolve the fixture path: explicit CLI > env > bundled."""
    if args.fixture is not None:
        return args.fixture
    if args.replay:
        return cfg.resolve_fixture()
    # Default to the bundled fixture (replay behaviour) so the
    # bridge runs out-of-the-box even when the user forgets
    # --replay/--fixture.
    return cfg.resolve_fixture()


# ---------------------------------------------------------------------------
# Async main
# ---------------------------------------------------------------------------

async def _amain(args: argparse.Namespace) -> int:
    from .logging_setup import configure_logging

    # Repo root = parent of the package directory.
    repo_root = Path(__file__).resolve().parent.parent
    cfg = Config.from_env(repo_root=repo_root)

    # CLI flags override env (handy for ad-hoc dev runs).
    if args.host is not None:
        cfg.bridge_host = args.host
    if args.port is not None:
        cfg.bridge_port = args.port
        cfg.health_port = cfg.bridge_port + 1
    if args.hz is not None:
        cfg.hz = args.hz
    if args.loop:
        cfg.loop_fixture = True
    if args.verbose:
        cfg.log_level = 10  # DEBUG

    configure_logging(level=cfg.log_level, fmt=cfg.log_format)

    # Log the resolved config (with secrets redacted).
    safe_cfg = cfg.to_dict()
    safe_cfg["auth_token"] = "<redacted>" if cfg.auth_token else ""
    log.info("starting digital-twin bridge",
             extra={"config": safe_cfg, "component": "bridge"})

    # Decide source: simulator (gamified) > fixture (replay) > bundled
    src: Any
    if args.simulate:
        log.info("starting procedural simulator (gamified mode)")
        from .simulator import Simulator, stream_simulator
        sim = Simulator(hz=cfg.hz, seed=args.sim_seed)
        state = BridgeState()
        state.set_state("STREAMING")
        state.fixture_total = -1  # -1 = infinite / simulator
        state.fixture_loop = True
        # The src is an async generator
        src = stream_simulator(sim)
        fixture_path = Path("(simulator)")
    else:
        fixture_path = _resolve_fixture(args, cfg)
        if not fixture_path.exists():
            log.error("fixture not found", extra={"path": str(fixture_path)})
        log.info("loading fixture", extra={"path": str(fixture_path)})
        records = read_fixture(fixture_path)
        log.info("loaded fixture",
                 extra={"path": str(fixture_path), "records": len(records)})

        state = BridgeState()
        state.set_state("STREAMING")
        # Start the WS data plane (fixture mode)
        src = stream_fixture(records, hz=cfg.hz, loop=cfg.loop_fixture, state=state)

    # Start the control plane.
    control = ControlServer(cfg, state)
    control.start()

    # Start the WS data plane.
    server = make_server(cfg, state)

    # Install signal handlers for graceful shutdown.
    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def _signal_handler(signame: str) -> None:
        if shutdown_event.is_set():
            return  # ignore repeated signals
        log.info("signal received; draining",
                 extra={"signal": signame})
        state.set_state("DRAINING")
        shutdown_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler, sig.name)
        except (NotImplementedError, RuntimeError):
            # Windows / non-main-thread: skip; KeyboardInterrupt still
            # works for the dev case.
            pass

    # Run the server and the shutdown watcher concurrently.
    serve_task = asyncio.create_task(server.serve(src), name="ws-serve")
    shutdown_task = asyncio.create_task(
        _wait_for_shutdown(shutdown_event, server, state, control),
        name="shutdown-watcher",
    )
    done, pending = await asyncio.wait(
        {serve_task, shutdown_task},
        return_when=asyncio.FIRST_COMPLETED,
    )
    # If the relay finished first (e.g. fixture ran out), still wait
    # briefly for any pending drain.  If the shutdown watcher finished
    # first, the serve_task is mid-flight; cancel it so the relay
    # stops pulling from the source and ``begin_drain`` can take over.
    if shutdown_task in done:
        log.info("serve task still running; cancelling to flush drain",
                 extra={"task": serve_task.get_name()})
        serve_task.cancel()
        try:
            await serve_task
        except (asyncio.CancelledError, Exception):
            pass
    else:
        for t in pending:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
    for t in done:
        if t.exception():
            log.error("task failed",
                      extra={"task": t.get_name(),
                             "error": str(t.exception())})
    state.set_state("SHUTDOWN")
    control.stop()
    return 0


async def _wait_for_shutdown(event: asyncio.Event, server, state, control):
    """Drain on signal: send the shutdown frame, wait, then return."""
    await event.wait()
    state.set_state("DRAINING")
    log.info("draining clients")
    try:
        await asyncio.wait_for(
            server.begin_drain(timeout=5.0), timeout=6.0
        )
    except asyncio.TimeoutError:
        log.warning("drain timed out; forcing close")
    state.set_state("SHUTDOWN")
    log.info("shutdown complete")


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        return asyncio.run(_amain(args))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
