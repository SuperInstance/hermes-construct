"""
cocapn_contract.py — extract the JSON wire contract from the hand-composed
contract-projection Rust source.

This module is the bridge between Rust and Python. It parses
``contracts/contract_projection.rs`` (a hand-composed projection that
aggregates field names from cocapn-marine's existing public types
— GgaData, AutopilotOutput, BathyDatabase, HeadingDeadband, etc.) and
exposes the field names as Python frozensets. Both ``bridge.py`` and
``tests/test_smoke.py`` read from this single source — neither hardcodes
field names. The smoke test then cross-checks the parsed field names
against cocapn-marine's actual upstream source files (sensor.rs,
autopilot.rs, bathy.rs, deadband.rs) to confirm they are real
verbatim references, not invented.

The parser is intentionally tolerant: it reads ``pub <name>: <type>``
lines inside struct bodies, strips doc comments and serde annotations,
and returns the field set per struct. If you add a struct to the
projection, you don't have to touch this parser — it just walks the file.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

# Default location of the hand-composed contract projection.
DEFAULT_RUST_SOURCE = (
    Path(__file__).resolve().parent.parent / "contracts" / "contract_projection.rs"
)


def parse_rust_contract(path: Path = DEFAULT_RUST_SOURCE) -> dict[str, frozenset[str]]:
    """Parse the contract projection and return {struct_name: frozenset(field_names)}.

    Returns at least:
      {
        "ContractProjection": {"vessel", "depth_m", "rudder_command_deg",
                               "autopilot", "bathy", "deadband", "timestamp",
                               "conservation", "fleet"},
        "Vessel":      {"lat", "lon", "heading_deg", "sog_knots", "cog_deg"},
        "Autopilot":   {"on_course", "target_heading_deg"},
        "Bathy":       {"depth_m", "contour_50fathom"},
        "Deadband":    {"heading_ok", "depth_ok", "speed_ok"},
      }

    Unknown structs are skipped silently; the parser only reports the ones
    named in the contract whitelist.
    """
    text = path.read_text(encoding="utf-8")
    return _parse_struct_fields(text)


# Structs we care about, named in the hand-composed projection.
EXPECTED_STRUCTS = ("ContractProjection", "Vessel", "Autopilot", "Bathy", "Deadband")


# Matches lines like `    pub field_name: Type,` inside struct bodies.
_FIELD_RE = re.compile(
    r"^\s*pub\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*[^,;\n{]+[,\n]",
    re.MULTILINE,
)


def _parse_struct_fields(text: str) -> dict[str, frozenset[str]]:
    """Find `pub struct Name { ... }` blocks and extract their `pub` field
    names. Comments (// ... and /* ... */) and cfg attributes are skipped."""
    # Strip /* ... */ block comments first.
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    out: dict[str, frozenset[str]] = {}

    # Find each "pub struct Name {" ... "}" body.
    struct_re = re.compile(
        r"pub\s+struct\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{([^{}]*)\}",
        re.DOTALL,
    )
    for m in struct_re.finditer(text):
        name = m.group(1)
        if name not in EXPECTED_STRUCTS:
            continue
        body = m.group(2)
        fields: list[str] = []
        for line in body.splitlines():
            line = line.split("//", 1)[0].strip()
            fm = _FIELD_RE.match(line + "\n")
            if fm:
                fields.append(fm.group(1))
        out[name] = frozenset(fields)
    return out


# Convenience accessors that the rest of the codebase imports.
def vessel_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return parse_rust_contract(path)["Vessel"]


def autopilot_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return parse_rust_contract(path)["Autopilot"]


def bathy_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return parse_rust_contract(path)["Bathy"]


def deadband_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return parse_rust_contract(path)["Deadband"]


def projection_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return parse_rust_contract(path)["ContractProjection"]


# Backward-compat alias for older code paths.
def snapshot_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    return projection_keys(path)


def contract(path: Path = DEFAULT_RUST_SOURCE) -> dict[str, frozenset[str]]:
    """Return the full contract as a dict (struct name → field set)."""
    return parse_rust_contract(path)


# The optional extensions the bridge is allowed to add without breaking the
# cocapn-marine contract. These are PROJECTION EXTENSIONS — they are not
# in the upstream cocapn-marine source. They are documented in
# CONTRACT.md under "PROJECTION_EXTENSIONS". Replace with verbatim
# upstream fields when cocapn-marine grows them.
EXTENSION_KEYS = frozenset({"fleet", "agent", "conservation"})


def all_top_level_keys(path: Path = DEFAULT_RUST_SOURCE) -> frozenset[str]:
    """Projection top-level keys + the optional extensions the bridge may emit."""
    return projection_keys(path) | EXTENSION_KEYS