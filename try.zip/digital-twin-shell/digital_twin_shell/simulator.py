"""
Procedural simulator for the digital-twin shell.

When the system is not being used for real fishing (idle), the bridge
can run in ``--simulate`` mode and use this module to generate a
gamified narrative. The simulator is a state machine that progresses
through 8 acts, each with its own physics, voice, mission, and
achievement. Records emitted have the same shape as the JSONL fixture
so the existing shell renderer is unchanged.

The story:

    Act 1 — DEPARTURE  (0-15s)
        Boat leaves harbor. Tutorial: "Welcome aboard. Hold 270°."
        Achievement: First Steps.

    Act 2 — APPROACH  (15-35s)
        Bathy deepens. Ghost fleet fades in. First mission appears.
        Achievement: 50 Fathoms.

    Act 3 — THE_GAP  (35-60s)
        Heading drifts, kintsugi seams fire. The player (or autopilot)
        must hold course.
        Achievement: The Gap.

    Act 4 — STORM  (60-90s)
        Barometric drop, wind picks up to 25kt, depth fluctuates.
        Mission: "Batten down. Stay within 10° of 270°."
        Achievement: Stormrider.

    Act 5 — GHOST_FLEET  (90-130s)
        Three vessels converge. CPA challenges. Slow to 4kt.
        Achievement: Mariner.

    Act 6 — WHALE  (130-170s)
        Sonar shows large contact. Slow to 3kt. Maintain 200m clearance.
        Achievement: Whale Watcher.

    Act 7 — WRECK  (170-220s)
        Mark an abandoned wreck at 57-22N. Mission: log the position.
        Achievement: Hydrographer.

    Act 8 — SETTLED  (220s+)
        Continuous. Calm, idle, "the reef remembers." Endless mode.
        Achievement: Reefwalker.

Scoring:

    +10 per kintsugi seam
    +5 per second held on-course during a gap
    +100 per ghost vessel CPA kept > 0.5nm
    +200 per mission completed
    +500 per achievement unlocked
    -1 per second off-course

Idle trigger:

    The simulator is selected by the bridge when ``--simulate`` is
    passed, or when the HTTP control plane reports no real-fishing
    activity for > N minutes (DTS_IDLE_S, default 5). For the demo
    we just use ``--simulate``.

This module is framework-free. It returns dicts that match the
JSONL schema. The bridge's ``stream_fixture`` and the simulator
both implement the same async-iterator shape, so the rest of the
bridge does not care which one is producing records.
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator, Dict, List, Optional

# ---------------------------------------------------------------------------
# Schema constants — match the JSONL fixture
# ---------------------------------------------------------------------------

START_LAT = 57.20
START_LON = -150.40
TARGET_LAT = 57.238
TARGET_LON = -150.462

# ---------------------------------------------------------------------------
# State machine
# ---------------------------------------------------------------------------

@dataclass
class Score:
    """Live scoring state. Surfaced to the renderer as ``rec['game']['score']``."""
    points: int = 0
    kintsugi: int = 0
    gaps: int = 0
    fish: int = 0
    missions_completed: int = 0
    achievements: List[str] = field(default_factory=list)
    current_mission: Optional[str] = None
    current_mission_progress: float = 0.0  # 0..1
    last_achievement: Optional[Dict[str, Any]] = None  # popped by the UI

    def add(self, pts: int, reason: str = "") -> None:
        self.points += pts

    def to_dict(self) -> Dict[str, Any]:
        return {
            "points": self.points,
            "kintsugi": self.kintsugi,
            "gaps": self.gaps,
            "fish": self.fish,
            "missions_completed": self.missions_completed,
            "achievements": list(self.achievements),
            "current_mission": self.current_mission,
            "current_mission_progress": round(self.current_mission_progress, 2),
            "last_achievement": self.last_achievement,
        }


class Act:
    """Base class for an act in the simulator."""

    name: str = "ACT"
    duration_s: float = 30.0
    achievement_on_enter: Optional[str] = None
    achievement_on_exit: Optional[str] = None
    intro_voice: str = ""

    def __init__(self, sim: "Simulator") -> None:
        self.sim = sim

    def on_enter(self) -> None:
        if self.achievement_on_enter:
            self.sim.unlock_achievement(self.achievement_on_enter)
        if self.intro_voice:
            self.sim.set_voice(self.intro_voice)
        if self.mission_text():
            self.sim.set_mission(self.mission_text(), self.mission_target())

    def on_exit(self) -> None:
        if self.achievement_on_exit:
            self.sim.unlock_achievement(self.achievement_on_exit)
        # Reward mission completion (one per act)
        if self.mission_text() and self.sim.score.current_mission == self.mission_text():
            self.sim.complete_mission()

    # Override in subclasses
    def mission_text(self) -> Optional[str]: return None
    def mission_target(self) -> float: return 1.0  # 1.0 = binary completion
    def tick(self, t: float, boat: Dict[str, Any]) -> Dict[str, Any]:
        """Return physics deltas for this tick: {heading, rudder, sog, ...}"""
        return {}


# --- The acts ---

class DepartureAct(Act):
    name = "DEPARTURE"
    duration_s = 15.0
    achievement_on_enter = "First Steps"
    intro_voice = "Welcome aboard, Captain. Casting off. Hold course 270°."

    def mission_text(self) -> str:
        return "Hold course 270° for 15 seconds."
    def mission_target(self) -> float:
        return 15.0

    def tick(self, t, boat):
        return {"target_heading": 270.0, "rudder_correction": 0.0}


class ApproachAct(Act):
    name = "APPROACH"
    duration_s = 20.0
    achievement_on_enter = "50 Fathoms"
    intro_voice = "Approaching the contour. Three vessels on the bow. Watch your depth."

    def mission_text(self) -> str:
        return "Reach the 50-fathom line."
    def mission_target(self) -> float:
        return 1.0

    def tick(self, t, boat):
        # Drift slightly to make the approach feel real
        return {"target_heading": 268.0, "rudder_correction": 0.2}


class TheGapAct(Act):
    name = "THE_GAP"
    duration_s = 25.0
    achievement_on_enter = "The Gap"
    intro_voice = "The Gap is opening. Hold your heading. Kintsugi is your friend."

    def mission_text(self) -> str:
        return "Survive the gap. Stay within 5° of 270°."
    def mission_target(self) -> float:
        return 25.0

    def tick(self, t, boat):
        # Induce a heading drift that the simulator's autopilot must fight
        # The drift is more dramatic here — the Gap event
        return {"target_heading": 270.0, "rudder_correction": -3.5 + 1.0 * math.sin(t * 0.7)}


class StormAct(Act):
    name = "STORM"
    duration_s = 30.0
    achievement_on_enter = "Stormrider"
    intro_voice = "Barometric pressure dropping fast. Wind building to 25 knots. Batten down."

    def mission_text(self) -> str:
        return "Stay within 10° of 270° during the storm."
    def mission_target(self) -> float:
        return 30.0

    def tick(self, t, boat):
        # Strong drift from wind
        return {"target_heading": 270.0, "rudder_correction": -5.0 + 2.0 * math.sin(t * 0.9)}


class GhostFleetAct(Act):
    name = "GHOST_FLEET"
    duration_s = 40.0
    achievement_on_enter = "Mariner"
    intro_voice = "Three vessels converging. Reduce to 4 knots. Hold CPA above half a nautical mile."

    def mission_text(self) -> str:
        return "Maintain CPA > 0.5nm with all ghost vessels."
    def mission_target(self) -> float:
        return 40.0

    def tick(self, t, boat):
        return {"target_heading": 270.0, "rudder_correction": -1.0}


class WhaleAct(Act):
    name = "WHALE"
    duration_s = 40.0
    achievement_on_enter = "Whale Watcher"
    intro_voice = "Sonar contact. Large biological. Reduce to 3 knots. Maintain 200 metres clearance."

    def mission_text(self) -> str:
        return "Slow to 3 knots and hold for 30 seconds."
    def mission_target(self) -> float:
        return 30.0

    def tick(self, t, boat):
        return {"target_heading": 270.0, "rudder_correction": 0.5}


class WreckAct(Act):
    name = "WRECK"
    duration_s = 50.0
    achievement_on_enter = "Hydrographer"
    intro_voice = "Sonar shows a contact on the bottom. Wreck at 57-22N, 150-27W. Mark it."

    def mission_text(self) -> str:
        return "Log the wreck position."
    def mission_target(self) -> float:
        return 1.0

    def tick(self, t, boat):
        return {"target_heading": 268.0, "rudder_correction": -0.5}


class SettledAct(Act):
    name = "SETTLED"
    duration_s = 1e9  # effectively infinite
    achievement_on_enter = "Reefwalker"
    intro_voice = "On station. Engines quiet. The reef remembers. Standing by."

    def mission_text(self) -> str:
        return None  # No mission in settled mode

    def tick(self, t, boat):
        return {"target_heading": 270.0, "rudder_correction": 0.0}


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

ACTS: List[type] = [
    DepartureAct,
    ApproachAct,
    TheGapAct,
    StormAct,
    GhostFleetAct,
    WhaleAct,
    WreckAct,
    SettledAct,
]


class Simulator:
    """Generates gamified records on demand."""

    def __init__(self, *, hz: float = 2.0, seed: Optional[int] = None) -> None:
        self.hz = hz
        self.dt = 1.0 / hz
        self.start_time = time.time()
        self.tick_index = 0
        self.score = Score()
        self.score.current_mission = "Standing by."
        self.voice_text: str = "Standing by."
        self.voice_meta: str = "simulator"
        self.current_act_index: int = 0
        self.current_act: Act = ACTS[0](self)
        self.current_act.on_enter()
        # Boat state
        self.boat = {
            "lat": START_LAT,
            "lon": START_LON,
            "heading_deg": 270.0,
            "sog_knots": 5.0,
            "target_heading_deg": 270.0,
        }
        # Drift for settling
        self.idle_seconds: float = 0.0
        # RNG
        self.rng = random.Random(seed)

    # -- mission / achievement helpers --

    def unlock_achievement(self, name: str) -> None:
        if name in self.score.achievements:
            return
        self.score.achievements.append(name)
        self.score.add(500, reason="achievement: " + name)
        self.score.last_achievement = {
            "name": name,
            "ts": time.time(),
            "points": 500,
        }

    def complete_mission(self) -> None:
        self.score.missions_completed += 1
        self.score.add(200, reason="mission completed")
        self.score.current_mission = None
        self.score.current_mission_progress = 1.0

    def set_mission(self, text: str, target: float) -> None:
        self.score.current_mission = text
        self.score.current_mission_progress = 0.0
        self._mission_target = target

    def set_voice(self, text: str) -> None:
        self.voice_text = text
        self.voice_meta = f"sim · act {self.current_act_index + 1}"

    # -- the tick --

    def _maybe_advance_act(self) -> None:
        elapsed = time.time() - self.start_time
        # Compute the act's start time as sum of preceding acts' durations
        so_far = 0.0
        for i, cls in enumerate(ACTS):
            if i < self.current_act_index:
                so_far += cls.duration_s
            elif i == self.current_act_index:
                if elapsed - so_far >= cls.duration_s and i < len(ACTS) - 1:
                    self.current_act.on_exit()
                    self.current_act_index += 1
                    self.current_act = ACTS[self.current_act_index](self)
                    self.current_act.on_enter()
                break

    def _apply_act(self) -> None:
        deltas = self.current_act.tick(self.idle_seconds, self.boat)
        # Apply rudder correction to heading
        correction = deltas.get("rudder_correction", 0.0)
        # Heading is "held" by the autopilot: target = base, current = target + drift
        # The drift is induced by the wind/Gap; the autopilot fights it.
        # We model: heading = target - (correction / 5) + noise
        target = deltas.get("target_heading", self.boat["target_heading_deg"])
        self.boat["target_heading_deg"] = target
        drift = -correction * 0.6 + self.rng.uniform(-0.4, 0.4)
        self.boat["heading_deg"] = (target + drift) % 360
        # Speed varies per act
        speed_target = 6.0
        if self.current_act.name == "GHOST_FLEET":
            speed_target = 4.0
        elif self.current_act.name == "WHALE":
            speed_target = 3.0
        elif self.current_act.name == "SETTLED":
            speed_target = 4.5
        self.boat["sog_knots"] = max(0.5, speed_target + self.rng.uniform(-0.3, 0.3))

    def _advance_position(self) -> None:
        # Convert SOG to lat/lon delta per second
        sog = self.boat["sog_knots"]
        speed_mps = sog * 0.5144  # knots → m/s
        # 1 degree lat = 111 km; 1 degree lon = 111 km * cos(lat)
        hdg = self.boat["heading_deg"]
        # True heading → east/north velocity
        vx = math.sin(math.radians(hdg)) * speed_mps
        vy = math.cos(math.radians(hdg)) * speed_mps
        # Apply over dt
        dlat = vy * self.dt / 111000.0
        cos_lat = math.cos(math.radians(self.boat["lat"]))
        dlon = vx * self.dt / (111000.0 * max(0.01, cos_lat))
        # Pull toward target so we don't drift off
        tgt_dx = TARGET_LON - self.boat["lon"]
        tgt_dy = TARGET_LAT - self.boat["lat"]
        pull_factor = 0.0003  # gentle pull toward TARGET
        dlon += tgt_dx * pull_factor * self.dt
        dlat += tgt_dy * pull_factor * self.dt
        self.boat["lat"] += dlat
        self.boat["lon"] += dlon

    def _kintsugi_event(self) -> int:
        """If the conservation headroom is low (gap), fire kintsugi seams.
        Returns the number of seams fired this tick.
        """
        # Headroom: 0.18 at calm, drops to 0.02 during gaps
        if self.current_act.name == "THE_GAP":
            headroom = 0.05 + self.rng.uniform(-0.02, 0.05)
        elif self.current_act.name == "STORM":
            headroom = 0.08 + self.rng.uniform(-0.03, 0.06)
        elif self.current_act.name in ("GHOST_FLEET", "WHALE", "WRECK"):
            headroom = 0.12 + self.rng.uniform(-0.04, 0.08)
        else:
            headroom = 0.18 + self.rng.uniform(-0.02, 0.04)
        # When headroom < 0.10, kintsugi fires
        seams = 0
        if headroom < 0.10:
            seams = self.rng.randint(1, 3)
            self.score.kintsugi += seams
            self.score.add(seams * 10, reason="kintsugi")
        return seams, headroom

    def _fleet_state(self) -> List[Dict[str, Any]]:
        # Different fleets per act
        if self.current_act.name in ("GHOST_FLEET", "WHALE", "WRECK", "SETTLED"):
            n = 4
        elif self.current_act.name == "DEPARTURE":
            n = 0
        else:
            n = 3
        fleet = []
        for i in range(n):
            base_dist = [2.8, 4.2, 6.0, 7.5][i]
            base_brg = [65, 215, 295, 180][i]
            base_crs = [270, 268, 271, 90][i]
            base_sog = [5.5, 5.2, 5.8, 8.2][i]
            dist = max(0.2, base_dist + self.rng.uniform(-0.3, 0.3))
            brg = (base_brg + self.rng.uniform(-3, 3)) % 360
            crs = base_crs
            sog = base_sog
            # CPA computation
            cpa = 0.4 + 0.6 * abs(math.sin(self.idle_seconds * 0.1 + i))
            tcpa = abs(8.0 * math.cos(self.idle_seconds * 0.05 + i)) + 1.0
            fleet.append({
                "mmsi": 366123450 + i,
                "name": ["Cormorant", "Meridian", "Resolute", "Cape Vega"][i],
                "type": ["fishing", "cargo", "fishing", "tanker"][i],
                "distance_nm": round(dist, 2),
                "bearing_deg": round(brg, 1),
                "course_deg": crs,
                "sog_kt": sog,
                "cpa_nm": round(cpa, 2),
                "tcpa_min": round(tcpa, 1),
            })
        return fleet

    def _wind_record(self) -> Dict[str, Any]:
        base_speed = 12.0
        if self.current_act.name == "STORM":
            base_speed = 25.0
        elif self.current_act.name == "GHOST_FLEET":
            base_speed = 15.0
        elif self.current_act.name == "SETTLED":
            base_speed = 8.0
        return {
            "apparent_speed_kt": round(base_speed + 1.5 * math.sin(self.idle_seconds * 0.2), 1),
            "apparent_angle_deg": round(45.0 + 5.0 * math.sin(self.idle_seconds * 0.3), 1),
            "true_speed_kt": round(base_speed * 0.85, 1),
            "true_angle_deg": round(53.0, 1),
            "gust_kt": round(base_speed + self.rng.uniform(2.0, 4.5), 1),
        }

    def _gps_record(self) -> Dict[str, Any]:
        degraded = self.current_act.name in ("STORM",)
        return {
            "fix": "DGPS" if not degraded else "GPS",
            "sats": 11 + (self.rng.randint(-2, 1) if not degraded else self.rng.randint(-3, 0)),
            "hdop": round(0.8 + (0.0 if not degraded else 0.6) + self.rng.uniform(-0.1, 0.1), 2),
            "mode": "A",
        }

    def _engine_record(self) -> Dict[str, Any]:
        rpm = 1450
        if self.current_act.name == "STORM":
            rpm = 1800
        elif self.current_act.name == "GHOST_FLEET":
            rpm = 1300
        elif self.current_act.name == "WHALE":
            rpm = 1100
        elif self.current_act.name == "SETTLED":
            rpm = 1000
        return {
            "rpm": rpm + self.rng.randint(-30, 30),
            "oil_pressure_psi": round(58 + self.rng.uniform(-2, 2), 1),
            "coolant_temp_c": round(82 + self.rng.uniform(-1, 3 if self.current_act.name == "STORM" else 1), 1),
            "fuel_pct": round(74.5 - 0.01 * self.idle_seconds, 1),
            "hours": round(2847.6 + self.idle_seconds / 3600, 1),
        }

    def _weather_record(self) -> Dict[str, Any]:
        base_baro = 29.92
        if self.current_act.name == "STORM":
            base_baro = 29.65
        return {
            "baro_inhg": round(base_baro + self.rng.uniform(-0.02, 0.02), 3),
            "baro_trend": -0.012 if self.current_act.name == "STORM" else 0.002,
            "air_temp_c": round(11.5 + self.rng.uniform(-0.5, 0.5), 1),
            "water_temp_c": round(7.8 - 0.005 * self.idle_seconds + self.rng.uniform(-0.1, 0.1), 1),
            "wind_wave_ht_m": round(0.6 + 0.2 * math.sin(self.idle_seconds * 0.2), 2),
            "swell_ht_m": round(1.2 + 0.3 * math.cos(self.idle_seconds * 0.1), 2),
        }

    def _compass_record(self) -> Dict[str, Any]:
        h = self.boat["heading_deg"]
        return {
            "magnetic_heading_deg": round(h, 1),
            "deviation_deg": -2.5,
            "variation_deg": 18.0,
            "true_heading_deg": round(h - 18.0 - 2.5, 1),
        }

    def _depth_sounder_record(self) -> Dict[str, Any]:
        # Smooth depth profile from start to target
        p = min(1.0, self.idle_seconds / 200.0)
        d = 54.86 + (91.44 - 54.86) * p
        # During the gap, sounder disagrees with chart
        chart = d - (6.0 if self.current_act.name == "THE_GAP" else 0.0)
        arches = []
        if self.current_act.name in ("WHALE", "WRECK") and self.rng.random() < 0.5:
            for _ in range(self.rng.randint(1, 3)):
                arches.append({
                    "depth_m": round(d - self.rng.uniform(5, 25), 1),
                    "strength": round(self.rng.uniform(0.2, 0.9), 2),
                })
        return {
            "depth_m": round(d, 2),
            "chart_depth_m": round(chart, 2),
            "fish_arches": arches,
            "water_temp_c": round(7.8 - 0.005 * self.idle_seconds, 1),
        }

    def _log_record(self) -> Dict[str, Any]:
        return {
            "distance_nm": round(self.idle_seconds * self.boat["sog_knots"] / 3600, 2),
            "total_nm": round(28417.6 + self.idle_seconds * self.boat["sog_knots"] / 3600, 1),
        }

    def _vhf_record(self) -> Optional[Dict[str, Any]]:
        # One VHF message every ~8 ticks
        if self.tick_index % 8 != 0:
            return None
        pool = [
            ("16", "All stations, this is Coast Guard Sitka. Gale warning in effect."),
            ("13", "Cormorant, this is Meridian. Standing by on 13."),
            ("16", "Reef Sea Buoy is off-station. Use caution."),
            ("16", "Cape Vega, heavy fog reported at 57-15N. Reduce speed."),
            ("72", "Working channel 72, Resolute out."),
        ]
        # Adjust tone for act
        if self.current_act.name == "STORM":
            pool = [
                ("16", "SECURITE. Gale-force winds expected within the hour."),
                ("16", "All vessels, seek shelter. Coast Guard Sitka."),
            ]
        elif self.current_act.name == "WHALE":
            pool = [
                ("16", "Whale sighting reported at 57-22N. Slow to 5 knots."),
                ("13", "Researchers on 13, please confirm sighting."),
            ]
        elif self.current_act.name == "WRECK":
            pool = [
                ("16", "Uncharted wreck reported at 57-22N, 150-27W. Use caution."),
            ]
        ch, text = self.rng.choice(pool)
        return {"channel": ch, "text": text, "source_mmsi": 0}

    # -- main record generator --

    def next_record(self) -> Dict[str, Any]:
        self.idle_seconds = time.time() - self.start_time
        self._maybe_advance_act()
        self._apply_act()
        self._advance_position()
        seams, headroom = self._kintsugi_event()

        # Update mission progress (per-second)
        if self.score.current_mission:
            target = getattr(self, "_mission_target", 1.0)
            # Time-based missions
            if target > 1.0:
                self.score.current_mission_progress = min(1.0, self.idle_seconds_in_act() / target)
            # Position-based (we just complete it)
            else:
                self.score.current_mission_progress = min(1.0, self.idle_seconds_in_act() / 5.0)

        # On-course penalty
        if abs(self.boat["heading_deg"] - self.boat["target_heading_deg"]) > 5.0:
            self.score.add(-1, reason="off-course")
        else:
            self.score.add(1, reason="on-course")

        # VHF
        vhf = self._vhf_record()

        # Compose the record
        rec = {
            "vessel": {
                "lat": round(self.boat["lat"], 5),
                "lon": round(self.boat["lon"], 5),
                "heading_deg": round(self.boat["heading_deg"], 2),
                "sog_knots": round(self.boat["sog_knots"], 2),
                "cog_deg": round(self.boat["heading_deg"] + 0.4 * math.sin(self.idle_seconds * 0.2), 2),
            },
            "depth_m": round(self._depth_sounder_record()["depth_m"], 2),
            "rudder_command_deg": round(self.rng.uniform(-2, 2), 2),
            "autopilot": {
                "on_course": abs(self.boat["heading_deg"] - self.boat["target_heading_deg"]) < 5.0,
                "target_heading_deg": self.boat["target_heading_deg"],
            },
            "bathy": {
                "depth_m": round(self._depth_sounder_record()["chart_depth_m"], 2),
                "contour_50fathom": self._depth_sounder_record()["depth_m"] > 80.0,
            },
            "deadband": {
                "heading_ok": abs(self.boat["heading_deg"] - self.boat["target_heading_deg"]) < 5.0,
                "depth_ok": True,
                "speed_ok": True,
            },
            "conservation": {
                "gamma": round(0.62 + 0.05 * math.sin(self.idle_seconds * 0.3), 3),
                "eta": round(1.0 - 0.62 - headroom - 0.10, 3),
                "headroom": round(headroom, 3),
            },
            "fleet": self._fleet_state(),
            "agent": {
                "text": self.voice_text,
                "speaker": "CoCapn",
            },
            "wind": self._wind_record(),
            "gps": self._gps_record(),
            "engine": self._engine_record(),
            "depth_sounder": self._depth_sounder_record(),
            "compass": self._compass_record(),
            "weather": self._weather_record(),
            "log": self._log_record(),
            "game": self.score.to_dict(),
            "simulator": {
                "act": self.current_act.name,
                "act_index": self.current_act_index,
                "idle_seconds": round(self.idle_seconds, 1),
                "kintsugi_seams_this_tick": seams,
            },
            "timestamp": (datetime.now(timezone.utc)).isoformat(),
        }
        if vhf:
            rec["vhf"] = vhf

        self.tick_index += 1
        return rec

    def idle_seconds_in_act(self) -> float:
        """Approximate seconds spent in the current act."""
        so_far = 0.0
        for i, cls in enumerate(ACTS):
            if i < self.current_act_index:
                so_far += cls.duration_s
            elif i == self.current_act_index:
                return max(0.0, self.idle_seconds - so_far)
        return 0.0


async def stream_simulator(sim: Simulator) -> AsyncIterator[dict]:
    """Async generator that yields simulator records at sim.hz."""
    interval = sim.dt
    while True:
        rec = sim.next_record()
        yield rec
        import asyncio
        await asyncio.sleep(interval)
