"""
http_control.py — stdlib HTTP control plane: /healthz, /metrics, /  (404).

Implements the production control endpoints on a SEPARATE port
(``DTS_HEALTH_PORT``) so the WS data plane is never blocked by a
health-check probe, and so the operator can lock down the health port
to a private network while exposing WS to the fleet.

Threading model
===============
The control server runs in a background ``threading.Thread`` so the
asyncio event loop in ``bridge.py`` is not blocked by Prometheus
scrapes.  All state is read-only from the HTTP thread; the live
counters are simple mutable fields on a :class:`BridgeState` instance
the bridge mutates under its own lock-free discipline (Python int/float
assignments are atomic).

Endpoints
=========
``GET /healthz``
    200 + ``{"status":"ok"|"degraded", "uptime_s": ...,
    "last_frame_age_s": ..., "clients": N, "state": "..."}`` when
    the bridge is in STREAMING and the watchdog is happy.  503 + same
    JSON shape when state != STREAMING OR ``last_frame_age_s`` >
    ``watchdog_timeout_s``.

``GET /metrics``
    200 + Prometheus text format.  Always returns the five required
    series (zero-valued if not yet seen).

``GET /`` (and any other path)
    404 + small JSON body.  No surprise HTML surface on this port.

CORS
====
For non-``*`` ``allowed_origins`` the server sets
``Access-Control-Allow-Origin`` to the matching origin.  Preflight
OPTIONS is answered for ``/healthz`` and ``/metrics`` only.
"""

from __future__ import annotations

import json
import logging
import ssl
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:  # avoid an import cycle at runtime
    from .config import Config

log = logging.getLogger("digital_twin_shell.http_control")


# ---------------------------------------------------------------------------
# Live state — mutated by the bridge, read by the HTTP thread.
# ---------------------------------------------------------------------------

class BridgeState:
    """Atomic-ish counters the HTTP control plane reads.

    All fields are simple types; CPython int/float/str assignments are
    GIL-atomic.  A reader may see a torn pair of fields (e.g. clients=N
    while frames_sent is mid-update) but never a corrupted one.  The
    Prometheus contract tolerates this.
    """

    __slots__ = (
        "started_at", "last_frame_at", "frames_sent",
        "errors_by_kind", "state", "clients",
        "fixture_index", "fixture_total", "fixture_loop",
    )

    def __init__(self) -> None:
        self.started_at: float = time.time()
        self.last_frame_at: float = 0.0
        self.frames_sent: int = 0
        self.errors_by_kind: dict = {}
        self.state: str = "CONNECTING"  # CONNECTING|STREAMING|DRAINING|SHUTDOWN
        self.clients: int = 0
        # Fixture progress: 0.0 to 1.0 (resets per loop iteration)
        self.fixture_index: int = 0
        self.fixture_total: int = 0
        self.fixture_loop: bool = False

    # Convenience accessors the HTTP handler uses ----------------------

    def uptime_s(self) -> float:
        return time.time() - self.started_at

    def last_frame_age_s(self) -> float:
        if self.last_frame_at == 0.0:
            return self.uptime_s()
        return max(0.0, time.time() - self.last_frame_at)

    def fixture_progress(self) -> float:
        if self.fixture_total <= 0:
            return 0.0
        return (self.fixture_index % self.fixture_total) / self.fixture_total

    def note_frame(self) -> None:
        self.frames_sent += 1
        self.last_frame_at = time.time()

    def note_error(self, kind: str) -> None:
        self.errors_by_kind[kind] = self.errors_by_kind.get(kind, 0) + 1

    def set_state(self, state: str) -> None:
        self.state = state


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

class _ControlHandler(BaseHTTPRequestHandler):
    # Per-request state, populated by the factory.
    bridge_state: BridgeState = None  # type: ignore[assignment]
    watchdog_timeout_s: float = 10.0
    allowed_origins: List[str] = None  # type: ignore[assignment]

    # Quieter access log — the JSON logger owns the operator's eye.
    def log_message(self, format: str, *args) -> None:  # noqa: A002
        log.debug("http %s - %s", self.address_string(), format % args)

    # --- routing --------------------------------------------------------

    def do_OPTIONS(self) -> None:  # noqa: N802 (BaseHTTPRequestHandler API)
        if self.path not in ("/healthz", "/metrics"):
            self._send_404()
            return
        origin = self.headers.get("Origin", "")
        allow_origin = self._resolve_cors(origin)
        self.send_response(204)
        if allow_origin:
            self.send_header("Access-Control-Allow-Origin", allow_origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods",
                             "GET, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        origin = self.headers.get("Origin", "")
        allow_origin = self._resolve_cors(origin)
        if self.path == "/healthz":
            self._handle_healthz(allow_origin)
        elif self.path == "/metrics":
            self._handle_metrics(allow_origin)
        else:
            self._send_404(allow_origin)

    # --- handlers -------------------------------------------------------

    def _handle_healthz(self, allow_origin: Optional[str]) -> None:
        s = self.bridge_state
        age = s.last_frame_age_s()
        # Degraded iff: state != STREAMING OR last_frame > watchdog
        degraded = (
            s.state != "STREAMING"
            or age > self.watchdog_timeout_s
        )
        body = {
            "status": "degraded" if degraded else "ok",
            "state": s.state,
            "uptime_s": round(s.uptime_s(), 3),
            "last_frame_age_s": round(age, 3),
            "clients": s.clients,
            "frames_sent": s.frames_sent,
        }
        self._send_json(503 if degraded else 200, body, allow_origin)

    def _handle_metrics(self, allow_origin: Optional[str]) -> None:
        s = self.bridge_state
        age = s.last_frame_age_s()
        progress = s.fixture_progress()
        # Errors as labelled counter series.
        error_lines = []
        for kind, count in sorted(s.errors_by_kind.items()):
            safe = _prom_label(kind)
            error_lines.append(
                f'dts_errors_total{{kind="{safe}"}} {count}'
            )
        # Always emit at least one zero-bucket so the metric exists.
        if not error_lines:
            error_lines.append('dts_errors_total{kind="none"} 0')

        body = (
            "# HELP dts_frames_sent_total Records broadcast to WS clients.\n"
            "# TYPE dts_frames_sent_total counter\n"
            f"dts_frames_sent_total {s.frames_sent}\n"
            "# HELP dts_clients_connected Currently connected WS clients.\n"
            "# TYPE dts_clients_connected gauge\n"
            f"dts_clients_connected {s.clients}\n"
            "# HELP dts_errors_total Bridge errors by kind.\n"
            "# TYPE dts_errors_total counter\n"
            + "\n".join(error_lines) + "\n"
            "# HELP dts_last_frame_age_seconds Seconds since the last upstream frame.\n"
            "# TYPE dts_last_frame_age_seconds gauge\n"
            f"dts_last_frame_age_seconds {age:.3f}\n"
            "# HELP dts_fixture_progress Fraction of the fixture consumed (0..1).\n"
            "# TYPE dts_fixture_progress gauge\n"
            f"dts_fixture_progress {progress:.4f}\n"
            "# HELP dts_state_info Current state (1.0 with state= label).\n"
            "# TYPE dts_state_info gauge\n"
            f'dts_state_info{{state="{_prom_label(s.state)}"}} 1.0\n'
        )
        self._send_text(200, body, allow_origin,
                        content_type="text/plain; version=0.0.4; charset=utf-8")

    # --- helpers --------------------------------------------------------

    def _resolve_cors(self, origin: str) -> Optional[str]:
        if "*" in self.allowed_origins:
            return "*" if origin else None
        if origin and origin in self.allowed_origins:
            return origin
        return None

    def _send_json(self, code: int, body: dict,
                   allow_origin: Optional[str]) -> None:
        payload = json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        if allow_origin:
            self.send_header("Access-Control-Allow-Origin", allow_origin)
            self.send_header("Vary", "Origin")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _send_text(self, code: int, body: str,
                   allow_origin: Optional[str], *,
                   content_type: str = "text/plain; charset=utf-8") -> None:
        payload = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        if allow_origin:
            self.send_header("Access-Control-Allow-Origin", allow_origin)
            self.send_header("Vary", "Origin")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _send_404(self, allow_origin: Optional[str] = None) -> None:
        body = {"error": "not found", "path": self.path}
        self._send_json(404, body, allow_origin)


# ---------------------------------------------------------------------------
# Server factory
# ---------------------------------------------------------------------------

def make_handler(state: BridgeState, watchdog_timeout_s: float,
                 allowed_origins: List[str]):
    """Return a ``_ControlHandler`` subclass bound to ``state``.

    Class-attribute defaults are set with a metaclass trick: subclass
    ``type`` to inject the values directly into the class namespace so
    Python's class-body scoping doesn't shadow them with closure
    lookups during class creation.
    """

    cls_body = dict(
        bridge_state=state,
        watchdog_timeout_s=watchdog_timeout_s,
        allowed_origins=allowed_origins,
    )
    return type("_BoundHandler", (_ControlHandler,), cls_body)


def _prom_label(value: str) -> str:
    """Make ``value`` safe for a Prometheus label: replace common
    delimiters and quote-escape."""
    return (
        value.replace("\\", "\\\\")
             .replace('"', '\\"')
             .replace("\n", " ")
    )


class ControlServer:
    """Thin lifecycle wrapper around :class:`ThreadingHTTPServer`.

    Usage::

        srv = ControlServer(cfg, state)
        srv.start()
        ...
        srv.stop()

    The server runs in a daemon thread.  ``stop()`` is idempotent and
    safe to call from the asyncio event loop (``server.shutdown`` is
    blocking but the HTTP thread is short-lived once the loop signals
    it).
    """

    def __init__(self, cfg: "Config", state: BridgeState) -> None:
        self.cfg = cfg
        self.state = state
        self._thread: Optional[threading.Thread] = None
        self._httpd: Optional[ThreadingHTTPServer] = None
        self._ssl_health: Optional[ssl.SSLContext] = None

    # -------------------------------------------------------------------

    def _build_server(self) -> ThreadingHTTPServer:
        handler = make_handler(
            self.state, self.cfg.watchdog_timeout_s,
            self.cfg.allowed_origins,
        )
        httpd = ThreadingHTTPServer(
            (self.cfg.bridge_host, self.cfg.health_port), handler
        )
        # Optional TLS for the health port (separate cert from WS).
        if self.cfg.tls_cert_health and self.cfg.tls_key_health:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(
                certfile=self.cfg.tls_cert_health,
                keyfile=self.cfg.tls_key_health,
            )
            httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
            self._ssl_health = ctx
        return httpd

    def start(self) -> None:
        self._httpd = self._build_server()
        scheme = "https" if self._ssl_health else "http"
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            name="dts-control",
            daemon=True,
        )
        self._thread.start()
        log.info("control server listening",
                 extra={
                     "scheme": scheme,
                     "host": self.cfg.bridge_host,
                     "port": self.cfg.health_port,
                     "path": "/healthz, /metrics",
                 })

    def stop(self) -> None:
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
                self._httpd.server_close()
            except Exception as exc:  # pragma: no cover - best-effort
                log.warning("control server stop failed",
                            extra={"error": str(exc)})
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._httpd = None
        self._thread = None


# ---------------------------------------------------------------------------
# Standalone smoke entry — runs /healthz + /metrics against a fixture
# record stream, useful for local debugging.
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:  # pragma: no cover
    import argparse
    from .config import Config

    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, default=8766)
    p.add_argument("--watchdog", type=float, default=10.0)
    args = p.parse_args(argv)

    cfg = Config.from_env()
    cfg.health_port = args.port
    cfg.watchdog_timeout_s = args.watchdog
    state = BridgeState()
    state.set_state("STREAMING")
    state.last_frame_at = time.time()
    state.fixture_total = 1
    state.fixture_index = 0

    srv = ControlServer(cfg, state)
    srv.start()
    print(f"control server on {args.port}; Ctrl-C to stop",
          flush=True)
    try:
        while True:
            time.sleep(1.0)
            state.frames_sent += 1
    except KeyboardInterrupt:
        pass
    finally:
        srv.stop()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
