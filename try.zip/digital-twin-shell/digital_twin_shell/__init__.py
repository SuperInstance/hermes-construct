"""digital-twin-shell — the visible reef surface where the agents live.

This package ships the Python WebSocket bridge that consumes the JSONL fixture
produced by (the eventual I/O layer of) ``cocapn-marine`` and re-broadcasts it
to any browser connected on the bridge laptop.

It has *no* runtime dependency on ``cocapn-marine`` itself — the bridge speaks
the JSON contract the Rust crate will one day serialise. See
``CONTRACT.md`` for the wire format.
"""

__all__ = ["__version__"]
__version__ = "0.1.0"