"""
gen_fixture.py — produce a 120-record (2 min @ 1 Hz) JSONL fixture that
exercises the full wire contract: vessel, autopilot, bathy, deadband,
timestamp, plus optional agent voice, fleet cross-traffic, conservation
state, and at least one Gap event + one kintsugi-seam depth discrepancy.

Hand-curated to feel like a realistic track around the 50-fathom contour.
Run as a module to regenerate, or import `build_records()` for tests.
"""

from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional


# Anchor for the track: somewhere realistic on the eastern shelf.
# (Not a real spot — chosen for round numbers.)
START_LAT = 57.2333   # 57°14'N
START_LON = -150.4500  # 150°27'W (Alaska-ish shelf)

VESSEL_NAMES = ["Cormorant", "Meridian", "Resolute"]


def lat_deg(lat: float) -> str:
    """Format lat as '57°14'N'-ish."""
    hemi = "N" if lat >= 0 else "S"
    deg = int(abs(lat))
    minutes = int(round((abs(lat) - deg) * 60))
    return f"{deg}°{minutes:02d}'{hemi}"


def lon_deg(lon: float) -> str:
    hemi = "E" if lon >= 0 else "W"
    deg = int(abs(lon))
    minutes = int(round((abs(lon) - deg) * 60))
    return f"{deg}°{minutes:02d}'{hemi}"


def build_records(*, hz: float = 1.0,
                  n: int = 120,
                  start: Optional[datetime] = None) -> list[dict]:
    """Build the 2-minute track."""
    if start is None:
        start = datetime(2026, 7, 10, 12, 0, 0, tzinfo=timezone.utc)

    records: list[dict] = []
    sog_knots_base = 6.2

    # Fleet members — start positions offset from the boat, in nautical miles.
    # 1 deg lat ~= 60 nm; 1 deg lon at 57N ~= 32 nm.
    fleet_initial_offset_nm = {
        "Cormorant": (3.2, -4.1),
        "Meridian":  (-2.4, 5.0),
        "Resolute":  (4.6,  2.7),
    }

    for i in range(n):
        ts = (start + timedelta(seconds=i / hz)).isoformat().replace(
            "+00:00", "Z"
        )

        # Slow drift — boat makes 0.5 nm every 10 seconds south-southwest
        # along the contour. 1 deg lat = 60 nm, so 0.5 nm = 0.0083 deg.
        dlat = -0.0083 * (i / 10.0)
        dlon = -0.0050 * (i / 10.0)
        lat = START_LAT + dlat
        lon = START_LON + dlon

        # Heading drifts slightly: 270° -> 273° -> 268° over the run.
        heading = 270.0 + 3.0 * math.sin(i / 18.0)
        sog = sog_knots_base + 0.6 * math.sin(i / 9.0)
        cog = heading + 0.4 * math.sin(i / 11.0)

        # Rudder follows heading error; clamp to a realistic band.
        rudder = max(-15.0, min(15.0, (heading - 270.0) * 1.6))

        # Bathymetry: the boat is trolling the 50-fathom (~91.4 m) edge.
        # Real bathy depth oscillates slightly around 92. depth_m from
        # the live sounder drifts +/- 0.8 m.
        bathy_depth = 92.0 + 0.7 * math.sin(i / 14.0)
        live_depth = bathy_depth + 0.6 * math.cos(i / 6.5)

        # Kintsugi event: around t=35..42s, the live sounder disagrees with
        # the chart by > 2.0 m for several seconds — that's our seam.
        if 35 <= i <= 42:
            live_depth = bathy_depth + 3.1 + 0.3 * math.sin(i)

        # Gap event: t=70..78s — heading_ok trips false (cross-current),
        # AND at t=78..82 the 50-fathom contour indicator drops because
        # we're drifting onto the shallow shelf.
        heading_ok = True
        depth_ok = True
        speed_ok = True
        contour_50fathom = True

        if 70 <= i <= 78:
            heading_ok = False  # a gap opens in heading confidence
        if 78 <= i <= 82:
            contour_50fathom = False  # drift onto the shelf

        # Deadband responds: if contour or heading drift, deadband flags it.
        if not heading_ok or not contour_50fathom:
            depth_ok = False

        # Fleet cross-traffic: at t=50..65, one of the fleet (Meridian)
        # swings into the boat's vicinity. Each frame carries a small
        # snapshot of fleet positions.
        fleet = []
        for name, (dlat_off, dlon_off) in fleet_initial_offset_nm.items():
            # Meridian converges on the boat around t=50..65.
            if name == "Meridian" and 50 <= i <= 65:
                proximity = 1.0 - (i - 50) / 15.0  # 1.0 -> 0.0
                dlat_off *= max(0.3, proximity)
                dlon_off *= max(0.3, proximity)
            ghost_lat = lat + (dlat_off / 60.0) + 0.0008 * math.sin(
                i / 10.0 + hash(name) % 7
            )
            ghost_lon = lon + (dlon_off / 32.0) + 0.0006 * math.cos(
                i / 12.0 + hash(name) % 5
            )
            ghost_heading = 268.0 + 4.0 * math.cos(i / 16.0 + hash(name) % 4)
            fleet.append({
                "name": name,
                "lat": round(ghost_lat, 6),
                "lon": round(ghost_lon, 6),
                "heading_deg": round(ghost_heading, 2),
            })

        # Conservation state: gamma + eta <= C
        # gamma = "productive signal" (e.g., on-course fraction in window)
        # eta   = "loss / drift" (e.g., heading error magnitude in degrees)
        gamma = 0.86 + 0.04 * math.sin(i / 13.0)
        eta = 0.08 + 0.05 * (1.0 if not heading_ok else 0.0)
        C = 1.0
        conservation = {
            "gamma": round(gamma, 4),
            "eta": round(eta, 4),
            "C": C,
            "headroom": round(max(0.0, C - gamma - eta), 4),
        }

        # Agent voice — CoCapn reads the situation in the lore's voice.
        # Updated only on interesting frames so the UI doesn't spam the captain.
        agent_voice = None
        interesting = (
            (i % 6 == 0)
            or (not heading_ok)
            or (not contour_50fathom)
            or (35 <= i <= 42)
        )
        if interesting:
            if not heading_ok and not contour_50fathom:
                voice = (
                    "CoCapn: course drift and shelf-edge approach. "
                    f"Gap forming at {lat_deg(lat)} {lon_deg(lon)} — scouting."
                )
            elif not contour_50fathom:
                voice = (
                    "CoCapn: chart says 50-fathom; sounder disagrees. "
                    f"Kintsugi seam open near {lat_deg(lat)}."
                )
            elif not heading_ok:
                voice = (
                    f"CoCapn: heading {heading:.0f}°, rudder {rudder:.1f}°, "
                    "off course — recomputing."
                )
            elif 35 <= i <= 42:
                voice = (
                    "CoCapn: depth delta +3.1m vs. chart. "
                    "Kintsugi seam logged — golden."
                )
            else:
                voice = (
                    f"CoCapn: course {heading:.0f}°, rudder {rudder:.1f}°, "
                    "on course."
                )
            agent_voice = {"speaker": "CoCapn", "text": voice}

        rec = {
            "vessel": {
                "lat": round(lat, 6),
                "lon": round(lon, 6),
                "heading_deg": round(heading, 2),
                "sog_knots": round(sog, 2),
                "cog_deg": round(cog, 2),
            },
            "depth_m": round(live_depth, 2),
            "rudder_command_deg": round(rudder, 2),
            "autopilot": {
                "on_course": heading_ok,
                "target_heading_deg": 270.0,
            },
            "bathy": {
                "depth_m": round(bathy_depth, 2),
                "contour_50fathom": contour_50fathom,
            },
            "deadband": {
                "heading_ok": heading_ok,
                "depth_ok": depth_ok,
                "speed_ok": speed_ok,
            },
            "timestamp": ts,
            "fleet": fleet,
            "conservation": conservation,
        }
        if agent_voice is not None:
            rec["agent"] = agent_voice

        records.append(rec)

    return records


def write_fixture(records: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, separators=(",", ":")))
            f.write("\n")


def main() -> int:
    out = Path(__file__).resolve().parent.parent / "sample-fixture.jsonl"
    records = build_records()
    write_fixture(records, out)
    print(f"wrote {len(records)} records → {out}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())