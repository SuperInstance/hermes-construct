"""
config.py — typed, env-driven configuration for the digital-twin bridge.

Single source of truth for every tunable knob.  ``bridge.py`` instantiates
one ``Config`` at startup and reads nothing else from the environment
afterwards.

Why a dataclass (not a dict) — every field is typed, has a default, and
appears in :func:`describe` for the README env-var table.

Why a separate module — keeps the bridge module focused on transport;
allows tests to import and mutate fields without touching the bridge
code, and lets future tooling (e.g. a CLI flag parser, a YAML loader)
plug in by subclassing.

Hard rule: NO hardcoded ports, hosts, log levels, fixture paths, or
auth tokens anywhere in the runtime code.  Every value comes from here.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TRUE = frozenset({"1", "true", "yes", "on", "y", "t"})
_FALSE = frozenset({"0", "false", "no", "off", "n", "f", ""})


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    low = raw.strip().lower()
    if low in _TRUE:
        return True
    if low in _FALSE:
        return False
    raise ValueError(
        f"{name}={raw!r}: expected one of true/false/1/0/yes/no/on/off"
    )


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"{name}={raw!r}: expected integer") from exc


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise ValueError(f"{name}={raw!r}: expected float") from exc


def _env_str(name: str, default: str) -> str:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw


# ---------------------------------------------------------------------------
# Log level normalisation
# ---------------------------------------------------------------------------

_LOG_LEVELS = {
    "DEBUG": 10, "INFO": 20, "WARNING": 30, "WARN": 30, "ERROR": 40,
}


def _env_log_level(name: str, default: str) -> int:
    raw = (_env_str(name, default) or "").upper()
    if raw not in _LOG_LEVELS:
        raise ValueError(
            f"{name}={raw!r}: expected one of DEBUG/INFO/WARNING/ERROR"
        )
    return _LOG_LEVELS[raw]


def log_level_name(level: int) -> str:
    """Return the canonical uppercase name for an int level."""
    for name, val in _LOG_LEVELS.items():
        if val == level:
            return name
    return "INFO"


# ---------------------------------------------------------------------------
# Origin parsing
# ---------------------------------------------------------------------------

def _env_origins(name: str, default: str) -> List[str]:
    raw = _env_str(name, default) or "*"
    if raw.strip() == "*":
        return ["*"]
    return [o.strip() for o in raw.split(",") if o.strip()]


# ---------------------------------------------------------------------------
# The Config dataclass
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """All env-driven configuration in one typed bundle.

    Defaults match the README's "happy-path" dev invocation.  Override
    any field via the ``DTS_*`` environment variables.
    """

    # -- transport ----------------------------------------------------------
    bridge_host: str = "0.0.0.0"
    bridge_port: int = 8765
    health_port: int = 8766  # default: +1 from bridge_port
    hz: float = 1.0

    # -- fixture ------------------------------------------------------------
    fixture_path: str = "sample-fixture.jsonl"  # resolved relative to REPO
    loop_fixture: bool = False

    # -- logging ------------------------------------------------------------
    log_level: int = 20  # INFO
    log_format: str = "json"  # "json" or "text"

    # -- auth & CORS --------------------------------------------------------
    auth_token: str = ""  # empty = auth disabled
    allowed_origins: List[str] = field(default_factory=lambda: ["*"])

    # -- TLS ----------------------------------------------------------------
    tls_cert: str = ""  # empty = no TLS (ws://)
    tls_key: str = ""
    tls_cert_health: str = ""  # separate cert for control server
    tls_key_health: str = ""

    # -- limits & health ----------------------------------------------------
    max_clients: int = 64
    max_frame_bytes: int = 65536
    max_messages_per_sec: int = 10
    watchdog_timeout_s: float = 10.0

    # -- runtime flags ------------------------------------------------------
    env: str = "dev"  # "dev" | "production" | "staging"
    telemetry_endpoint: str = ""  # empty = console-only

    # -- derived paths ------------------------------------------------------
    repo_root: Optional[Path] = None  # set by from_env()

    # -----------------------------------------------------------------------

    @classmethod
    def from_env(cls, *, repo_root: Optional[Path] = None,
                 argv: Optional[List[str]] = None) -> "Config":
        """Read every DTS_* var from the environment and return a Config.

        ``argv`` is accepted for symmetry with the bridge CLI but is
        currently unused — env vars are the only source.
        """
        bridge_port = _env_int("DTS_BRIDGE_PORT", 8765)
        health_port_env = os.environ.get("DTS_HEALTH_PORT")
        if health_port_env is None or health_port_env == "":
            health_port = bridge_port + 1
        else:
            health_port = _env_int("DTS_HEALTH_PORT", bridge_port + 1)

        cfg = cls(
            bridge_host=_env_str("DTS_BRIDGE_HOST", "0.0.0.0"),
            bridge_port=bridge_port,
            health_port=health_port,
            hz=_env_float("DTS_BRIDGE_HZ", 1.0),
            fixture_path=_env_str(
                "DTS_BRIDGE_FIXTURE", "sample-fixture.jsonl"
            ),
            loop_fixture=_env_bool("DTS_BRIDGE_LOOP", False),
            log_level=_env_log_level("DTS_LOG_LEVEL", "INFO"),
            log_format=_env_str("DTS_LOG_FORMAT", "json").lower(),
            auth_token=_env_str("DTS_AUTH_TOKEN", ""),
            allowed_origins=_env_origins("DTS_ALLOWED_ORIGINS", "*"),
            tls_cert=_env_str("DTS_TLS_CERT", ""),
            tls_key=_env_str("DTS_TLS_KEY", ""),
            tls_cert_health=_env_str("DTS_TLS_CERT_HEALTH", ""),
            tls_key_health=_env_str("DTS_TLS_KEY_HEALTH", ""),
            max_clients=_env_int("DTS_MAX_CLIENTS", 64),
            max_frame_bytes=_env_int("DTS_MAX_FRAME_BYTES", 65536),
            max_messages_per_sec=_env_int(
                "DTS_MAX_MESSAGES_PER_SEC", 10
            ),
            watchdog_timeout_s=_env_float("DTS_WATCHDOG_TIMEOUT_S", 10.0),
            env=_env_str("DTS_ENV", "dev").lower(),
            telemetry_endpoint=_env_str("DTS_TELEMETRY_ENDPOINT", ""),
            repo_root=repo_root,
        )
        cfg.validate()
        return cfg

    # -----------------------------------------------------------------------

    def validate(self) -> None:
        """Cross-field sanity checks. Raises ValueError on bad config."""
        if self.log_format not in ("json", "text"):
            raise ValueError(
                f"DTS_LOG_FORMAT={self.log_format!r}: expected json|text"
            )
        if self.bridge_port < 1 or self.bridge_port > 65535:
            raise ValueError(
                f"DTS_BRIDGE_PORT={self.bridge_port}: must be 1..65535"
            )
        if self.health_port < 1 or self.health_port > 65535:
            raise ValueError(
                f"DTS_HEALTH_PORT={self.health_port}: must be 1..65535"
            )
        if self.bridge_port == self.health_port:
            raise ValueError(
                f"DTS_BRIDGE_PORT and DTS_HEALTH_PORT collide at "
                f"{self.bridge_port}; they must differ"
            )
        if self.hz <= 0:
            raise ValueError(f"DTS_BRIDGE_HZ={self.hz}: must be > 0")
        if self.max_clients < 1:
            raise ValueError(
                f"DTS_MAX_CLIENTS={self.max_clients}: must be >= 1"
            )
        if self.max_frame_bytes < 64:
            raise ValueError(
                f"DTS_MAX_FRAME_BYTES={self.max_frame_bytes}: must be >= 64"
            )
        if self.max_messages_per_sec < 1:
            raise ValueError(
                f"DTS_MAX_MESSAGES_PER_SEC={self.max_messages_per_sec}: "
                f"must be >= 1"
            )
        if self.watchdog_timeout_s < 0:
            raise ValueError(
                f"DTS_WATCHDOG_TIMEOUT_S={self.watchdog_timeout_s}: must be >= 0"
            )
        # TLS keys require the matching cert
        if bool(self.tls_cert) != bool(self.tls_key):
            raise ValueError(
                "DTS_TLS_CERT and DTS_TLS_KEY must be set together"
            )
        if bool(self.tls_cert_health) != bool(self.tls_key_health):
            raise ValueError(
                "DTS_TLS_CERT_HEALTH and DTS_TLS_KEY_HEALTH must be set together"
            )
        # Production-mode safety: refuse to boot without auth in production.
        if self.env == "production" and not self.auth_token:
            raise ValueError(
                "DTS_ENV=production requires DTS_AUTH_TOKEN to be set. "
                "Refusing to start with auth disabled in production mode."
            )

    # -----------------------------------------------------------------------

    def resolve_fixture(self) -> Path:
        """Return the absolute fixture path.  If relative, anchor to
        ``repo_root``; else honour the path verbatim."""
        p = Path(self.fixture_path)
        if not p.is_absolute() and self.repo_root is not None:
            p = self.repo_root / p
        return p

    # -----------------------------------------------------------------------

    def to_dict(self) -> dict:
        """JSON-safe representation.  Logger level is rendered by name."""
        d = asdict(self)
        d["log_level"] = log_level_name(self.log_level)
        d["repo_root"] = str(self.repo_root) if self.repo_root else None
        return d


# ---------------------------------------------------------------------------
# Self-describing env-var table (used by README + /healthz debug block)
# ---------------------------------------------------------------------------

ENV_TABLE: List[dict] = [
    {"name": "DTS_BRIDGE_HOST", "default": "0.0.0.0",
     "description": "Interface the WS bridge binds to."},
    {"name": "DTS_BRIDGE_PORT", "default": "8765",
     "description": "TCP port the WS bridge listens on."},
    {"name": "DTS_BRIDGE_FIXTURE", "default": "sample-fixture.jsonl",
     "description": "JSONL fixture file (relative to repo root or absolute)."},
    {"name": "DTS_BRIDGE_HZ", "default": "1.0",
     "description": "Replay rate in records per second."},
    {"name": "DTS_BRIDGE_LOOP", "default": "false",
     "description": "Loop the fixture forever (good for demos)."},
    {"name": "DTS_LOG_LEVEL", "default": "INFO",
     "description": "Log level: DEBUG | INFO | WARNING | ERROR."},
    {"name": "DTS_LOG_FORMAT", "default": "json",
     "description": "Log line format: json | text."},
    {"name": "DTS_AUTH_TOKEN", "default": "",
     "description": "If set, clients must present this token to upgrade."},
    {"name": "DTS_ALLOWED_ORIGINS", "default": "*",
     "description": "Comma-separated allowed Origin headers, or '*'."},
    {"name": "DTS_TLS_CERT", "default": "",
     "description": "Path to TLS cert for WSS (empty = WS)."},
    {"name": "DTS_TLS_KEY", "default": "",
     "description": "Path to TLS key for WSS (empty = WS)."},
    {"name": "DTS_TLS_CERT_HEALTH", "default": "",
     "description": "Optional separate cert for the HTTPS control server."},
    {"name": "DTS_TLS_KEY_HEALTH", "default": "",
     "description": "Optional separate key for the HTTPS control server."},
    {"name": "DTS_MAX_CLIENTS", "default": "64",
     "description": "Max concurrent WS clients (0 = no cap)."},
    {"name": "DTS_MAX_FRAME_BYTES", "default": "65536",
     "description": "Reject any incoming WS message larger than this."},
    {"name": "DTS_MAX_MESSAGES_PER_SEC", "default": "10",
     "description": "Per-client incoming rate cap; over -> close 1008."},
    {"name": "DTS_HEALTH_PORT", "default": "<BRIDGE_PORT>+1",
     "description": "HTTP control port (health, metrics)."},
    {"name": "DTS_WATCHDOG_TIMEOUT_S", "default": "10",
     "description": "Seconds without upstream before /healthz flips degraded."},
    {"name": "DTS_ENV", "default": "dev",
     "description": "dev | production. Production requires DTS_AUTH_TOKEN."},
    {"name": "DTS_TELEMETRY_ENDPOINT", "default": "",
     "description": "If set, browser telemetry POSTs to this URL."},
]


def main(argv: Optional[List[str]] = None) -> int:
    """Print the resolved config as JSON.  Useful as a smoke check."""
    import json
    try:
        cfg = Config.from_env()
    except ValueError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(cfg.to_dict(), indent=2, default=str))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
