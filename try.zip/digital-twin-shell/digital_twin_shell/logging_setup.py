"""
logging_setup.py — stdlib JSON-or-text logging for the digital-twin bridge.

Goals
=====
* Every log line is a single JSON object on stdout (default) so log
  shippers (Loki, Datadog, vector, etc.) can ingest without a parser.
* ``DTS_LOG_FORMAT=text`` falls back to a human-readable format
  (the old ``"%(asctime)s %(levelname)s %(name)s | %(message)s"``) for
  the local Captain running the bridge in a terminal.
* No third-party deps — stdlib only.  The JSON formatter is a
  60-line ``logging.Formatter`` subclass.
* The ``extra={...}`` kwargs to a log call become top-level fields in
  the JSON object.  This is the key extension point for structured
  tracing: ``log.info("client connected", extra={"client_ip": ip})``
  produces ``{"...","client_ip":"1.2.3.4"}``.
* The record's ``created`` timestamp is rendered as ISO 8601 UTC.

Why not ``python-json-logger`` — added dependency for a one-formatter
feature.  Stdlib is enough and the test suite stays hermetic.
"""

from __future__ import annotations

import json
import logging
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict


# Standard LogRecord attributes we copy to the JSON object — anything
# in ``extra`` is layered on top.  See the Python docs for the full set.
_STD_ATTRS = frozenset({
    "args", "asctime", "created", "exc_info", "exc_text", "filename",
    "funcName", "levelname", "levelno", "lineno", "message", "module",
    "msecs", "msg", "name", "pathname", "process", "processName",
    "relativeCreated", "stack_info", "thread", "threadName",
})


class JsonFormatter(logging.Formatter):
    """Render a LogRecord as a single-line JSON object.

    The shape is stable: ``ts`` (ISO 8601 UTC), ``level``, ``logger``,
    ``msg``, then everything from ``extra`` (or any non-standard
    attribute) as additional keys.  Exceptions are rendered as
    ``exc_info`` (the formatted traceback) so the log line stays
    single-line JSON but still carries the stack.
    """

    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "ts": _iso(record.created),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # Thread/process tags — handy for concurrency debugging.
        payload["thread"] = record.threadName
        payload["process"] = record.process

        # Anything passed via ``extra=`` or set as a non-standard attr.
        for key, value in record.__dict__.items():
            if key in _STD_ATTRS or key in payload:
                continue
            if key.startswith("_"):
                continue
            payload[key] = _safe(value)

        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        if record.stack_info:
            payload["stack_info"] = self.formatStack(record.stack_info)
        return json.dumps(payload, ensure_ascii=False, default=_safe)


class TextFormatter(logging.Formatter):
    """The human-readable fallback used when DTS_LOG_FORMAT=text."""

    def __init__(self) -> None:
        super().__init__(
            fmt="%(asctime)s %(levelname)s %(name)s | %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S%z",
        )

    def format(self, record: logging.LogRecord) -> str:
        # Render the base text line…
        out = super().format(record)
        # …then append any ``extra={...}`` as a trailing key=value list
        # so structured fields survive even in text mode.
        extras = []
        for key, value in record.__dict__.items():
            if key in _STD_ATTRS or key.startswith("_"):
                continue
            extras.append(f"{key}={value!r}")
        if extras:
            out = out + "  " + " ".join(extras)
        if record.exc_info:
            out = out + "\n" + self.formatException(record.exc_info)
        return out


def _iso(epoch_seconds: float) -> str:
    """Render an epoch second as ISO 8601 UTC with millisecond precision."""
    dt = datetime.fromtimestamp(epoch_seconds, tz=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{int(dt.microsecond / 1000):03d}Z"


def _safe(value: Any) -> Any:
    """Coerce non-JSON-serializable values into strings.

    Most log payloads are primitives; the only common case is bytes
    (which we decode as utf-8 with surrogate-escape on failure).
    """
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("utf-8", errors="replace")
    if isinstance(value, set):
        return sorted(value)
    return str(value)


def configure_logging(*, level: int = logging.INFO,
                      fmt: str = "json",
                      stream=None) -> None:
    """Install the bridge's root logger handler.

    Idempotent — calling twice replaces the handler rather than
    duplicating output.  ``stream`` defaults to ``sys.stdout`` so
    containers can capture both streams together if they want.
    """
    root = logging.getLogger()
    # Wipe any pre-existing handlers (e.g. default root config).
    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler(stream if stream is not None
                                    else sys.stdout)
    if fmt == "json":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(TextFormatter())
    root.addHandler(handler)
    root.setLevel(level)

    # Tame chatty third-party loggers.
    for noisy in ("websockets.server", "websockets.protocol",
                  "asyncio", "urllib3"):
        logging.getLogger(noisy).setLevel(max(level, logging.INFO))


# Re-export ``time`` so callers can do ``logging_setup.time.time()``
# without an extra import (the bridge module already imports it).
time = time


if __name__ == "__main__":  # pragma: no cover
    # Self-test: emit a few lines in both formats so the operator
    # can sanity-check the output.
    configure_logging(level=logging.DEBUG, fmt="json")
    log = logging.getLogger("digital_twin_shell.logging_setup")
    log.debug("debug line")
    log.info("info line", extra={"client_ip": "10.0.0.1"})
    log.warning("warn with extras", extra={"retry": 3, "ctx": {"a": 1}})
    log.error("error with stack", exc_info=ValueError("boom"))

    print("---", file=sys.stderr)
    configure_logging(level=logging.INFO, fmt="text")
    log.info("text-mode line", extra={"client_ip": "10.0.0.1"})
