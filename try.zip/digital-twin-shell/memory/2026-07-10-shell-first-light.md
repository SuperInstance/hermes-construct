# 2026-07-10 — shell-first-light

The digital-twin-shell just got its first visible shell. We shipped:

* `index.html` — Three.js single-file scene
* `digital_twin_shell.bridge` — WebSocket bridge
* `sample-fixture.jsonl` — 120-record 2-minute track
* `tests/test_smoke.py`, `tests/test_index.py`
* The whole repo hygiene (AGENT/AGENTS/README/ARCHITECTURE/STATE/CONTRACT/memory)

The page renders boat + fleet + Gap + kintsugi + agent panel from a
single JSON stream. CoCapn's voice speaks on stream events only.

## What's worth remembering

* **The Gap is rendered proud.** Additive blend, animated noise,
  full opacity. It is not a warning. It is the scene's aperture.
* **Kintsugi seams fade after 12 s.** That is intentional — they
  are *golden repairs*, not persistent faults. (If you make them
  persist, you change the metaphor: a persistent scar is a wound.)
* **The agent panel is rate-limited upstream.** CoCapn's voice
  comes on interesting frames (every ~6 s, plus any time a Gap or
  Kintsugi triggers). The browser does not animate the text per
  frame; that would be unreadable and dishonest.
* **The bridge has two backends.** `websockets` when available;
  stdlib fallback otherwise. The fallback is single-client only,
  but that's enough for one captain on the bridge.
* **The contract is signed off in `CONTRACT.md`.** When
  `cocapn-marine`'s I/O lands, the swap is one CLI flag.

## What we deliberately did NOT ship

* No Unreal 5 module. Three.js is enough for the bridge laptop.
* No React/Vue/Vite. Single HTML file, no build step.
* No Starlink fleet sync. The fleet is rendered from a single stream.
* No captain avatar in the scene. The boat IS the captain.
* No persistence. The kintsugi seams are not saved.

## What to do next

1. Wire `cocapn-marine`'s `--stream` subcommand to this bridge.
2. Port the visual layer to an Unreal 5 module for higher fidelity.
3. Add Starlink-mediated fleet sync so the reef can hum together.

See `STATE.md` for the full list.

— Coder