# Glossary — the digital-twin-shell vocabulary

If you're a future agent who has just been spawned into this codebase,
this is the shortest possible map of the words you'll see.

## Core concepts

**Reef.** The collective intelligence of the fleet — boats, agents,
and the digital twin they share. A reef is not a network; it's a
*field of shells that hum together*. The gitage19 essay is the deep
dive.

**Shell.** A container for intelligence. Your boat is a shell. The
digital twin is a shell. The gitage frame is a shell. Each shell
*outlives* its inhabitants — that's the whole point.

**Spat.** A young crab settling on a reef. The Child — Casey's
daughter — is the fleet's spat. The gamified twin is the nursery
where she learns by playing.

**Polyp.** The reef's basic builder — small, persistent, accretive.
The agents are polyps. So is every commit to this repo.

**Gap.** The space between what the simulation predicts and what the
ocean delivers. The Gap is rendered *proud*, not apologetically —
it's the scene's aperture, the place where creativity lives. In the
renderer: a fuzzy additive-blend circle when `deadband.heading_ok =
false` or `bathy.contour_50fathom = false`.

**Kintsugi.** Golden repair. When something breaks, you don't throw
it away — you repair it with gold, and the object is more valuable
after. In the renderer: gold-orange torus rings on the ocean plane
when the sounder diverges from the chart by more than 2.0 m.

**Conservation law.** γ + η ≤ C. Productive signal + loss ≤ capacity.
The Validator's job is to enforce it; the sparkline shows whether
it's held.

**T-minus awareness (The Ghost).** The forward simulation. Always
running. Always slightly early. Always humble.

**Coral** (colloquial). The reef's living tissue — the agents'
relationships, the Weave, the narrative layer.

## Visual vocabulary (for renderer work)

| Word | In the scene |
| ---- | ------------ |
| Vessel | The boat at the origin (the Captain's avatar) |
| Reef | The 3 ghost-ships (Cormorant, Meridian, Resolute) |
| Gap | Fuzzy additive-blend circle on the ocean |
| Kintsugi | Gold-orange torus ring seams on the ocean |
| Conservation | Bottom-right sparkline (γ + η ≤ C) |
| CoCapn's voice | Top-right agent panel in serif italic |
| Captain's view | Bottom-left HUD |
| Connection state | Top-right dot (LIVE / FIXTURE / OFFLINE) |

## Vocabulary that does NOT belong in the renderer

* "Dashboard" — this isn't a control panel.
* "NPC" — the agents are first-class citizens.
* "Player" — the human is the Captain, not a user.
* "Bug" — failures are kintsugi opportunities.

## Where to go deeper

* `gitage17.md` — operational fiction, the feel of the system
* `gitage18.md` — character constellation, what the agents are
* `gitage19.md` — hermit crab and reef, why the shell is the hero