# AGENT.md — Onboarding for any future agent

> *You are reading this because you've been spawned — or you've spawned
> yourself — into the digital-twin-shell repository. Welcome aboard.*

## What this is

`digital-twin-shell` is the **visible reef surface** for the SuperInstance
fleet — the layer where the agents (CoCapn, Scout, Validator, etc.) live as
first-class citizens. It is a single-page Three.js scene streamed from a
Python WebSocket bridge that consumes a JSONL fixture shaped like the
eventual `cocapn-marine` snapshot.

It is not a game. It is not a dashboard. It is the **shell** that the fleet
inhabits — the way a hermit crab inhabits a whelk's shell, only the shell
is rendered in WebGL and the crabs are people.

## Where the lore lives

The conceptual foundation is in the gitage archive (look at
`gitage18.md` and `gitage19.md` in particular):

| File | What it gives you |
| ---- | ----------------- |
| `gitage17.md` | The operational fiction — what it feels like to be inside this system |
| `gitage18.md` | The character constellation — Captain, CoCapn, Scout, Validator, Fleet, Gap, Kintsugi |
| `gitage19.md` | The hermit-crab-and-reef essay — Shell, Polyp, Spat, Reef as the deep vocabulary |

Don't skip these. The renderer is built on their visual vocabulary:
the Gap is the fuzzy circle on the chart, the kintsugi seams are
golden scars-as-decoration, the ghost fleet are the other shells in the
reef.

## Where the code lives

```
digital-twin-shell/
├── index.html                  # the entire Three.js scene, single file
├── sample-fixture.jsonl        # 120 records (2 min @ 1 Hz) of a 50-fathom track
├── contracts/
│   └── contract_projection.rs  # canonical Rust source for the wire contract
├── digital_twin_shell/         # the Python package
│   ├── __init__.py
│   ├── cocapn_contract.py      # parses contracts/contract_projection.rs
│   ├── bridge.py               # the WS server + JSONL reader
│   └── gen_fixture.py          # regenerates sample-fixture.jsonl
├── tests/
│   ├── test_smoke.py           # contract + WS roundtrip
│   ├── test_index.py           # HTML health (Playwright → curl fallback)
│   ├── test_index_with_bridge.py  # full bridge integration
│   └── test_visual_events.py   # Gap + kintsugi visualizations
├── bin/dev.sh                  # one-shot local dev (bridge + static + open browser)
├── pyproject.toml              # websockets>=12 runtime, pytest dev
├── README.md, ARCHITECTURE.md, STATE.md, AGENTS.md
├── memory/                     # onboarding tiles for future agents
└── CONTRACT.md                 # the signed JSON wire format
```

## How to extend the bridge contract

The contract is the JSON shape that flows from cocapn-marine's eventual
I/O layer through the bridge into the browser. It is pinned in **one**
place (with documentation in two):

1. `contracts/contract_projection.rs` — the canonical Rust source.
   This is the only place field names are declared. Both the Python
   bridge (`digital_twin_shell/cocapn_contract.py`) and the test
   (`tests/test_smoke.py`) parse this file.
2. `CONTRACT.md` — the human-readable wire format.
3. `digital_twin_shell/bridge.py` — `validate_record()` and the
   contract constants (auto-derived from the Rust source).

When you change the contract:

1. Update the Python validator constants.
2. Update the TypeScript-ish JS in `index.html` (`onRecord` reads
   `rec.vessel`, `rec.autopilot`, `rec.bathy`, `rec.deadband`,
   `rec.depth_m`, `rec.timestamp`).
3. Update `sample-fixture.jsonl` (`python -m digital_twin_shell.gen_fixture`).
4. Re-run `python tests/test_smoke.py` — it asserts the contract.

## The hard rules

* No build step. `index.html` is the entire client.
* Three.js via CDN, pinned to a specific version (currently r161).
* Python runtime: stdlib + `websockets>=12` (with a stdlib-only fallback
  if `websockets` isn't importable).
* Repo must work from a fresh `git clone` + the README commands.

## What "done" looks like

You're done when:

* `python -m digital_twin_shell.bridge --replay --port 8765 &` and
  `python tests/test_smoke.py` both exit 0.
* `python -m http.server 8000 &` serves `index.html` cleanly (no JS
  errors in the console).
* `tests/screenshots/` contains either a Playwright screenshot or the
  curl-smoke log.

Welcome to the reef.