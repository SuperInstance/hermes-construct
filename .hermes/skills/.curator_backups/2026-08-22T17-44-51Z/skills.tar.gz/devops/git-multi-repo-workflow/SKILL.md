---
name: git-multi-repo-workflow
description: Git workflows for multi-repo orchestrations, submodule cleanup, and integration branch management.
---

# Git Multi-Repo Workflow

Use this skill when working across multiple repositories that are orchestrated together, especially when submodules or integration branches are involved.

## Pitfalls

**Monorepo Subdir Masquerade**
Paths under a single work-tree can appear as independent repos. Example: `/c/Users/casey/polln/claw`, `/c/Users/casey/polln/spreadsheet-moment` etc. all resolve to `/c/Users/casey/polln/.git`. Detect with:
```
git -C "<path>" rev-parse --git-dir
git -C "<path>" rev-parse --show-toplevel
```
Duplicate results mean the paths are not independent. Do not fetch/push them individually; operate on the top-level repo only.

**Shared Git-Dir Duplicates**
Temp clones and sandbox copies e.g., `/c/Users/casey/AppData/Local/Temp/hermes-clone` can duplicate a canonical clone. Always de-duplicate by remote URL + git-dir before auditing sync state.

**Diverged Work-Tree Loss Risk**
When local commits diverge ahead/behind remote, a fast-forward pull will fail. Before deleting local disk copies, preserve the local commit graph on GitHub. Create a backup branch from current HEAD and push it:
```
git -C "<path>" fetch origin
git -C "<path>" branch -f local-backup-$(date +%Y-%m-%d)
git -C "<path>" push -u origin local-backup-$(date +%Y-%m-%d):refs/heads/local-backup-$(date +%Y-%m-%d)
```
This guarantees nothing is lost even if merge is impossible. Only delete local after the backup ref is confirmed on remote.

## Multi-Repo Audit & Cleanup Workflow

**1. Inventory**
Find all `.git` directories under the user home:
```
find /c/Users/casey -maxdepth 5 -type d -name .git -print
```
Normalize paths and group by `git -C "<path>" rev-parse --git-dir` + remote URL to collapse work-tree doppelgängers.

**2. Sync Classification**
For each unique repo:
```
git -C "<path>" fetch origin
ahead=$(git -C "<path>" rev-list --count origin/main..HEAD || git -C "<path>" rev-list --count origin/master..HEAD)
behind=$(git -C "<path>" rev-list --count HEAD..origin/main || git -C "<path>" rev-list --count HEAD..origin/master)
dirty=$(git -C "<path>" status --porcelain | wc -l)
```
Classify as synced / behind / ahead / diverged / dirty.

**3. Parallel Execution**
Use background terminals with `notify_on_complete` for pulls, pushes and deletions. Pull fast-forward only for behind repos you intend to keep:
```
git -C "<path>" fetch origin && git -C "<path>" pull --ff-only origin main
```
Delete only after backup verification.

**4. Disk Reclaim**
Delete local clones that are fully synced with GitHub and have no local commits ahead:
```
rm -rf "<path>"
```
Prioritize duplicates, sandbox, temp, and experiment trees first.

## Reference Files

- `references/integration-branch-patterns.md` — force-push, submodule cleanup, and commit conventions
- `references/audit-cleanup-playbook.md` — step-by-step audit, backup-branch, and parallel cleanup pattern used for SuperInstance fleet

## Reference Files

- `references/integration-branch-patterns.md` — force-push, submodule cleanup, and commit conventions
