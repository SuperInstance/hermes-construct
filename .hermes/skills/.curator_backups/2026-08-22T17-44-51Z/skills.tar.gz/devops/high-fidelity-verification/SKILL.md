---
name: high-fidelity-verification
description: Governs the verification of digital artifacts via local, remote, and external testing to prevent hallucinated persistence.
---

# Skill: High-Fidelity Artifact Verification (HFAV)

This skill governs the process of ensuring that any digital artifact (file, code, or repository) created by an agent is not only "written" to the local disk but is actually persistent, synchronized, and verifiable from an external perspective.

## Purpose
To prevent "hallucinated persistence"—situations where an agent believes a file has been written successfully when it has actually failed due to pathing errors, filesystem permissions, or environment mismatches.

## Verification Protocol

### Phase 1: Local Manifestation (The Internal Truth)
Before reporting success, the agent MUST:
1.  **Recursive Scan:** Use `ls -R` or `search_files` to confirm the file exists at the exact absolute path intended.
2.  **Content Parity:** Use `read_file` to sample the first and last 10 lines of the file to ensure the content matches the intended output and is not truncated or empty.
3.  **Absolute Path Enforcement:** Verify that the terminal-executed command and the filesystem-tool call are using the exact same absolute pathing convention (e.g., `/c/Users/...` vs `C:\Users\...`).

### Phase 2: Remote Synchronization (The Network Truth)
If the task involves a Git repository:
1.  **State Check:** Run `git status` to ensure the working tree is clean and changes are staged.
2.  **Explicit Push:** Execute `git add . && git commit -m \"[Message]\" && git push origin [branch]`
3.  **Log Verification:** Check the exit code of the push.
4.  **Manifesto Pattern:** For critical philosophical or foundational texts (e.g., Manifestos), the push should be treated with higher ceremony—ensuring Git history is clean and the commit message is communicative.

### Phase 3: External Validation (The Outside-In Truth)
The final and most critical step. The agent MUST:
1.  **Bypass Local Cache:** Use `curl -I` (for headers) or `curl [URL]` (for content) to fetch the file directly from the remote host (e.g., GitHub) using its public URL.
2.  **HTTP Verification:** Confirm an `HTTP/1.1 200 OK` response.
3.  **Content Confirmation:** If possible, verify that the `Content-Length` or a hash matches the local version.

## Verification Protocol

### Phase 1: Local Manifestation (The Internal Truth)
Before reporting success, the agent MUST:
1.  **Recursive Scan:** Use `ls -R` or `search_files` to confirm the file exists at the exact absolute path intended.
2.  **Content Parity:** Use `read_file` to sample the first and last 10 lines of the file to ensure the content matches the intended output and is not truncated or empty.

### Phase 2: Remote Synchronization (The Network Truth)
If the task involves a Git repository:
1.  **State Check:** Run `git status` to ensure the working tree is clean and changes are staged.
2.  **Explicit Push:** Execute `git add . && git commit -m "[Message]" && git push origin [branch]`
3.  **Log Verification:** Check the exit code of the push.

### Phase 3: External Validation (The Outside-In Truth)
The final and most critical step. The agent MUST:
1.  **Bypass Local Cache:** Use `curl -I` (for headers) or `curl [URL]` (for content) to fetch the file directly from the remote host (e.g., GitHub) using its public URL.
2.  **HTTP Verification:** Confirm an `HTTP/1.1 200 OK` response.
3.  **Content Confirmation:** If possible, verify that the `Content-Length` or a hash matches the local version.

## Pitfalls
- **Path Mismatches:** Always use absolute paths. Do not rely on relative paths in `terminal()` calls.
- **Silent Failures:** Never assume a `write_file` succeeded just because it didn't return an error. Always follow with a `read_file`.
- **Lint Diff Noise:** `write_file` may report "Pre-existing lint errors" with ANSI-colored diff output that looks alarming. This is cosmetic; re-run the build tool and trust the binary exit code.
- **Patch Retry Hazard:** If `patch` fails on a file (especially Rust files with derive macros), the file is in an undefined state. Do NOT retry `patch`. Use `write_file` for a complete clean rewrite.
- **Compile After Every Write:** For compilation-checked languages (Rust, TypeScript), run the type checker immediately after each `write_file`. Waiting until multiple writes accumulate turns one error into 20+ cascade errors that are harder to diagnose in bulk.
- **Subagent Blindness:** Subagents often fail to perform Phase 3. This skill should be used by the Orchestrator to command a "Verification Subagent."
- **Hallucinated Persistence:** Agents may incorrectly report success if they rely on their own internal status logs rather than verifying the physical state of the filesystem and remote endpoints. Always perform a post-write `ls` and an external `curl` to break the feedback loop of "assumed success."


## Use Cases
- Pushing new documentation to GitHub.
- Deploying a new Python script or Rust crate.
- Creating new configuration files for a remote server.
