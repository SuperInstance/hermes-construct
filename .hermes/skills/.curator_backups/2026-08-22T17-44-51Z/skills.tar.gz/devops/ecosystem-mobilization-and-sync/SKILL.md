---
name: ecosystem-mobilization-and-sync
description: Governs the high-fidelity distribution, synchronization, and verification of documentation, schemas, and architectural context across a distributed, multi-repository ecosystem.
---

# Ecosystem Mobilization & Synchronization

Governs the movement, synchronization, and verification of documentation, schemas, and architectural context across a distributed, multi-repository ecosystem.

## 🎯 Purpose
To prevent \"intelligence decay\" and \"context fragmentation\" when a single architectural change must be propagated across multiple independent repositories.

## 🛠 Core Workflow: The Mobilization Sequence

### 1. Preparation & Mapping
- **Verify Source:** Ensure master documentation, schemas, and guides are in their final, versioned state in the master repository.
- **Target Mapping:** Map the source (Master Docs) to the destination (Target Repo `docs/` or `onboarding/`).

### 2. The \"Atomic Sync\" Pattern
To avoid the `180s` timeout limit and Git divergence in large repositories:
- **DO NOT** use bulk loop scripts (e.g., `for r in repos; do ... done`) via `terminal` if the repos contain thousands of files (like `node_modules/`).
- **DO** iterate manually/sequentially via discrete `terminal` calls.
- **Sequence for each repo:**
  1. `cd <repo>`
  2. `git fetch origin`
  3. `git pull origin <branch> --rebase` (Handle divergence early).
  4. `mkdir -p docs`
  5. `cp -r <source_docs_path>/* docs/` (Use `rsync` if available to exclude heavy/junk directories).
  6. `git add docs/`
  7. `git commit -m \"docs: sync master architecture and onboarding\"`
  8. `git push origin HEAD`

### 3. The \"Massive Docs Commit\" Strategy
In high-volume synchronization (e.g., adding dozens of onboarding/security files at once):
- **Symptom:** Large file counts or high insertion numbers (e.g., 50k+ lines) causing long-running Git processes.
- **Behavior:** Git may emit numerous `LF will be replaced by CRLF` warnings on Windows hosts.
- **Action:** Proceed with the commit. These are cosmetic warnings handled by Git and do not indicate corruption or failure.
- **Post-Commit:** Always verify the push success by checking the exit code of the `git push` command immediately following the commit.

## ⚠️ Pitfalls & Mitigations

### Diverged Branches (Non-fast-forward)
- **Symptom:** `git push` returns `[rejected] HEAD -> main (non-fast-forward)`.
- **Fix:** 
  - **Safe:** `git pull --rebase` to integrate remote changes.
  - **Aggressive (Requires User Consent):** `git reset --hard origin/<branch>` to wipe local state.

### Bulk Operation Timeouts
- **Symptom:** Command exit code `124` (Timeout).
- **Cause:** Recursive `cp` or `git push` on massive file counts exceeds 180s.
- **Fix:** Break the loop. Execute one repository at a time. Explicitly exclude `node_modules/` or `.venv/` from the copy phase.

### Pathing Proxy & Symlink Mismatches
- **Symptom:** `write_file` or `patch` operations land in a \"ghost directory\" (e.g., `C:\\\\c\\\\Users\\\\...`).
- **Fix:** **Always use absolute paths** for filesystem operations during high-stakes orchestration. 

### Remote Collision
- **Symptom:** Attempting to add a remote `origin` that already exists.
- **Fix:** Use `git remote remove origin` before re-establishing a connection if needed.

## 🧬 Succession Logic
Every synchronization task MUST culminate in the creation of a \"Handover\" artifact. A repository is not \"synced\" until its internal documentation reflects the current state of the global architecture.
