---
name: rust-compilation-patterns
description: Catalog of recurring Rust compilation fixes, schema derivation workarounds, and test correction patterns.
---

# Rust Compilation Patterns

Use this skill when fixing Rust compilation errors that recur across codebases.

## Reference Files

- `references/rust-compilation-fixes.md` — detailed fix patterns with examples
