# Rust Compilation Fix Patterns (2026-03 session)

## Schemars + Uuid/DateTime Gaps

When `Uuid`, `DateTime<Utc>`, or `Vec<(Uuid, String)>` are used in a struct deriving `JsonSchema`, add explicit overrides:

- `Uuid` → `#[schemars(with = "String")]`
- `DateTime<Utc>` → `#[schemars(with = "String")]`
- `Vec<(Uuid, String)>` → `#[schemars(with = "Vec<(String, String)>")]`

## Ambiguous Glob Re-exports Warning

When `pub use common::*;` and `pub use claw::*;` both export a shared type name (e.g. `ErrorHandling`), resolve by:

1. Moving the shared type into one module only, or
2. Re-exporting the canonical path explicitly instead of glob, or
3. Living with the warning if dedup is too invasive. (Preferred during active development.)

## Test Fixes for Enum Misuse

If integration tests construct an enum as a struct (e.g. `Capability { name: "..." }`), replace with the correct enum variant (`Capability::MemoryPersistence`). Rust will surface this as a type-error in struct-like syntax.

## Unused Variable in Tests

When `let removed =` (or similar) is unused in an assert-less test, rename to `let _removed =` to suppress the warning without changing semantics.

## Duplicate Type Definitions

If `cargo check` reports ambiguous types between modules, search for duplicate `struct`/`enum` definitions across files. Deduplicate into one canonical module and add `use` statements to consumers. After deduplication, remove orphaned `#[derive(...)]` lines in the file that lost the definition.

## Submodule Pointer Cleanup

If `git status` shows a path in `D` (deleted) or `R` (renamed) with mode `160000`, it is a git submodule pointer without proper `.gitmodules`. Remove via:
```
git rm --cached --quiet <submodule-path>
```
Then recommit. This unblocks future commits in the parent repo.

## Force-Push for Unrelated Histories

When `git pull` fails due to unrelated histories and the branch is a clean-publish integration branch, force-push:
```
git push --force origin <branch>
```
Acceptable for integration branches with no external collaborators.
