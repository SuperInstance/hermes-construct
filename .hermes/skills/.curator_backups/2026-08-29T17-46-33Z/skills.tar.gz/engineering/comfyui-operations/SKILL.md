---
name: comfyui-operations
title: ComfyUI Local Image Generation
description: 'Governs the end-to-end operation of a local ComfyUI instance for image generation: server lifecycle, mock module patching, dtype fixes, prompt submission, and output retrieval. Applies to the user''s Documents\\ComfyUI install on Windows.'
---

# ComfyUI Local Image Generation

## When to Use This Skill

Use whenever you need to produce images from a local ComfyUI installation — whether from a Python submission script, the web UI, or a queued prompt. This skill covers the full pipeline from "ComfyUI is broken" to "PNG delivered."

---

## Environment

| Variable | Value |
|---|---|
| ComfyUI root | `C:\Users\casey\Documents\ComfyUI` |
| venv Python | `.venv\Scripts\python.exe` |
| Default port | `8188` |
| GPU | NVIDIA RTX 4050 Laptop (CUDA, 6 GB VRAM) |
| Checkpoint library | `models\checkpoints\` inside root |
| Output dir | `output\` inside root |

---

## Step 1 — Pre-flight: Is ComfyUI Already Running?

```bash
curl -s -w "\nHTTP:%{http_code}" http://127.0.0.1:8188/system_stats | tail -3
```

- `HTTP:200` → server is live, skip to Step 5.
- `HTTP:000` or connection refused → go to Step 2.

**Important:** This system also runs a desktop ComfyUI Manager on port **8000** (owned by `Manager.exe`, not python). Do not kill or interfere with that instance.

---

## Step 2 — Patch `comfy_aimdo` Mock Module (One-Time, idempotent)

ComfyUI's `comfy-aimdo` plugin ships a mock module that, in this install, raises on import and returns `None` from `.get()` — both break model loading.

### `comfy\\aimdo\\control.py`
Must define `lib = None` at module level. If missing, add it after imports.

### `comfy\\aimdo\\model_mmap.py`
```python
import ctypes

class ModelMMAP:
    def __init__(self, filepath):
        self.initialized = True
        self.path = filepath
        try:
            with open(filepath, 'rb') as f:
                data = f.read()
            self._buf = ctypes.create_string_buffer(data)
            self._addr = ctypes.addressof(self._buf)
            self._size = len(data)
        except Exception:
            self._buf = ctypes.create_string_buffer(0)
            self._addr = ctypes.addressof(self._buf)
            self._size = 0

    def get(self):
        """Return integer memory address — required by comfy.utils.load_safetensors."""
        return self._addr

    def get_file_handle(self):
        return 0

    def bounce(self):
        return False

    def __del__(self):
        pass
```

**Why this is needed:** `comfy/utils.py` calls `model_mmap.get()` and passes the result to `ctypes.c_uint8 * file_size).from_address(...)`. If `.get()` returns `None` → `TypeError: integer expected`. Returning a real ctypes buffer address fixes it without the actual aimdo DLL.

### ⚠️ CRITICAL: The venv package shadows the local mock

This install has `comfy-aimdo 0.4.13` installed in `.venv\Lib\site-packages\`. Python's import system will find that copy **before** the local `comfy_aimdo\` folder in the repo root. Patching the local files alone is insufficient — the venv copy will still be loaded and will still raise.

**Permanent fix (idempotent):**
```bash
cd C:/Users/casey/Documents/ComfyUI
.venv/Scripts/python.exe -m pip uninstall comfy-aimdo -y
```

After uninstall, Python falls back to the local `comfy_aimdo\` directory, which carries the patched mock. No further venv-side maintenance needed.

### Verify the right module is loading

```bash
cd C:/Users/casey/Documents/ComfyUI && .venv\Scripts\python.exe -c "
import comfy_aimdo, inspect
print('file:', comfy_aimdo.__file__)
print('has ModelMMAP:', hasattr(comfy_aimdo, 'ModelMMAP'))
m = comfy_aimdo.ModelMMAP('dummy')
print('get() returns int:', isinstance(m.get(), int))
"
```

Expected output: `file` points to `C:\Users\casey\Documents\ComfyUI\comfy_aimdo\__init__.py` (the local folder, NOT `.venv\Lib\site-packages\`). If it still points to site-packages, the uninstall didn't stick — re-run `pip uninstall`.

After patching, **flush all pycache** before restarting ComfyUI:
```bash
find C:/Users/casey/Documents/ComfyUI -name "__pycache__" -type d -exec rm -rf {} +
find C:/Users/casey/Documents/ComfyUI -name "*.pyc" -delete
```

---

## Step 3 — Kill Stale Processes and Restart

Port conflicts and database locks are the two most common silent ComfyUI startup failures. Kill stale instances before restart.

```bash
taskkill //F //IM python.exe
```

**Critical:** Flush pycache AFTER kill and BEFORE restart — starting a fresh executable instance on cached `.pyc` will silently re-trigger the original TypeError even after patching.

**Restart:** use `terminal(background=True, notify_on_complete=False)`. The background `Session` returns immediately with a `session_id`. Do NOT use `nohup` or shell `&` — those paths error in this environment.

**Wait for ready:** checkpoint index on this hardware takes 60–90 s. Poll repeatedly:
```bash
sleep 30
netstat -ano | grep "8188" | head -3
curl -s -w "\nHTTP:%{http_code}" http://127.0.0.1:8188/system_stats | tail -3
```
HTTP:200 + `"comfyui_version": "0.32.0"` → server fully ready.

**If server still hasn't bound after 90 s:** background-mode stdout is invisible in this env. Switch to foreground with a log redirect to diagnose:
```bash
cd C:/Users/casey/Documents/ComfyUI && .venv/Scripts/python.exe main.py --listen 127.0.0.1 --port 8188 --force-fp32 > C:/Users/casey/comfy_startup.log 2>&1
```
Inspect `C:\Users\casey\comfy_startup.log` — it captures exactly the startup errors that background mode hides.

---

## Step 4 — Handle dtype Mismatch (The `Half` vs `Float` Error)

**Symptom:**
```
RuntimeError: mat1 and mat2 must have the same dtype, but got Half and Float
```
at KSampler step, after checkpoint loaded successfully.

**Cause:** Chilloutmix and some SD1.5 checkpoints load UNet weights as `float16` while empty latent and noise tensors are `float32`.

**Fix:** Restart with:
```bash
.venv\Scripts\python.exe main.py --listen 127.0.0.1 --port 8188 --force-fp32
```

`--force-fp32` coerces UNet to FP32, matching noise/latent tensors. Prefer this over `--force-fp16` and over casting tensors in the workflow.

**Do NOT refactor to `UNETLoader` / `CLIPLoader` / `VAELoader` separately** — on this install those loaders have empty model name lists. The only populated loader is `CheckpointLoaderSimple` which returns `[MODEL, CLIP, VAE]`.

---

## Step 5 — Submit a Prompt

- [templates/submit_prompt.py](templates/submit_prompt.py)
- [references/2026-08-19-aimdo-debug-session.md](references/2026-08-19-aimdo-debug-session.md)
- [references/2026-09-29-venv-shadow.md](references/2026-09-29-venv-shadow.md) – Additional venv shadowing and verification guide.
**Wiring rules (CheckpointLoaderSimple output indices):**
- KSampler `model` → `["4", 0]`
- CLIPTextEncode `clip` → `["4", 1]`
- VAEDecode `vae` → `["4", 2]`

Always use `CheckpointLoaderSimple` (not split loaders) with this install.

**Poll result:**
```bash
curl -s "http://127.0.0.1:8188/history/<prompt_id>" | python3 -c "...parse status_str..."
```

- `"status_str": "error"` → read `status.messages` for `execution_error`; `node_id` from `current_outputs` identifies the failing node.
- `"status_str": "success"` → images written to `output\`.

---

## Step 6 — Retrieve Generated Image

```bash
ls -lt C:/Users/casey/Documents/ComfyUI/output/
```

Files are `<prefix>_#####_.<ext>`. Deliver to user via `send_message` with `MEDIA:<absolute_path>` and optionally `vision_analyze` to confirm content.

---

## Pitfalls

| Pitfall | Fix |\n|---|---|\n| VM snapshot failures (stale snapshots) | Unprovisioned VMs consume resources on non‑reclaimed hyper‑visors. | Corrupted snapshots cause VM host crashes or fail to delete on ACME provisioning. |\n\n| **Additional pitfalls (2026-08-19)** | See `references/2026-08-19-additional-pitfalls.md` for detailed, up‑to‑date resolution steps (port‑release, venv shadowing, cache clearing). |\n
|---|---|
| `taskkill //F //IM python.exe` kills desktop app | Desktop app uses `Manager.exe`. Safe to kill python alone for this install. |
| Server "started" but port never binds | Background stdout is invisible. Re-run in foreground with log redirect after 90 s without HTTP:200. |
| `UNETLoader` / `CLIPLoader` name lists are empty | This install registers checkpoints only under `CheckpointLoaderSimple`. Do not refactor to split loaders. |
| Port stuck in TIME_WAIT after kill | Clears within ~60 s. Wait and recheck with `netstat`. |
| `comfyui.db` locked after crash | Kill all python.exe processes; SQLite lock clears automatically. Do not delete the database while python holds it. |
| dtype error after checkpoint loads | Checkpoint loaded fine — mismatch is at sampler step. Apply `--force-fp32` on restart. |
| Patch written but same `integer expected` error on next start | Almost always stale `__pycache__` from before the patch. Kill → flush → restart is mandatory sequence. |
| Background process appears alive but port never binds | Check `netstat -ano \| grep "8188"`; if no LISTENING, poll the process with `process(action='log')` or foreground-rerun. |
| `comfy_aimdo` patch in local repo has no effect | Venv site-packages copy (`comfy-aimdo 0.4.13`) shadows the local mock. Run `pip uninstall comfy-aimdo -y`. Verify with `python -c "import comfy_aimdo; print(comfy_aimdo.__file__)"` — path must contain `ComfyUI\comfy_aimdo\`, NOT `.venv\Lib\site-packages\`. |

---
\n|---|---\n| **New Pitfall: Venv shadowing causing wrong package import** | When `comfy-aimdo` remains installed in the venv, Python imports the shadowed version, ignoring patches to local files and causing `TypeError: integer expected`. Fix: uninstall the package (`pip uninstall comfy-aimdo -y`), flush `__pycache__`, verify import path points to the repo’s `comfy_aimdo`, then restart. See `references/2026-09-29-venv-shadow.md`. |\\\n\n## Templates

- [templates/submit_prompt.py](templates/submit_prompt.py) — copy-pasteable prompt submission script for this install's CheckpointLoaderSimple wiring.
- [references/2026-08-19-aimdo-debug-session.md](references/2026-08-19-aimdo-debug-session.md) — full error signature catalog and resolution chain for comfy_aimdo issues. Reference this when the same `TypeError: integer expected` reappears after restart.
