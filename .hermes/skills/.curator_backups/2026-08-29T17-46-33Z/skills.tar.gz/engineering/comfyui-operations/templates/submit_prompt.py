"""Submit a single image generation prompt to the local ComfyUI instance.

Usage:
    python submit_prompt.py

Edit the PROMPT, NEGATIVE, WIDTH, HEIGHT, STEPS, CFG, SEED, PREFIX,
and CKPT_NAME variables below before running.

Wiring (CheckpointLoaderSimple output indices):
    KSampler.model   -> ["4", 0]   (MODEL)
    CLIPTextEncode   -> ["4", 1]   (CLIP)
    VAEDecode.vae    -> ["4", 2]   (VAE)
"""

import json
import urllib.request
import urllib.error
import time

SERVER = "http://127.0.0.1:8188"

# ── Edit these ──────────────────────────────────────────────────────────────
PROMPT = (
    "Hermes the towfish submarine drone, home on a sleek modern submarine interior, "
    "glowing screens, sonar displays, warm cabin lights, detailed mechanical parts, "
    "dieselpunk aesthetic, copper pipes and brass fixtures, cinematic lighting, "
    "highly detailed, 8k, masterpiece"
)
NEGATIVE = "ugly, blurry, low quality, distorted, deformed, bad anatomy, watermark, text"
WIDTH = 768
HEIGHT = 768
STEPS = 25
CFG = 7.0
SEED = 42
PREFIX = "Hermes_Sub"
CKPT_NAME = "chilloutmix_NiPrunedFp32Fix.safetensors"
# ─────────────────────────────────────────────────────────────────────────────

workflow = {
    "3": {
        "class_type": "KSampler",
        "inputs": {
            "seed": SEED,
            "steps": STEPS,
            "cfg": CFG,
            "sampler_name": "euler",
            "scheduler": "normal",
            "denoise": 1.0,
            "model": ["4", 0],
            "positive": ["6", 0],
            "negative": ["7", 0],
            "latent_image": ["5", 0],
        },
    },
    "4": {
        "class_type": "CheckpointLoaderSimple",
        "inputs": {"ckpt_name": CKPT_NAME},
    },
    "5": {
        "class_type": "EmptyLatentImage",
        "inputs": {"width": WIDTH, "height": HEIGHT, "batch_size": 1},
    },
    "6": {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": PROMPT, "clip": ["4", 1]},
    },
    "7": {
        "class_type": "CLIPTextEncode",
        "inputs": {"text": NEGATIVE, "clip": ["4", 1]},
    },
    "8": {
        "class_type": "VAEDecode",
        "inputs": {"samples": ["3", 0], "vae": ["4", 2]},
    },
    "9": {
        "class_type": "SaveImage",
        "inputs": {"filename_prefix": PREFIX, "images": ["8", 0]},
    },
}


def submit(session):
    payload = json.dumps({"prompt": workflow}).encode("utf-8")
    req = urllib.request.Request(
        f"{SERVER}/prompt",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode())
            print(json.dumps(data, indent=2))
            return data.get("prompt_id")
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.read().decode()}")
        return None
    except Exception as exc:
        print(f"Error: {exc}")
        return None


def poll(prompt_id, timeout=300, interval=5):
    """Poll history until success or error, return (status_str, outputs)."""
    deadline = time.monotonic() + timeout
    url = f"{SERVER}/history/{prompt_id}"
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                entry = json.loads(resp.read().decode()).get(prompt_id, {})
                status = entry.get("status", {})
                s = status.get("status_str", "pending")
                if s in ("success", "error"):
                    return s, entry.get("outputs", {})
        except Exception:
            pass
        time.sleep(interval)
    return "timeout", {}


if __name__ == "__main__":
    pid = submit({})
    if not pid:
        raise SystemExit(1)
    print(f"Prompt queued: {pid} — waiting for completion…")
    status, outputs = poll(pid)
    print(f"Final status: {status}")
    if outputs:
        print(f"Outputs: {json.dumps(outputs, indent=2)[:500]}")
