# Additional pitfalls (2026-08-19)

## Port conflict persistence
After killing all Python processes with `taskkill //F //IM python.exe`, ensure the port is fully released. Run `netstat -ano | findstr :8188` – if any `LISTENING` entries remain, wait for Windows to release the port (typically within 60 seconds) before restarting ComfyUI. Rebooting the machine is unnecessary; just wait.

## Venv package shadowing
In this install, `comfy-aimdo 0.4.13` is installed into the venv and shadows the local `comfy_aimdo` folder. Run:
```bash
.venv\\Scripts\\python.exe -m pip uninstall comfy-aimdo -y
```
After uninstall, verify that the imports now resolve to the patched directory:
```bash
python -c "import comfy_aimdo; print(comfy_aimdo.__file__)"
```
The printed path must contain `ComfyUI\\comfy_aimdo\\`. If it still points to `.venv\\Lib\\site-packages\\`, repeat the uninstall.

## Stale `__pycache__` artifacts
Even after patching the mock module, stale bytecode in `__pycache__` can cause the original `TypeError: integer expected` to reappear. Always clear caches before a restart:
```bash
find C:/Users/casey/Documents/ComfyUI -name "__pycache__" -type d -exec rm -rf {} +
find C:/Users/casey/Documents/ComfyUI -name "*.pyc" -delete
```
Failure to clear caches invalidates the patches and will produce the same error on subsequent launches.