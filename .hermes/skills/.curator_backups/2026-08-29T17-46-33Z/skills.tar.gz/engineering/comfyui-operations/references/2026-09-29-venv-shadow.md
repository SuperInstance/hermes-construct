# Venv Shadowing – Why It Breaks ComfyUI and How to Fix It

## Symptom
When `comfy-aimdo` (or any other package) is installed inside the virtual environment,
Python import resolution loads that copy before the local repository files.
Result: patches to `comfy_aimdo\control.py` or `comfy_aimdo\model_mmap.py`
are ignored, leading to errors such as:

```
TypeError: integer expected
```

during model loading.

## Root Cause
The venv’s `site‑packages` directory is added to `sys.path` earlier than the
project root. Even though the repository contains a patched version of
`comfy_aimdo`, the venv copy is found first and used.

## Fix – One‑Time, Idempotent Steps

1. **Uninstall the venv package**  
   ```bash
   cd "C:/Users/casey/Documents/ComfyUI"
   .venv\\Scripts\\python.exe -m pip uninstall comfy-aimdo -y
   ```

2. **Verify the correct module is loaded**  
   ```bash
   .venv\\Scripts\\python.exe -c "\
import comfy_aimdo, inspect; \
print('module file:', comfy_aimdo.__file__); \
print('has ModelMMAP:', hasattr(comfy_aimdo, 'ModelMMAP'))"
   ```
   Expected output shows the path containing `ComfyUI\\comfy_aimdo\\` (not
   `...\\.venv\\Lib\\site-packages\\`).

3. **Flush compiled bytecode**  
   ```bash
   rm -rf "C:/Users/casey/Documents/ComfyUI/__pycache__"
   find "C:/Users/casey/Documents/ComfyUI" -name "*.pyc" -delete
   ```

4. **Restart ComfyUI** (see the *Step 2 — Patch* section for patch details)

## References
* `skills/comfyui-operations/SKILL.md` – ComfyUI operations guide
* `references/2026-08-19-additional-pitfalls.md` – Additional pitfalls and solutions