# ComfyUI comfy_aimdo — Session Reference (2026-08-19)

## Error Signatures Observed

### 1. `TypeError: integer expected` at `load_safetensors`
```
File "comfy/utils.py", line 92, in load_safetensors
    mv = memoryview((ctypes.c_uint8 * file_size).from_address(model_mmap.get()))
TypeError: integer expected
```
**Root cause A:** `model_mmap.get()` returns `None` (mock stub not implemented).
**Root cause B:** `model_mmap.get()` raises `RuntimeError("comfy-aimdo is not initialized")` because `control.lib = None`.
**Root cause C (this session):** Local `comfy_aimdo/` mock was patched, but the installed venv package in `.venv\Lib\site-packages\comfy_aimdo\` was being loaded instead, which still had the broken `get()`.
**Fix for A & B:** Patch `model_mmap.py` to read file into `ctypes.create_string_buffer` and return `ctypes.addressof(self._buf)` as integer.
**Fix for C:** `pip uninstall comfy-aimdo` so Python falls back to the local mock.

### 2. `RuntimeError: mat1 and mat2 must have the same dtype, but got Half and Float`
**Location:** KSampler `sample()` → `model.apply_model()` → linear layer.
**Cause:** Chilloutmix checkpoint loads UNet weights as fp16; empty latent + noise tensors are fp32.
**Fix:** Start ComfyUI with `--force-fp32` flag. Coerces UNet to fp32 to match latent tensors.
**Do NOT use:** `UNETLoader` with `dtype: "fp32"` — on this install the `unet_name` list is empty and validation rejects it. Only `CheckpointLoaderSimple` accepts `chilloutmix_NiPrunedFp32Fix.safetensors`.

### 3. `Port 8188 already in use` / `Failed to acquire lock on database`
**Cause:** Stale python.exe from prior crash holds port + SQLite lock.
**Fix:** `taskkill //F //IM python.exe` then re-start.

### 4. `VAELoader` validates `vae_name` against `['pixel_space']` only
**Wrong:** passing checkpoint filename to `VAELoader` → `value_not_in_list`.
**Correct:** Use `CheckpointLoaderSimple` which returns VAE as output index 2. No separate VAELoader needed for SD1.5 checkpoints.

## Resolution Chain (this session)

1. Patched local `comfy_aimdo/model_mmap.py` → `get()` returned integer address ✓
2. Discovered venv copy at `.venv\Lib\site-packages\comfy_aimdo\` was shadowing local mock ✗
3. Copied patched files into venv → worked temporarily but revert risk on reinstall
4. **Permanent fix:** `pip uninstall comfy-aimdo -y`
5. After uninstall: `comfy-aimdo` shows `installed: null` in `/system_stats`
6. Python now imports local `comfy_aimdo/` mock correctly

## Key Checkpoints Available

| Name | Notes |
|---|---|
| `chilloutmix_NiPrunedFp32Fix.safetensors` | SD 1.5 anime/realism hybrid, fp32 variant |
| `realisticVision_v60.safetensors` | Photorealistic |
| `dreamshaper_8.safetensors` | Versatile stylized |
| Full list | 22 checkpoints in `models\checkpoints\` |

## ComfyUI Version Behavior Notes

- `comfy-aimdo` version `0.4.13`: installed package is broken (no DLL available); local mock required.
- `VAELoader`: only accepts `"pixel_space"` — cannot be used to load SD1.5 VAE from checkpoint file.
- `UNETLoader` / `CLIPLoader`: model name lists are empty on this install. Use `CheckpointLoaderSimple`.
- `--force-fp32`: forces UNet weights to fp32. Safe default for this GPU (6 GB VRAM).
- Desktop Manager runs on port 8000 (`Manager.exe`), separate from the git install on 8188.
