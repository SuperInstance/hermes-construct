# comfyui-operations — Session Reference Notes

## 2026-08-19: First Successful Image Generation

### Environment L
- ComfyUI: 0.32.0, Python 3.12.11, PyTorch 2.8.0+cu129
- Desktop ComfyUI Manager on port 8000 (PID owned by `Manager.exe`, not python)
- Git-based ComfyUI in `C:\Users\casey\Documents\ComfyUI`, port 8188
- Two python.exe instances can run simultaneously without conflict

### Mock Module Patches (one-time, idempotent)
- `comfy_aimdo/control.py`: already contained `lib = None` — no action needed
- `comfy_aimdo/model_mmap.py`: added ctypes buffer + integer-returning `.get()`
  - Without this: `RuntimeError: comfy-aimdo is not initialized`
  - With missing `.get()` fix: `TypeError: integer expected` (from_address(None))
  - After full patch: checkpoint loads successfully

### dtype Mismatch Fix
- Error: `mat1 and mat2 must have the same dtype, but got Half and Float`
- Fires at KSampler first step, after model loads fine
- Solution: launch with `--force-fp32`; makes UNet FP32 to match latent/noise tensors
- Do NOT use UNETLoader/CLIPLoader/VAELoader separately — those loaders have empty model lists in this install
- Only `CheckpointLoaderSimple` has the populated checkpoint names; it returns [MODEL, CLIP, VAE]

### Process Lifecycle
- Stale python.exe processes hold port 8188 and SQLite database lock (`comfyui.db`)
- `taskkill //F //IM python.exe` is safe (desktop app runs `Manager.exe`)
- After kill: restart ComfyUI; server takes 60–90 s to warm up
- Background mode is correct for long-lived server; use foreground only for debugging startup
- `--force-fp32` flag must be on at server launch, not in the workflow

### Prompt Submission Wiring (CheckpointLoaderSimple)
```
"4" CheckpointLoaderSimple  -> ["MODEL", "CLIP", "VAE"]
"5" EmptyLatentImage
"6" CLIPTextEncode  clip=["4",1]
"7" CLIPTextEncode  clip=["4",1]
"3" KSampler        model=["4",0], positive=["6",0], negative=["7",0], latent_image=["5",0]
"8" VAEDecode       samples=["3",0], vae=["4",2]
"9" SaveImage       images=["8",0]
```

### Verification
- Health: `curl http://127.0.0.1:8188/system_stats` → HTTP 200, check `comfyui_version`
- Queue: submit prompt, get prompt_id
- Poll: `curl http://127.0.0.1:8188/history/<prompt_id>` → `status_str == "success"`
- Output: `ls -lt output/` → newest file is the result

### Known Working Checkpoint
- `chilloutmix_NiPrunedFp32Fix.safetensors` — generates with --force-fp32
