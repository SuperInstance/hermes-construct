# CUDA-enabled PyTorch Installation Options

## Option 1: Install CUDA-enabled PyTorch

```bash
# Uninstall any existing CPU or conflicting PyTorch packages
pip uninstall -y torch torchvision torchaudio

# Install the CUDA-enabled wheel matching your driver version (e.g., cu124 for recent NVIDIA drivers)
pip install --extra-index-url https://download.pytorch.org/whl/cu124 torch torchvision torchaudio

# Verify the installation
python -c "import torch; print('torch', torch.__version__, 'CUDA available:', torch.cuda.is_available())"
```

## Option 2: Install CPU-only PyTorch (for machines without compatible GPUs)

```bash
pip uninstall -y torch torchvision torchaudio
pip install torch torchvision torchaudio
python -c "import torch; print('torch', torch.__version__, 'CUDA available:', torch.cuda.is_available())"
```

## Option 3: General GPU Verification

```bash
python -c "import torch; print('CUDA available:', torch.cuda.is_available())"
nvidia-smi
```

## Recommended Sequence for this SuperInstance Setup

1. **Activate the ComfyUI virtual environment**  
   ```bash
   C:\Users\casey\Documents\ComfyUI\.venv\Scripts\activate
   ```

2. **Remove any remaining `comfy-aimdo` package that shadows local patches**  
   ```bash
   pip uninstall -y comfy-aimdo
   ```

3. **Clean stale byte‑code files**  
   ```bash
   find C:\Users\casey\Documents\ComfyUI -name "__pycache__" -type d -exec rm -rf {} + 
   find C:\Users\casey\Documents\ComfyUI -name "*.pyc" -delete
   ```

4. **Install the appropriate PyTorch variant** (Option 1 if you have a working GPU driver, Option 2 otherwise).

5. **Restart ComfyUI** (preferably in foreground for logs) and verify the `/system_stats` endpoint returns a 200 status.

## Common Pitfalls & Fixes

- **ImportError: cannot import name 'ModelMMAP' from 'comfy_aimdo.model_mmap'** – Ensure `comfy-aimdo` is uninstalled from the venv and that the import path points to the repo’s local `comfy_aimdo` directory.

- **RuntimeError: Torch not compiled with CUDA enabled** – Reinstall PyTorch with the appropriate CUDA wheel; the CPU‑only wheel will raise this error when a checkpoint expects a CUDA device.

- **Port binding errors after a crash** – Verify no lingering Python processes (`taskkill //F //IM python.exe`) and flush `__pycache__` before restarting.