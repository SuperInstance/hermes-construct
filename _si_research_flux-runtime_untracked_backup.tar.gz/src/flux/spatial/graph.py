"""
Spatial Hierarchy Graph engine for managing spatial relationships and containment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any, Generator


@dataclass(frozen=True)
class SpatialEntity:
    """Represents an object in the spatial hierarchy."""
    id: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __hash__(self):
        return hash(self.id)

    def __eq__(self, other):
        if not isinstance(other, SpatialEntity):
            return False
        return self.id == other.id


class SpatialHierarchyGraph:
    """
    A directed acyclic graph representing a spatial hierarchy.
    Each node is a SpatialEntity, and edges represent containment (parent -> child).
    """

    def __init__(self):
        # Mapping of entity_id -> SpatialEntity
        self._entities: Dict[str, SpatialEntity] = {}
        # Mapping of parent_id -> set of child_ids
        self._children: Dict[str, Set[str]] = {}
        # Mapping of child_id -> parent_id (ensures a strict hierarchy/tree structure)
        self._parents: Dict[str, str] = {}

    def add_entity(self, entity: SpatialEntity) -> None:
        """Adds an entity to the graph."""
        if entity.id not in self._entities:
            self._entities[entity.id] = entity
            self._children[entity.id] = set()

    def remove_entity(self, entity_id: str) -> None:
        """Removes an entity and its hierarchy links."""
        if entity_id not in self._entities:
            return

        # 1. Identify everything that needs to be removed (the entity itself + all its descendants)
        to_remove = [entity_id] + list(self.get_descendants(entity_id))

        # 2. Remove the links from the PARENT of the entity being removed
        parent_id = self._parents.get(entity_id)
        if parent_id:
            self._children[parent_id].discard(entity_id)
            del self._parents[entity_id]

        # 3. Remove all identified entities from central registries
        for eid in to_remove:
            if eid in self._entities:
                del self._entities[eid]
            if eid in self._children:
                del self._children[eid]
            if eid in self._parents:
                del self._parents[eid]

    def set_parent(self, entity_id: str, parent_id: str) -> None:
        """
        Sets the parent of an entity, effectively moving it in the hierarchy.
        
        Args:
            entity_id: The ID of the entity to move.
            parent_id: The ID of the new parent container.
        
        Raises:
            ValueError: If entity_id or parent_id doesn't exist, or if it creates a cycle.
        """
        if entity_id not in self._entities:
            raise ValueError(f"Entity '{entity_id}' not found.")
        if parent_id not in self._entities:
            raise ValueError(f"Parent '{parent_id}' not found.")
        if entity_id == parent_id:
            raise ValueError("An entity cannot be its own parent.")

        # Check for cyclic containment (is parent an ancestor of entity?)
        if self._is_ancestor(entity_id, parent_id):
            raise ValueError(f"Setting '{parent_id}' as parent of '{entity_id}' would create a cycle.")

        # Remove from old parent
        old_parent_id = self._parents.get(entity_id)
        if old_parent_id:
            self._children[old_parent_id].discard(entity_id)

        # Set new parent
        self._parents[entity_id] = parent_id
        self._children[parent_id].add(entity_id)

    def get_parent(self, entity_id: str) -> Optional[SpatialEntity]:
        """Returns the immediate parent of the entity."""
        parent_id = self._parents.get(entity_id)
        return self._entities.get(parent_id) if parent_id else None

    def get_children(self, entity_id: str) -> List[SpatialEntity]:
        """Returns all immediate children of the entity."""
        child_ids = self._children.get(entity_id, set())
        return [self._entities[cid] for cid in child_ids]

    def get_descendants(self, entity_id: str) -> Generator[str, None, None]:
        """Yields all descendant entity IDs using depth-first search."""
        for child_id in list(self._children.get(entity_id, set())):
            yield child_id
            yield from self.get_descendants(child_id)

    def get_ancestors(self, entity_id: str) -> List[SpatialEntity]:
        """Returns all ancestors of the entity (from root down to parent)."""
        ancestors = []
        curr_id = self._parents.get(entity_id)
        while curr_id:
            ancestors.append(self._entities[curr_id])
            curr_id = self._parents.get(curr_id)
        return ancestors  # Note: This is bottom-up. Reverse if top-down is needed.

    def is_contained_in(self, entity_id: str, container_id: str) -> bool:
        """Checks if the entity is contained within the specified container (directly or indirectly)."""
        curr_id = self._parents.get(entity_id)
        while curr_id:
            if curr_id == container_id:
                return True
            curr_id = self._parents.get(curr_id)
        return False

    def find_all_in(self, container_id: str) -> List[SpatialEntity]:
        """Finds all entities contained within the given container (recursively)."""
        if container_id not in self._entities:
            return []
        
        results = []
        for child_id in self._children[container_id]:
            results.append(self._entities[child_id])
            results.extend(self.find_all_in(child_id))
        return results

    def _is_ancestor(self, potential_ancestor_id: str, descendant_id: str) -> bool:
        """Internal check to see if A is an ancestor of B."""
        curr_id = self._parents.get(descendant_id)
        while curr_id:
            if curr_id == potential_ancestor_id:
                return True
            curr_id = self._parents.get(curr_id)
        return False

    def __repr__(self) -> str:
        return f"SpatialHierarchyGraph(entities={len(self._entities)}, rels={len(self._parents)})"
