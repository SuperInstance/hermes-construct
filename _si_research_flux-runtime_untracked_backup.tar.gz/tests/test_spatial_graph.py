from flux.spatial.graph import SpatialHierarchyGraph, SpatialEntity

def test_spatial_hierarchy():
    graph = SpatialHierarchyGraph()
    
    # Create Entities
    world = SpatialEntity("world")
    planet = SpatialEntity("planet")
    moon = SpatialEntity("moon")
    station = SpatialEntity("station")
    capsule = SpatialEntity("capsule")
    
    # Add to graph
    for e in [world, planet, moon, station, capsule]:
        graph.add_entity(e)
    
    # Build Hierarchy
    # world -> planet -> moon
    # planet -> station -> capsule
    graph.set_parent("planet", "world")
    graph.set_parent("moon", "planet")
    graph.set_parent("station", "planet")
    graph.set_parent("capsule", "station")
    
    print("DEBUG: Testing direct parent/child...")
    p = graph.get_parent("capsule")
    if p is None:
        print("ERROR: Parent of capsule is None")
    else:
        print(f"DEBUG: Parent of capsule is {p.id}")
        assert p.id == "station"
    
    print("DEBUG: Testing immediate children...")
    children = graph.get_children("station")
    assert len(children) == 1
    assert children[0].id == "capsule"
    
    # Test 2: Ancestors
    ancestors = graph.get_ancestors(capsule)
    ancestor_ids = [a.id for a in ancestors]
    assert ancestor_ids == ["station", "planet", "world"]
    
    # Test 3: Containment
    assert graph.is_contained_in("capsule", "world") is True
    assert graph.is_contained_in("capsule", "planet") is True
    assert graph.is_contained_in("capsule", "station") is True
    assert graph.is_contained_in("capsule", "moon") is False
    assert graph.is_contained_in("moon", "world") is True
    
    # Test 4: find_all_in (recursive)
    in_planet = graph.find_all_in("planet")
    in_planet_ids = {e.id for e in in_planet}
    assert in_planet_ids == {"moon", "station", "capsule"}
    
    # Test 5: Cyclic Prevention
    try:
        graph.set_parent("world", "capsule")
        assert False, "Should have raised ValueError for cycle"
    except ValueError as e:
        assert "cycle" in str(e).lower()
    
    # Test 6: Moving objects
    # Move capsule to moon
    graph.set_parent("capsule", "moon")
    assert graph.get_parent("capsule").id == "moon"
    assert graph.is_contained_in("capsule", "planet") is True # moon is in planet
    assert graph.is_contained_in("capsule", "world") is True
    
    # Test 7: Removal (Clean Test)
    graph2 = SpatialHierarchyGraph()
    e1 = SpatialEntity("1")
    e2 = SpatialEntity("2")
    e3 = SpatialEntity("3")
    for e in [e1, e2, e3]: graph2.add_entity(e)
    graph2.set_parent("2", "1")
    graph2.set_parent("3", "2")
    graph2.remove_entity("1")
    assert len(graph2._entities) == 0
    
    print("All spatial hierarchy tests passed!")

if __name__ == "__main__":
    test_spatial_hierarchy()
